<!-- catalog-only-start --><!-- ---

name: Material quick start on design/use and Material Theming
title: Theming
order: 1
-----><!-- catalog-only-end -->

get started and install:
npm install @material/web

Import element definitions from @material/web/<component>/<component-variant>.js.

// index.js
import '@material/web/button/filled-button.js';
import '@material/web/button/outlined-button.js';
import '@material/web/checkbox/checkbox.js';

Use the <component-name> tag in HTML markup. Refer to the component docs for more guidance on using each component.

Playground

<script type="module" src="./index.js"></script>

<label>
  Material 3
  <md-checkbox checked></md-checkbox>
</label>

<md-outlined-button>Back</md-outlined-button>
<md-filled-button>Next</md-filled-button>

# Theming

<!-- go/mwc-theming -->

<!--*
# Document freshness: For more information, see go/fresh-source.
freshness: { owner: 'lizmitchell' reviewed: '2024-02-12' }
tag: 'docType:concepts'
*-->

<!-- [TOC] -->

[Material Design theming](https://m3.material.io/foundations/customization)<!-- {.external} -->
creates unique branded products with familiar patterns and accessible
interactions.

![collage of views of a mobile UI that show a user's setting and preference for
a green primary color flows through system UI
harmoniously](images/theming.png "A user-generated color scheme can flow through apps that use a custom theme.")

## Tokens

Material is expressed in
[design tokens](https://m3.material.io/foundations/design-tokens/overview)<!-- {.external} -->,
which are the building blocks of all UI elements.

Each component token maps to a system token, which has a concrete reference
value.

![A diagram showing the heirachy of component tokens to system tokens to
reference
tokens](images/token-types.png "The relationship between reference, system, and component tokens.")

On the web, design tokens are
[CSS custom properties](https://developer.mozilla.org/en-US/docs/Web/CSS/--*)<!-- {.external} -->
and can be scoped with CSS selectors.

```css
.square-buttons {
  /* Changes all <md-filled-button> instances matching the selector */
  --md-filled-button-container-shape: 0px;
}
```

### Reference

Reference tokens hold concrete values, such as a hex color, pixel size, or font
family name.

#### Typeface

[`--md-ref-typeface` tokens](typography.md#typeface) can be used to change font
families and weights across all system and component tokens.

```css
:root {
  --md-ref-typeface-brand: "Fir Sans Condensed";
  --md-ref-typeface-plain: "Roboto Extra Condensed";
}
```

A typescale is a collection of font styles: font-family, font-size, line-height, and font-weight.

Tokens
Typescales can be set using CSS custom properties. Each typescale has three sizes: small, medium, and large. Each size has four properties: font (family), size, line-height, and weight.

Tokens follow the naming convention --md-sys-typescale-<scale>-<size>-<property>.

Typescale Tokens
Display --md-sys-typescale-display-medium-font
--md-sys-typescale-display-medium-size
--md-sys-typescale-display-medium-line-height
--md-sys-typescale-display-medium-weight
Headline --md-sys-typescale-headline-medium-font
--md-sys-typescale-headline-medium-size
--md-sys-typescale-headline-medium-line-height
--md-sys-typescale-headline-medium-weight
Title --md-sys-typescale-title-medium-font
--md-sys-typescale-title-medium-size
--md-sys-typescale-title-medium-line-height
--md-sys-typescale-title-medium-weight
Body --md-sys-typescale-body-medium-font
--md-sys-typescale-body-medium-size
--md-sys-typescale-body-medium-line-height
--md-sys-typescale-body-medium-weight
Label --md-sys-typescale-label-medium-font
--md-sys-typescale-label-medium-size
--md-sys-typescale-label-medium-line-height
--md-sys-typescale-label-medium-weight

#### Palette

_MWC does not currently support `--md-ref-palette` tokens._

### System

System tokens define decisions and roles that give the design system its
character, from color and typography, to elevation and shape.

#### Color

[`--md-sys-color` tokens](color.md#tokens) define dynamic color roles that map
to components. See the [color guide](color.md) for more details.

```css
:root {
  --md-sys-color-primary: red;
  --md-sys-color-secondary: blue;
}
```

:root {
/_ Generated from Material Theme Builder Figma plugin
or `material-color-utilities`. _/
--md-sys-color-primary: #006A6A;
--md-sys-color-on-primary: #FFFFFF;
--md-sys-color-primary-container: #6FF7F6;
--md-sys-color-on-primary-container: #002020;
/_ ... _/
}

/_ Usage in custom components _/
.primary {
background: var(--md-sys-color-primary);
color: var(--md-sys-color-on-primary);
}

A color scheme can be set using CSS custom properties. Tokens follow the naming convention --md-sys-color-<token>.

All tokens have a corresponding --md-sys-color-on-<token> for content color with accessible contrast.

Key color Tokens
Primary --md-sys-color-primary
--md-sys-color-primary-container
Secondary --md-sys-color-secondary
--md-sys-color-secondary-container
Tertiary --md-sys-color-tertiary
--md-sys-color-tertiary-container
Error --md-sys-color-error
--md-sys-color-error-container
Neutral --md-sys-color-background
--md-sys-color-surface
--md-sys-color-surface-bright _
--md-sys-color-surface-dim _
--md-sys-color-surface-container _
--md-sys-color-surface-container-lowest _
--md-sys-color-surface-container-low _
--md-sys-color-surface-container-high _
--md-sys-color-surface-container-highest \*
--md-sys-color-outline
--md-sys-color-outline-variant

- all surface tokens use --md-sys-on-surface or --md-sys-color-on-surface-variant for their content.

#### Typography

[`--md-sys-typography` tokens](typography.md#typescale) define typescale roles
that map to components. See the [typography guide](typography.md) for more
details.

```css
:root {
  --md-sys-typography-body-medium-size: 1rem;
  --md-sys-typography-body-medium-line-height: 1.5rem;
}
```

Tip: to change all font families across typescales, prefer setting --md-ref-typeface-brand and --md-ref-typeface-plain, which map to each typescale.

Use --md-sys-typescale-<scale>-font to change the typeface that a font is mapped to. This is useful for custom typefaces.

:root {
--my-brand-font: 'Open Sans';
--my-headline-font: 'Montserrat';
--my-title-font: 'Montserrat';
--my-plain-font: system-ui;

--md-ref-typeface-brand: var(--my-brand-font);
--md-ref-typeface-plain: var(--my-plain-font);

--md-sys-typescale-headline-font: var(--my-headline-font);
--md-sys-typescale-title-font: var(--my-title-font);
}

#### Shape

[`--md-sys-shape` tokens](shape.md#tokens) define corner shapes used in
components. See the [shape guide](shape.md) for more details.

```css
:root {
  --md-sys-shape-corner-small: 4px;
  --md-sys-shape-corner-medium: 6px;
  --md-sys-shape-corner-large: 8px;
}
```

#### Motion

_MWC does not currently support `--md-sys-motion` tokens._

### Component

Component tokens are design attributes assigned to elements. They can be system
tokens or concrete values.

```css
:root {
  --md-filled-button-container-shape: 0px;
}

md-filled-button.error {
  --md-filled-button-container-color: var(--md-sys-color-error);
  --md-filled-button-label-text-color: var(--md-sys-color-on-error);
}
```

Refer to each [components' documentation](../components/) for available tokens.

> Note: unlike `--md-ref-*` and `--md-sys-*` tokens, which are prefixed with
> `ref` and `sys`, component tokens are _not_ prefixed with `comp`.
