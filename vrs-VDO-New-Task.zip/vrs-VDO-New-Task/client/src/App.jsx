import { SnackbarProvider, useSnackbar } from "notistack";
import UserDashboard from "./views/UserDashboard";
import LandingPage from "./views/LandingPage";
import Error404 from "./views/Error404";
import QueueIn from "./views/QueueIn";
import {
  ServicePathThemeProvider,
  UserDashboardThemeProvider,
  QueueThemeProvider,
} from "./Themes";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import UserRegistration from "./components/registration/UserRegistration";
// import UserDashboardSplash from "./views/UserDashboardSplash";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import HHGShipping from "./views/HHGShipping";
import HHGClass1License from "./views/HHGClass1License";
import { Provider } from "react-redux";
import store from "./utils/store";
import Appointments from "./views/Appointments";
import ScheduleAppointment from "./components/Dashboard/Appointments/ScheduleAppointment.jsx";
import RequestsPanel from "./components/Dashboard/Requests/RequestsPanel.jsx";
import UserVehicles from "./components/Dashboard/Vehicles/UserVehicles.jsx";
import NewRequestsPage from "./views/NewRequests/NewRequestsPage.jsx";
import NewRequestsSplash from "./views/NewRequests/NewRequestsSplash.jsx";
import VRSRequestsGetStartedPage from "./views/NewRequests/RequestsGetStarted.jsx";
import RequestsNumberVehicles from "./views/NewRequests/RequestsNumberVehicles.jsx";
import WhichMethodUsed from "./components/Dashboard/Requests/WhichMethodUsed.jsx";
import HowDidYouTransfer from "./components/Dashboard/Requests/HowDidYouTransfer.jsx";

import MSFaskifneeded from "./components/Services/MSFaskifneeded.jsx";
import MSFverify from "./views/Services/MSFverify.jsx";
import MultipleServicesStart from "./views/Services/MultipleServicesStart.jsx";
import ReceivedNotificationRequests from "./components/Dashboard/Requests/ReceivedNotificationRequests.jsx";
import NoReceivedMail from "./components/Dashboard/Requests/NoReceivedMail.jsx";
import ReceivedMail from "./components/Dashboard/Requests/ReceivedMail.jsx";
import ReturningUserDialog from "./views/ReturningUserDialog.jsx";
import Documents from "./components/Dashboard/Documents.jsx";
import Resources from "./components/Dashboard/Resources.jsx";
import Contact from "./components/Dashboard/Contact.jsx";
import Partners from "./components/Dashboard/Partners.jsx";
import Feedback from "./components/Dashboard/Feedback.jsx";
import USAREURUpload from "./components/Dashboard/Requests/USAREURUpload.jsx";
import PCSOrdersUpload from "./components/Dashboard/Requests/PCSOrdersUpload.jsx";
import QueueSelectLocation from "./views/QueueSelectLocation.jsx";
import QueueFinalStage from "./views/QueueFinalStage.jsx";
import Service from "./views/Services/Service.jsx";
import ServiceType from "./components/Services/ServiceType.jsx";
import ServiceTypeInitial from "./components/Services/ServiceTypeInitial.jsx";
import ServiceTypeUpdate from "./components/Services/ServiceTypeUpdate.jsx";
import ServiceTypeDereg from "./components/Services/ServiceTypeDereg.jsx";
import DoDID from "./components/Dashboard/Requests/DoDID.jsx";
import MeansOfPayment from "./components/Dashboard/Requests/MeansOfPayment.jsx";
import PCSOrders from "./components/Dashboard/Requests/PCSOrders.jsx";
import PreviousRegistration from "./components/Dashboard/Requests/PreviousRegistration.jsx";
import USAREUR from "./components/Dashboard/Requests/USAREUR.jsx";
import CheckDocs4Services from "./views/CheckDocs4Services.jsx";
import TitleUpload from "./views/Services/TitleUpload.jsx";
import LienMemorandum from "./views/Services/LienMemorandum.jsx";
import HHGPaperworkUpload from "./views/Services/HHGPaperworkUpload.jsx";
import HHGPaperworkVerify from "./views/Services/HHGPaperworkVerify.jsx";
import ServicePathStart from "./views/Services/ServicePathStart.jsx";
import NewArrivalInitial from "./components/Dashboard/Requests/NewArrivalInitial.jsx";

// import KeycloakProvider from "./utils/KeycloakProvider";

export default function App() {
  // const wrapper = React.createRef();
  const router = createBrowserRouter([
    {
      path: "/",
      element: (
        <QueueThemeProvider>
          <LandingPage />
        </QueueThemeProvider>
      ),
    },
    {
      path: "/QueueIn",
      element: (
        <QueueThemeProvider>
          <QueueIn />
        </QueueThemeProvider>
      ),
    },
    // children: [
    //   {
    //     index: true,
    //     path: "/QueueIn/LocationSelection",
    //     element: <QueueSelectLocation />,
    //   },
    // ],

    {
      path: "QueueIn/LocationSelection",
      element: (
        <QueueThemeProvider>
          <QueueSelectLocation />
        </QueueThemeProvider>
      ),
    },
    {
      path: "QueueIn/FinalQueueIn",
      element: (
        <QueueThemeProvider>
          <QueueFinalStage />
        </QueueThemeProvider>
      ),
    },
    {
      path: "/Register",
      element: (
        <ServicePathThemeProvider>
          <UserRegistration />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/UserDashboard",
      element: (
        <UserDashboardThemeProvider>
          <UserDashboard />
        </UserDashboardThemeProvider>
      ),
      children: [
        {
          // TODO: FIX /USERDASHBOARD (W/O VEHICLES ISSUE)
          index: true,
          path: "/UserDashboard/vehicles",
          element: <UserVehicles />,
        },
        {
          path: "/UserDashboard/appointments",
          element: <Appointments />,
        },
        {
          path: "/UserDashboard/scheduleappointment",
          element: <ScheduleAppointment />,
        },
        {
          path: "/UserDashboard/requests",
          element: <RequestsPanel />,
        },
        {
          path: "/UserDashboard/documents",
          element: <Documents />,
        },
        {
          path: "/UserDashboard/resources",
          element: <Resources />,
        },
        {
          path: "/UserDashboard/contact",
          element: <Contact />,
        },
        {
          path: "/UserDashboard/partners",
          element: <Partners />,
        },
        {
          path: "/UserDashboard/feedback",
          element: <Feedback />,
        },
      ],
    },
    {
      path: "/CheckDocs4Services",
      element: (
        <ServicePathThemeProvider>
          <CheckDocs4Services />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/HHGShipping",
      element: (
        <ServicePathThemeProvider>
          <HHGShipping />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/WhichMethodUsed",
      element: (
        <ServicePathThemeProvider>
          <WhichMethodUsed />
        </ServicePathThemeProvider>
      ),
    },
    // {
    //   path: "/HowDidYouTransfer",
    //   element: (
    //     <ServicePathThemeProvider>
    //       <HowDidYouTransfer />
    //     </ServicePathThemeProvider>
    //   ),
    // },
    {
      path: "/ReceivedNotificationRequests",
      element: (
        <ServicePathThemeProvider>
          <ReceivedNotificationRequests />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/NoReceivedMail",
      element: (
        <ServicePathThemeProvider>
          <NoReceivedMail />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/ReceivedMail",
      element: (
        <ServicePathThemeProvider>
          <ReceivedMail />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/HHGClass1License",
      element: (
        <ServicePathThemeProvider>
          <HHGClass1License />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/LienMemorandum",
      element: (
        <ServicePathThemeProvider>
          <LienMemorandum />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/HHGPaperworkUpload",
      element: (
        <ServicePathThemeProvider>
          <HHGPaperworkUpload />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/HHGPaperworkVerify",
      element: (
        <ServicePathThemeProvider>
          <HHGPaperworkVerify />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "/DoDID",
      element: (
        <UserDashboardThemeProvider>
          <DoDID />
        </UserDashboardThemeProvider>
      ),
    },
    {
      path: "/MeansOfPayment",
      element: (
        <UserDashboardThemeProvider>
          <MeansOfPayment />
        </UserDashboardThemeProvider>
      ),
    },
    {
      path: "/PCSOrders",
      element: (
        <UserDashboardThemeProvider>
          <PCSOrders />
        </UserDashboardThemeProvider>
      ),
    },
    {
      path: "/PreviousRegistration",
      element: (
        <UserDashboardThemeProvider>
          <PreviousRegistration />
        </UserDashboardThemeProvider>
      ),
    },
    {
      path: "/USAREUR",
      element: (
        <UserDashboardThemeProvider>
          <USAREUR />
        </UserDashboardThemeProvider>
      ),
    },
    {
      path: "/TitleUpload",
      element: (
        <UserDashboardThemeProvider>
          <TitleUpload />
        </UserDashboardThemeProvider>
      ),
    },
    {
      path: "USAREURUpload",
      element: (
        <ServicePathThemeProvider>
          <USAREURUpload />
        </ServicePathThemeProvider>
      ),
    },
    {
      path: "PCSOrdersUpload",
      element: (
        <ServicePathThemeProvider>
          <PCSOrdersUpload />
        </ServicePathThemeProvider>
      ),
    },
    //TODO The backgrounds and the redux needs to be implemented
    {
      path: "/NewRequests",
      element: (
        ///do not change this from service path start please
        <QueueThemeProvider>
          <ServicePathStart />
        </QueueThemeProvider>
      ),
      children: [
        {
          index: true,
          element: (
            <QueueThemeProvider>
              <VRSRequestsGetStartedPage />
            </QueueThemeProvider>
          ),
        },
        {
          path: "/NewRequests/Splash-Page",
          element: (
            <QueueThemeProvider>
              <NewRequestsSplash />
            </QueueThemeProvider>
          ),
        },
        {
          path: "/NewRequests/Add-Vehicles",
          element: (
            <QueueThemeProvider>
              <RequestsNumberVehicles />
            </QueueThemeProvider>
          ),
        },
        {
          path: "/NewRequests/VehicleType",
          element: (
            <QueueThemeProvider>
              <MSFaskifneeded />
            </QueueThemeProvider>
          ),
        },
      ],
    },
    {
      path: "/EditProfile",
      element: (
        <QueueThemeProvider>
          <ReturningUserDialog />
        </QueueThemeProvider>
      ),
    },
    // {
    //   path: "/UserInfo",
    //   element: (
    //     <TurqdelightThemeProvider>
    //       <UserInfo />
    //     </TurqdelightThemeProvider>
    //   ),
    // },
    // { keep this for now
    //   path: "/ServicePathStart",
    //   element: (
    //     <ServicePathThemeProvider>
    //       <ServicePathStart />
    //     </ServicePathThemeProvider>
    //   ),
    // },
    {
      path: "/NewRequests/MSF1",
      element: (
        <QueueThemeProvider>
          <MSFverify />
        </QueueThemeProvider>
      ),
    },

    {
      path: "/MultipleServicesStart",
      element: (
        <ServicePathThemeProvider>
          <MultipleServicesStart />
        </ServicePathThemeProvider>
      ),
    },

    {
      path: "/Service",
      element: (
        <ServicePathThemeProvider>
          <Service />
        </ServicePathThemeProvider>
      ),

      children: [
        {
          index: true,
          element: <ServiceType />,
        },
        {
          path: "/Service/Initial",
          element: (
            <ServicePathThemeProvider>
              <ServiceTypeInitial />
            </ServicePathThemeProvider>
          ),
          //  #ff2600
          //  #ff2600   // FIXME ALERT #ff2600 IMPORTANT!: #ff2600HOW TO HANDLE THIS BEST - AS CHILDREN OR NEW VIEWS?#ff2600
          // children: [
          //   {
          //     index: true,
          //     path: "/Service/Initial/Arrival",
          //     element: (
          //       <ServicePathThemeProvider>
          //         <HowDidYouTransfer />
          //       </ServicePathThemeProvider>
          //     ),
          //   },
          //   {},
          // ],#ff2600
        },

        {
          path: "/Service/Update",
          element: (
            <ServicePathThemeProvider>
              <ServiceTypeUpdate />,
            </ServicePathThemeProvider>
          ),
        },
        {
          path: "/Service/Deregister",
          element: (
            <ServicePathThemeProvider>
              <ServiceTypeDereg />,
            </ServicePathThemeProvider>
          ),
        },
      ],
    },

    {
      path: "/Service/Arrival",
      element: (
        <ServicePathThemeProvider>
          <HowDidYouTransfer />
        </ServicePathThemeProvider>
      ),
      children: [
        {
          // TODO: FIX /USERDASHBOARD (W/O VEHICLES ISSUE)
          index: true,
          path: "/Service/Arrival",
          element: <NewArrivalInitial />,
        },
        {
          path: "/Service/Arrival/Shipped",
          element: <ReceivedNotificationRequests />,
        },

        {
          path: "/Service/Arrival/Mail",
          element: <NoReceivedMail />,
        },
        {
          path: "/Service/Arrival/ReceivedMail",
          element: <ReceivedMail />,
        },

        {
          path: "/Service/Arrival/HHG",
          element: <HHGShipping />,
        },

        // {
        //   path: "/Service/Arrival/Shipped",
        //   element:
        // },
      ],
    },
    // {
    //   // FIXME!
    //   // path = "Service/Initial/Service/Arrival" ? path = "Service/Arrival" : path= "Service/Arrival"},
    //   path: "Service/Arrival",
    //   element: (
    //     <ServicePathThemeProvider>
    //       <HowDidYouTransfer />
    //     </ServicePathThemeProvider>
    //   ),
    // },

    { path: "*", element: <Error404 /> },
  ]);

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Provider store={store}>
        <SnackbarProvider
          preventDuplicate
          maxSnack={5}
          action={(snackbarKey) => (
            <SnackbarCloseButton snackbarKey={snackbarKey} />
          )}
        >
          <RouterProvider router={router} />
        </SnackbarProvider>
      </Provider>
    </LocalizationProvider>
  );
}

function SnackbarCloseButton({ snackbarKey }) {
  const { closeSnackbar } = useSnackbar();
  return (
    <IconButton onClick={() => closeSnackbar(snackbarKey)}>
      <Close />
    </IconButton>
  );
}
