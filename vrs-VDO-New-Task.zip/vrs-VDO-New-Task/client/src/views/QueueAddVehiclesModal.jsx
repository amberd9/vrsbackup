import { IconButton, Paper, Modal } from "@mui/material";
import "../components/Services/walkthru.css";

import Box from "@mui/material/Box";

import RequestsNumberVehicles from "./NewRequests/RequestsNumberVehicles.jsx";

import { cancel } from "../imgs/index.js";

const QueueAddVehiclesModal = ({ open, handleClose }) => {
  // TODO: HIDE MY PROFILE VEHICLES FOR NONLOGGEDIN USERS ACCESSING THE QUEUE
  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          maxHeight: "90vw",
          overflowY: "auto",
        }}
      >
        <Box
          justifyContent="flex-end"
          sx={{
            border: "5px solid #a5c077",
            color: "##6A5B9B",
            mx: "auto",
            mt: 5,
            backgroundColor: "#1A1429",
            borderRadius: "12px",
          }}
          maxWidth={1100}
          className="upload"
        >
          <IconButton sx={{ ml: "93%" }} onClick={handleClose}>
            <img src={cancel} alt="cancel" height="40px" />
          </IconButton>
          <RequestsNumberVehicles />
        </Box>
      </Modal>
    </>
  );
};
export default QueueAddVehiclesModal;
