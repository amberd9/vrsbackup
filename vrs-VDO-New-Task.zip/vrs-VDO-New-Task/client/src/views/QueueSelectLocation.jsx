import {
  Stack,
  Checkbox,
  ListItemText,
  Typography,
  Button,
  Divider,
  Fab,
  Stepper,
  Step,
  StepLabel,
  IconButton,
  InputLabel,
  Icon,
} from "@mui/material";
import "../components/Services/walkthru.css";
import {
  btn_maps_hrs,
  circle_fab_blue,
  circle_fab_lightblue,
  svc_btn_green,
  svc_btn_purple,
  typ_roboto_header,
  typ_roboto_sub,
} from "../components/Services/WalkthruCSS.jsx";
import { Outlet, useNavigate } from "react-router-dom";
import MainHeaderServices from "../components/MainHeaderServices";
import LocationQueueInPage from "./LocationQueueInPage";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Chip from "@mui/material/Chip";
import { useState } from "react";
import {
  DoneOutlineRounded,
  Groups2Rounded,
  SkipPreviousRounded,
} from "@mui/icons-material";
import QueueAddVehiclesModal from "./QueueAddVehiclesModal.jsx";
import { astrooutoflaptop, hours, maps, queueInMain } from "../imgs/index.js";
import QueueSelectLocation from "./QueueSelectLocation.jsx";
import QueueInfoModal from "./QueueInfoModal.jsx";

const QueueLocation = () => {
  //State to see which Service is selected
  const [serviceCheckedIndex, setServiceCheckedIndex] = useState(null);
  // //State to see which Location is selected
  const [locationCheckedIndex, setLocationCheckedIndex] = useState(null);
  const [activeStep, setActiveStep] = useState(0);
  const navigate = useNavigate();
  const steps = ["Select Service", "Select Location", "Join Queue"];

  const handleNext = () => {
    if (steps.length - 1 !== activeStep) setActiveStep(activeStep + 1);
  };
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  const [multVehicleOpen, setMultVehicleOpen] = useState(false);
  //functions for selection list
  const ITEM_HEIGHT = 120;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4 + ITEM_PADDING_TOP,
        width: 650,
        background: "#111F4F",
        color: "#E7DEFF",
        borderRadius: 12,
        hover: "#001126",
        border: "solid px #DBEA97",
      },
    },
  };
  const [service, setService] = useState([]);
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setService(typeof value === "string" ? value.split(",") : value);
  };
  const names = ["Kapaun", "Vogelweh", "Stuttguart", "Sembach"];
  //  TODO: MAKE CHIPS DELETABLE const [chipData, setChipData] = useState([]);
  //   const handleDelete = (chipToDelete) => () => { setChipData((chips) =>chips.filter((chip) => chip.key !== chipToDelete.key));

  return (
    <>
      {/* <Maps />
      <Hours /> */}
      <QueueAddVehiclesModal
        open={multVehicleOpen}
        handleClose={() => setMultVehicleOpen(false)}
      />
      <Box
        flex={1}
        className="user_dashboard_page"
        sx={{
          "::-webkit-scrollbar-thumb": {
            background: "#0060A943",
          },
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <MainHeaderServices />
        <Stack>
          <Stepper activeStep={activeStep} alternativeLabel sx={{ my: 0.5 }}>
            {steps.map((step) => (
              <Step key={step}>
                <StepLabel>{step}</StepLabel>
              </Step>
            ))}
            {/* {activeStep === 0 && ({ serviceCheckedIndex = serviceCheckedIndex}; {setServiceCheckedIndex=setServiceCheckedIndex})}; */}
            {/* {(setActiveStep = 1)}
            {activeStep === 1} */}
            {/* && (
                <LocationQueueInPage
                locationCheckedIndex={locationCheckedIndex}
                setLocationCheckedIndex={setLocationCheckedIndex}
                />
              )} */}
            {/* {activeStep === 2} */}
            {/* // && <QueueDashboard /> */}
          </Stepper>
        </Stack>
        {/* </Box>
    </>
  );
}; 
export default QueueIn; */}
        <Stack>
          <Stack direction="row" py={2} justifyContent="space-evenly">
            <Box
              sx={{
                background: "#6A5B9B14",
                border: "solid 5px #3E3A51",
                borderRadius: 4,
                width: "800px",
              }}
            >
              <Box align="center">
                <Typography
                  fontSize={30}
                  fontFamily="Roboto Condensed"
                  py={1}
                  flexShrink="shrink"
                  px={20}
                >
                  SELECT LOCATION
                </Typography>

                <FormControl
                  sx={{
                    display: "flex",
                    m: 1,
                    width: 650,
                    background: "#D3EF4B87",
                    borderColor: "#102759",
                    borderWidth: 5,
                    borderStyle: "solid",
                    borderRadius: 4,
                  }}
                >
                  <InputLabel id="label"></InputLabel>
                  <Select
                    sx={{ display: "flex" }}
                    multiple
                    open={open}
                    onOpen={handleOpen}
                    onClose={handleClose}
                    autoWidth
                    value={service}
                    onChange={handleChange}
                    defaultValue={"Kapaun"}
                    defaultChecked={"Kapaun"}
                    labelId="label"
                    id="select"
                    renderValue={(selected) => (
                      <Box
                        sx={{
                          display: "flex",
                          flexWrap: "wrap",
                          gap: 1,
                          borderRadius: 12,
                        }}
                      >
                        {selected.map((value) => (
                          <Chip
                            key={value}
                            label={value}
                            variant="outlined"
                            //   TODO: MAKE CHIPS DELETABLE onDelete={handleDelete(value)}
                            sx={{
                              background: "#0060A985",

                              color: "#F1ECF4",
                              border: "solid 2px #111F4F",

                              fontFamily: "Roboto Condensed",
                              fontSize: "18px",
                              display: {
                                filter: "drop-shadow(1px 1px 0.5px  #a5c07790)",
                              },
                            }}
                          />
                        ))}
                      </Box>
                    )}
                    MenuProps={MenuProps}
                  >
                    {names.map((name) => (
                      <MenuItem key={name} value={name}>
                        <Checkbox
                          sx={{ background: "#00203F30", color: "#6BAEFF" }}
                          checked={service.indexOf(name) > -1}
                        />
                        <ListItemText primary={name} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>{" "}
              <Box
                component="img"
                src={astrooutoflaptop}
                alt="astrocomputer"
                height="350px"
                sx={{ position: "absolute", bottom: "30%", left: "28%" }}
              />
            </Box>
            <Box
              align="center"
              sx={{
                background: "#1F1E3174",
                border: "solid 7px #141523",
                borderRadius: 4,
                width: "1400px",
              }}
            >
              <Stack alignItems="center" justifyContent="center">
                <Stack
                  direction="row"
                  alignItems="center"
                  sx={{
                    my: 5,
                    background: "#10275960",
                    border: "solid 3px #6D748D",
                    borderRadius: 4,
                    p: 4,
                    width: "1100px",
                  }}
                >
                  <Stack alignItems="center">
                    <Typography sx={{ ...typ_roboto_header }}>
                      [WALK-INS ALLOWED - MUST QUEUE]
                    </Typography>
                    <Typography my={4} sx={{ ...typ_roboto_sub }}>
                      LOCATION DETAILS
                    </Typography>
                    <Stack direction="row">
                      <Button
                        type="submit"
                        sx={btn_maps_hrs}
                        onClick={() => console.log("maps will open")}
                      >
                        <Box
                          component="img"
                          padding={1}
                          src={maps}
                          alt="test"
                        />
                        MAPS
                      </Button>
                      <Box width={20} />
                      <Button
                        type="submit"
                        sx={btn_maps_hrs}
                        onClick={() => console.log("hours will open")}
                      >
                        <Box
                          component="img"
                          padding={1}
                          height={60}
                          src={hours}
                          alt="test"
                        />
                        HOURS
                      </Button>
                    </Stack>
                    <Divider
                      width="2px"
                      orientation="vertical"
                      color="#D2F041"
                    />
                  </Stack>

                  <Box
                    ml="7%"
                    sx={{
                      background: "#645C7F44",
                      border: "solid 3px #0060A9",
                      borderRadius: 4,
                      height: "250px",
                      width: "400px",
                    }}
                  >
                    <Typography sx={typ_roboto_sub}>QUEUE STATUS</Typography>
                    <Stack direction="row" justifyContent="space-evenly">
                      <Box>
                        <Fab variant="circular" sx={circle_fab_blue}>
                          12
                        </Fab>
                        <Typography>
                          <br /> IN QUEUE
                        </Typography>
                      </Box>
                      <Box>
                        <Fab variant="circular" sx={circle_fab_lightblue}>
                          220
                        </Fab>
                        <Typography>
                          <br />
                          WAIT TIME
                        </Typography>
                      </Box>
                    </Stack>
                  </Box>
                </Stack>
                <Stack
                  direction="row"
                  justifyContent="space-around"
                  alignItems="center"
                  spacing={8}
                >
                  <Box
                    sx={{
                      background: "#1E2F5174",
                      border: "solid 4px #6D748D70",
                      borderRadius: 4,
                      height: "250px",
                      width: "500px",
                    }}
                  >
                    <Typography my={4} sx={{ ...typ_roboto_sub }}>
                      DO YOU HAVE EVERYTHING YOU NEED?
                    </Typography>
                    <Button
                      type="submit"
                      size="large"
                      minHeight={90}
                      startIcon={<DoneOutlineRounded />}
                      onClick={() => navigate("/CheckDocs4Services")}
                      sx={{ ...svc_btn_green }}
                    >
                      DOCUMENTS CHECK
                    </Button>
                  </Box>
                  <Box
                    sx={{
                      background: "#102c5b80",
                      border: "solid 4px #7690bc80",
                      borderRadius: 4,
                      height: "250px",
                      width: "500px",
                    }}
                  >
                    <Typography my={4} sx={{ ...typ_roboto_sub }}>
                      PREFER TO PLAN AHEAD?
                    </Typography>
                    <Button
                      type="submit"
                      startIcon={<Groups2Rounded />}
                      onClick={() => navigate("/MultipleServicesStart")}
                      sx={{ borderRadius: 4, height: 58 }}
                    >
                      MAKE APPOINTMENT
                    </Button>
                  </Box>
                </Stack>
              </Stack>
              <Box align="right" mx={5} my={5}>
                <Button
                  // onClick={handleNext}
                  onClick={() => navigate("/QueueIn/FinalQueueIn")}
                  // TODO: SYNTAX ON MULT PROPS AGAIN
                  // sx={[{ svc_btn_purple }, { borderColor: "#daf349" }]}
                  sx={svc_btn_purple}
                >
                  {activeStep === steps.length - 1 ? "Finish" : "Next"}
                </Button>
              </Box>
            </Box>
          </Stack>
          <IconButton disabled={activeStep === 0} onClick={handleBack}>
            <SkipPreviousRounded
              sx={{
                position: "absolute",
                left: "5%",
                bottom: 50,
                fontSize: "100px",
                color: "#daf349",
              }}
            />
          </IconButton>
        </Stack>
      </Box>
    </>
  );
};
export default QueueLocation;
