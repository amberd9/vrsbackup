import {
  Box,
  Chip,
  Divider,
  Stack,
  Typography,
  Radio,
  Button,
} from "@mui/material";
import * as React from "react";
import { FixedSizeList } from "react-window";
import { CheckCircle, PostAdd } from "@mui/icons-material";
const ServiceQueueInPage = ({
  serviceCheckedIndex,
  setServiceCheckedIndex,
}) => {
  //TODO: Add Image queueInMain.png
  const services = [
    "Initial Registration",
    "Transfer from DOD ID",
    "Expired Registration",
    "Change of Information",
    "Lost/Stolen Plates",
  ];
  return (
    <Stack direction={"row"} spacing={3}>
      <Box
        sx={{
          width: "40%",
          border: "2px solid lightblue",
          mb: 5,
          backgroundColor: "#1F1E31",
        }}
      >
        <Typography
          variant="h3"
          sx={{
            textAlign: "center",
            color: "#fff",
            backgroundColor: "#1B5F97",
          }}
        >
          Service Selection
        </Typography>
        <Divider />
        <FixedSizeList
          height={300}
          width="100%"
          itemSize={50}
          itemCount={services.length}
        >
          {({ index, style }) => (
            <Stack alignSelf="start" style={style} direction="row">
              <Radio
                checked={serviceCheckedIndex === index}
                onChange={(event) => setServiceCheckedIndex(index)}
              />
              <Typography variant="h6" sx={{ fontStyle: "italic" }}>
                {services[index]}
              </Typography>
            </Stack>
          )}
        </FixedSizeList>
      </Box>
      <Stack
        padding={5}
        sx={{
          border: "2px solid lightblue",
          backgroundColor: "#1F1E31",
        }}
      >
        <Stack spacing={3}>
          <Stack
            direction={"row"}
            spacing={1}
            sx={{
              borderRadius: 3,
              border: "2px solid lightblue",
              p: 3,
            }}
          >
            <Stack flex={1} spacing={3}>
              <Typography variant="h4"> [Selected Service]</Typography>
              <Typography>Walk-Ins Allowed ::: OR ::: Must Queue</Typography>
            </Stack>
            <Divider
              orientation="vertical"
              variant="middle"
              flexItem
              sx={{ m: 1 }}
            />
            <Stack
              direction={"row"}
              justifyContent={"space-around"}
              spacing={5}
            >
              <Stack spacing={3}>
                <Chip
                  label="10 people"
                  variant="outlined"
                  sx={{ fontSize: "1.5rem" }}
                />

                <Typography variant="h4">Position in Queue</Typography>
              </Stack>
              <Stack spacing={3}>
                <Chip
                  label="50 mins"
                  variant="outlined"
                  sx={{ fontSize: "1.5rem" }}
                />
                <Typography variant="h4">Wait Time</Typography>
              </Stack>
            </Stack>
          </Stack>
          <Stack direction={"row"} spacing={3}>
            <Stack
              sx={{
                borderRadius: 3,
                border: "2px solid lightblue",
                p: 3,
              }}
            >
              <Typography textAlign={"center"} variant="h5">
                Do you have everything you need?
              </Typography>
              <Button
                sx={{
                  backgroundColor: "#D3E4FF",
                  color: "#000",
                  borderRadius: 3,
                }}
                endIcon={<CheckCircle />}
              >
                Documents Check
              </Button>
            </Stack>
            <Stack
              sx={{
                borderRadius: 3,
                border: "2px solid lightblue",
                p: 3,
              }}
            >
              <Typography variant="h5" textAlign={"center"}>
                Prefer to plan ahead?
              </Typography>
              <Button
                sx={{
                  backgroundColor: "#1B5F97",
                  color: "#fff",
                  borderRadius: 3,
                }}
                endIcon={<PostAdd />}
              >
                Make an appointment
              </Button>
            </Stack>
          </Stack>
        </Stack>
      </Stack>
    </Stack>
  );
};

export default ServiceQueueInPage;
