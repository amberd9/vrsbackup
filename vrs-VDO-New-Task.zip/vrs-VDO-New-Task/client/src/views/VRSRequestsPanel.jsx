import { Box, Button, Dialog, Grid, Stack, Typography } from "@mui/material";
import React, { useState } from "react";
import {
  ClosedRequest,
  OpenRequest,
  ReturnedRequest,
  ClosedRequestAstronaut,
  OpenRequestAstronaut,
  ReturnedRequestAstronaut,
} from "../imgs/RequestPageImages/index.js";
import { Close } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

const VRSRequestsPanel = () => {
  const [openDialog, setOpenDialog] = useState(
    <OpenRequestDialog onClose={() => setOpenDialog(null)} />
  );

  const handleImageClick = (Dialog) => {
    setOpenDialog(Dialog);
  };

  const handleCloseDialog = () => {
    setOpenDialog(null);
  };
  const navigate = useNavigate();

  return (
    <div>
      <Stack spacing={2}>
        {/* <Button
          sx={{
            width: { lg: "200px", xs: "60px" },
          }}
        >
          Instructions
        </Button> */}
        <Button
          sx={{
            width: { lg: "250px", xs: "100px" },
          }}
          onClick={() => navigate("/NewRequests")}
        >
          New Requests
        </Button>
        <img
          src={OpenRequest}
          height={150}
          width={150}
          onClick={() =>
            handleImageClick(<OpenRequestDialog onClose={handleCloseDialog} />)
          }
        />
        <img
          src={ReturnedRequest}
          height={150}
          width={150}
          onClick={() =>
            handleImageClick(
              <ReturnedRequestDialog onClose={handleCloseDialog} />
            )
          }
        />
        <img
          src={ClosedRequest}
          height={150}
          width={150}
          onClick={() =>
            handleImageClick(
              <ClosedRequestDialog onClose={handleCloseDialog} />
            )
          }
        />
      </Stack>
      <Dialog open={Boolean(openDialog)} onClose={handleCloseDialog}>
        <Box>{openDialog}</Box>
      </Dialog>
    </div>
  );
};

const OpenRequestDialog = ({ onClose }) => {
  return (
    <Stack
      alignItems="center"
      sx={{
        borderRadius: 2,
        border: "2px solid lightblue",
        pb: 2,
      }}
    >
      <img src={OpenRequestAstronaut} height={250} width={400} />
      <Typography
        variant="h4"
        sx={{ textAlign: "center", width: "100%", backgroundColor: "#1A1623" }}
      >
        Open Requests
      </Typography>
      <Box
        sx={{
          borderRadius: 2,
          border: "2px solid lightblue",
          padding: 3,
        }}
      >
        <Typography>Request opened:[Pass in Date]</Typography>
        <Typography>Service [Registration Renewal]</Typography>
        <Typography>Outcome:[#Pass in variable for outcome]</Typography>
      </Box>
      <Button sx={{ mt: 2 }} onClick={onClose}>
        Close
      </Button>
    </Stack>
  );
};

const ReturnedRequestDialog = ({ onClose }) => {
  return (
    <Stack
      alignItems="center"
      sx={{
        borderRadius: 2,
        border: "2px solid lightblue",
        pb: 2,
      }}
    >
      <img src={ReturnedRequestAstronaut} height={250} width={400} />
      <Typography
        variant="h4"
        sx={{ textAlign: "center", width: "100%", backgroundColor: "#1A1623" }}
      >
        Returned Requests
      </Typography>
      <Box
        sx={{
          borderRadius: 2,
          border: "2px solid lightblue",
          padding: 3,
        }}
      >
        {" "}
        <Typography>Request opened:[Pass in Date]</Typography>
        <Typography>Request Returned:[Pass in Date]</Typography>
        <Typography>Service [Registration Renewal]</Typography>
        <Typography>Outcome:[#Pass in variable for outcome]</Typography>
      </Box>
      <Button sx={{ mt: 2 }} onClick={onClose}>
        Close
      </Button>
    </Stack>
  );
};

const ClosedRequestDialog = ({ onClose }) => {
  return (
    <Stack
      alignItems="center"
      sx={{
        borderRadius: 2,
        border: "2px solid lightblue",
        pb: 2,
      }}
    >
      <img src={ClosedRequestAstronaut} height={250} width={400} />
      <Typography
        variant="h4"
        sx={{ textAlign: "center", width: "100%", backgroundColor: "#1A1623" }}
      >
        Closed Requests
      </Typography>
      <Box
        sx={{
          borderRadius: 2,
          border: "2px solid lightblue",
          padding: 3,
        }}
      >
        <Typography>Request opened:[Pass in Date]</Typography>
        <Typography>Request closed:[Pass in Date]</Typography>
        <Typography>Service [Registration Renewal]</Typography>
        <Typography>Outcome:[#Pass in variable for outcome]</Typography>
      </Box>
      <Button sx={{ mt: 2 }} onClick={handleCloseDialog}>
        Close
      </Button>
    </Stack>
  );
};

export default VRSRequestsPanel;
