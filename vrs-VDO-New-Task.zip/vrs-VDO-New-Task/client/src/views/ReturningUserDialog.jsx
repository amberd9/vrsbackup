import {
  Typography,
  Stack,
  Button,
  TextField,
  Dialog,
  Skeleton,
  IconButton,
} from "@mui/material";
import CancelPresentationIcon from "@mui/icons-material/CancelPresentation";
import { useGSAP } from "@gsap/react";
import { useState, useRef } from "react";

const ReturningUserDialog = ({
  returningUserDialogOpen,
  setReturningUserDialogOpen,
}) => {
  const [closeRequested, setCloseRequested] = useState(false);
  const containerRef = useRef(null);
  // https://gsap.com/resources/React/
  // useGSAP context provider that handles DOM cleanup
  // for the animation when component unmounts
  useGSAP(
    () => {
      // animate modal when close button is clicked
      if (closeRequested) {
        // animate astronaut component into the sky
        tl.to(".astronaut", {
          y: -800,
          opacity: 0,
        });
        // animate '.dialog' component to the values defined in the object
        tl.to(".dialog", {
          opacity: 0,
          // close modal after animation is complete
          onComplete: () => setReturningUserDialogOpen(false),
        });
      }
    }, // useEffect dependency (useGSAP is a wrapper around useEffect)
    { dependencies: [returningUserDialogOpen, closeRequested] }
  );
  const skeleton = true;
  const fields = [
    "DODID (EDIPI)",
    "DEROS",
    "Full Name",
    "Last Name",
    "Email",
    "Employment Type",
    "Affiliation",
    "Organization",
    "MAJCOM",
    "Military Rank",
  ];

  return (
    <Dialog open={returningUserDialogOpen} className="dialog" fullScreen>
      <Stack justifyContent="center" sx={styles.container}>
        <IconButton
          sx={{
            position: "absolute",
            top: "5px",
            right: "5px",
          }}
          onClick={() => setCloseRequested(true)}
        >
          <CancelPresentationIcon />
        </IconButton>
        <Stack
          direction="row"
          justifyContent="center"
          justifySelf="center"
          sx={{ p: "1rem", height: "100%" }}
        >
          <Stack justifyContent="ceneter" className="astronaut">
            <img
              src="./coozy_astronaut.png"
              style={{
                maxHeight: "100%",
                maxWidth: "100%",
              }}
            />
          </Stack>
          <Stack elevation={0} sx={styles.card}>
            <Typography
              sx={{
                textAlign: "center",
                m: "1rem",
                fontSize: "1.2rem",
                fontStyle: "italic",
              }}
            >
              Please verify that your profile information is correct.
            </Typography>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gridTemplateRows: "repeat(5, 1fr)",
              }}
            >
              {!skeleton &&
                fields.map((field) => {
                  return (
                    <Stack sx={{ minHeight: "90px" }}>
                      <Typography
                        style={{ marginLeft: "1rem", fontSize: ".8rem" }}
                      >
                        {field}
                      </Typography>
                      <TextField
                        InputProps={{
                          sx: {
                            borderRadius: "20px",
                            backgroundColor: "#65666F",
                          },
                        }}
                        sx={{
                          alignSelf: "center",
                          width: "100%",
                          padding: ".5rem",
                        }}
                      />
                    </Stack>
                  );
                })}
              {skeleton &&
                fields.map((field) => {
                  return (
                    <Stack sx={{ minHeight: "90px" }}>
                      <Typography
                        style={{ marginLeft: "1rem", fontSize: ".8rem" }}
                      >
                        {field}
                      </Typography>
                      <Skeleton
                        width="90%"
                        height="100%"
                        sx={{
                          alignSelf: "center",
                          padding: ".5rem",
                        }}
                      />
                    </Stack>
                  );
                })}
            </div>
            <Stack direction="row" justifyContent="flex-end" m="2rem">
              <Typography
                sx={{
                  alignSelf: "center",
                  mr: "1rem",
                  fontSize: "1.5rem",
                  fontStyle: "italic",
                }}
              >
                Everything Look Good?
              </Typography>
              <Button
                size="small"
                variant="contained"
                sx={styles.button}
                onClick={() => setCloseRequested(true)}
              >
                Continue
              </Button>
            </Stack>
          </Stack>
        </Stack>
      </Stack>
    </Dialog>
  );
};

const styles = {
  card: {
    height: "fit-content",
    width: "60%",
    alignSelf: "center",
    padding: "1rem",
    backgroundColor: "#221E24",
  },
  container: {
    maxHeight: "100%",
    width: "100%",
    position: "relative",
    justifyContent: "space-around",
    paddingTop: "2rem",
  },
  button: {
    fontSize: ".8rem",
  },
};

export default ReturningUserDialog;
