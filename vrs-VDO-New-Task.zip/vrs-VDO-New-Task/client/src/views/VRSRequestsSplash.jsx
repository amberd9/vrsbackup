import {
  Stack,
  Button,
  Typography,
  Dialog,
  DialogContent,
  DialogActions,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  IconButton,
} from "@mui/material";
import React, { useState } from "react";
import { uploadcancel } from "../imgs";

const VRSRequestsSplash = () => {
  const [open, setOpen] = useState(false);
  const [activeStep, setActiveStep] = React.useState(0);
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  const handleComplete = () => {
    setOpen(false);
    setActiveStep(0);
  };
  const steps = [
    {
      label: "VRS Requests",
      description: (
        <Typography component={"span"}>
          Use this section to manage your appointment requests. <br />
          Before you can schedule an appointment, VRS needs to make sure that
          you have all the correct paperwork.
          <br />
          Select "NEW REQUEST" to get started! <br />
          You may make edits and respond to requests you have already created
          right in your dashboard.
        </Typography>
      ),
    },
    {
      label: "Appointment Scheduling",
      description: (
        <Typography component={"span"}>
          VRS must verify that all required paperwork is complete & accurate.
          <br /> The submission process is easy & helps guarantee a successful
          visit. <br />
          Please check that your vehicle information is updated in your profile.{" "}
          <br />
          This will help complete the process faster.
          <br />
          Be sure to update any personal information (i.e. Name, Rank, DEROS) in
          your "EDIT PROFILE" settings.
        </Typography>
      ),
    },
    {
      label: "Starting a New Request",
      description: (
        <Typography component={"span"}>
          To begin, select "NEW REQUEST" and follow the prompts. <br />
          You may also continue with previously started requests.
          <br />
          You can review & correct any requests that are returned.
          <br />
          Responses to requests will appear as notifications in your User drawer
          & be sent via e-mail.
        </Typography>
      ),
    },
    {
      label: "Checking New Requests/Appointments",
      description: (
        <Typography component={"span"}>
          Once VRS approves your paperwork you may schedule an appointment in
          the “Appointments” tab.
          <br />
          VRS encourages you to plan ahead and schedule an appointment for any
          service with us.
          <br />
          Please allow up to 72 hours for VRS to respond to and approve
          requests.
        </Typography>
      ),
    },
  ];
  return (
    <>
      <Button
        size="small"
        color="tertiary"
        sx={{
          alignSelf: "flex-start",
          minWidth: "170px",
          fontSize: "19px",
          fontWeight: "Medium",
          fontFamily: "Roboto Condensed",
          p: 0.2,
          mt: 2,
          mx: 2,
        }}
        onClick={() => setOpen(true)}
      >
        Instructions
      </Button>
      <Dialog open={open} maxWidth="lg">
        <DialogContent>
          <Stack direction="row" justifyContent="space-between">
            <Typography
              textAlign={"left"}
              sx={{
                fontSize: { lg: "32px", xs: "16px" },
              }}
            >
              Welcome to VRS Requests !
            </Typography>
            <IconButton onClick={() => setOpen(false)}>
              <img src={uploadcancel} alt="cancel" height="40px" />
            </IconButton>
          </Stack>
          <Stepper activeStep={activeStep} orientation="vertical">
            {steps.map((step, index) => (
              <Step key={index}>
                <StepLabel>{step.label}</StepLabel>
                <StepContent>
                  <Typography
                    textAlign={"left"}
                    sx={{
                      fontSize: { lg: "20px", xs: "10px" },
                    }}
                  >
                    {step.description}
                  </Typography>
                </StepContent>
              </Step>
            ))}
          </Stepper>
        </DialogContent>
        <DialogActions>
          {activeStep === steps.length - 1 ? (
            <>
              <Button disabled={activeStep === 0} onClick={handleBack}>
                Back
              </Button>
              <Button onClick={handleComplete}>Continue</Button>{" "}
            </>
          ) : (
            <>
              <Button disabled={activeStep === 0} onClick={handleBack}>
                Back
              </Button>
              <Button variant="contained" onClick={handleNext}>
                Next
              </Button>
              )
            </>
          )}
        </DialogActions>
      </Dialog>
    </>
  );
};

export default VRSRequestsSplash;
