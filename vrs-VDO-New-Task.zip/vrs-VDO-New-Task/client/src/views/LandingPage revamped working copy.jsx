import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Grid,
  IconButton,
  Stack,
  Typography,
  useMediaQuery,
} from "@mui/material";
import NewUserDialog from "./NewUserDialog.jsx";
import ReturningUserDialog from "./ReturningUserDialog.jsx";
import LandingNavBar from "../components/navBars/LandingPageNav.jsx";
import { useNavigate } from "react-router-dom";
import {
  ArrowDownwardRounded,
  ExpandMore,
  Facebook,
  FormatLineSpacing,
  Map,
  SpaceBar,
} from "@mui/icons-material";
import {
  eightsix,
  fivesixnine,
  sword,
  usag,
  vehiclelanding,
} from "../imgs/index.js";
//TODO: work on view for smaller screens also when navbar is hit it scrolls to each portion
import {
  btn_maps_hrs,
  typ_fira_subheader,
  typ_fira_title,
} from "../components/Services/WalkthruCSS.jsx";

///FIXME TODO: CLASS SET UP FOR REWORKING OF BACKGROUND SETUP.
// [class^="bg_"] {
//   min-height: 220vh;
//   background-repeat: repeat-y, no-repeat, repeat-y, no-repeat;
//   background-size: 100%;
//   background-position-y: top, center, center, bottom;
// }

// .bg_landing_page {
//   background: url("./imgs/LandingPageImages/stars2.png"),
//     linear-gradient(
//       rgba(9, 11, 27, 0.6) 15%,
//       rgba(1, 10, 53, 0.4),
//       rgba(37, 51, 122, 0.733),
//       rgba(121, 18, 64, 0.6)
//     ),
//     url("./imgs/LandingPageImages/stars3.png"),
//     url("./imgs/LandingPageImages/vehiclelanding.webp");
//   position: relative, static, relative, sticky;
//   background-size: contain;
//   background-position-y: bottom;
//   max-width: 100vw;

export default function LandingPage() {
  const navigate = useNavigate();
  const isLargeScreen = useMediaQuery("(min-width:1000px)");

  // TODO: fix sticky buttons for LandingNavBar; make anchors
  return (
    <>
      {/* <Stack className="bg_landing_page" pb={2}> */}

      <Grid
        className="bg_landing_page sticky"
        container
        justifyContent="space-between"
        rowGap={10}
        mb={0}
        zIndex={1300}
      >
        {" "}
        <Grid item>
          <Stack
            direction="row"
            className="bg_landing_page sticky"
            pb={2}
            sx={{ zIndex: 2300 }}
          >
            <LandingNavBar />
            <img src={eightsix} height={100} />
            <img src={fivesixnine} height={100} />
            <img src={sword} height={100} />
            <img src={usag} height={100} />
            {/* </Stack> */}{" "}
            <Stack
              align="center"
              justifyContent="center"
              alignItems="flex-start"
            >
              {/* <Box > */}
              <Typography textAlign="center">
                Welcome!
                <br /> <br />
                Please Sign-in to continue.
              </Typography>
              <ExpandMore sx={{ fontSize: 120, color: "#ff2d46" }} />
              {/* </Box> */}
              {/* <img className="sticky" src={vehiclelanding} width="100%" /> */}
            </Stack>
          </Stack>
        </Grid>
        <Grid item xs={12}>
          <Stack spacing={3} sx={{ alignItems: "center" }}>
            <Typography textAlign="center">
              Welcome!
              <br /> <br />
              Please Sign-in to continue.
            </Typography>
            <ExpandMore sx={{ fontSize: 120, color: "#ff2d46" }} />
            <Typography sx={typ_fira_title}>
              Register for an account with Kapaun Vehicle Registration. <br />{" "}
            </Typography>
            <Typography
              sx={{
                ...typ_fira_subheader,
                fontStyle: "italic",
                textAlign: "center",
              }}
            >
              {"\u25CF\u0020"}
              Manage and track services for each of your vehicles. <br />
              {"\u25CF\u0020"}
              Utilize planning tools and access vehicle resources. <br />
              {"\u25CF\u0020"}
              Schedule appointments and use our Queue-In system to meet all your
              vehicle needs.
            </Typography>
            <Button onClick={() => navigate("/UserDashboard/vehicles")}>
              Log In
            </Button>
            <Box>
              <Typography variant="h6" color="#C5EDFF" align="center">
                New User?
              </Typography>
              <Button onClick={() => setNewUserDialogOpen(true)}>
                Register
              </Button>
            </Box>
          </Stack>
        </Grid>
        <Grid
          item
          xs={6}
          sx={{ p: 3, borderRadius: 12, border: "3px solid lightblue" }}
        >
          <Stack spacing={4}>
            <Typography variant="h4" align="center">
              ABOUT US
            </Typography>
            <Typography color="text.tan">
              <b>MISSION:</b> Support and provide USAREUR vehicle
              registration/de-registration services for all SOFA affiliated
              personnel within the KMC area to include Army Kasernes, Air Base &
              Stations, GSUs and NATO members.
            </Typography>
            <Typography color="text.tan">
              The Vehicle Processing Center consists of three SEPARATE entities:
              <br />
              <br />
              <Typography component="span" color="text.lightblue">
                Vehicle Registration - 569th USFPS
                <br />
                <br />
                International Auto Logistics - Shipping office
                <br />
                <br />
                86th Kapaun Vehicle Safety Inspection - 86th VRS.
              </Typography>
              <br />
              <br />
              VRS is an appointment-based system and provides queue-in services
              on an emergency basis. The queue-in system is first come, first
              serve and only processes a handful of people each day for a select
              number of services. As such, we highly encourage that you create
              an account and schedule an appointment with us.
              <br />
              <br />
              Please keep in mind that Vehicle Registration handles hundreds of
              customers a day so we apologize if we are unable to answer the
              phone when you call. We are currently assisting customers at our
              desks.
            </Typography>
            <Box align="right">
              <Button
                variant="text"
                sx={{ borderWidth: 0, fontWeight: "light" }}
                color="secondary"
              >
                CONTACT US
              </Button>
            </Box>
          </Stack>
        </Grid>
        <Grid
          item
          xs={6}
          sx={{ p: 3, borderRadius: 12, border: "3px solid #C5EDFF" }}
        >
          <Typography fontFamily="Fira Sans Extra Condensed" align="center">
            Social Media
          </Typography>
          <Stack spacing={3} alignItems="center" justifyContent="center">
            <IconButton
              onClick={() => window.open("https://Facebook.com", "_blank")}
            >
              <Facebook sx={{ fontSize: 72 }} />
            </IconButton>
          </Stack>
        </Grid>
        <Grid
          item
          xs={12}
          p={5}
          sx={{
            textAlign: "center",
            p: 3,
            borderRadius: 12,
            border: "3px solid lightblue",
          }}
        >
          <Typography variant="h4" mb={3}>
            PARTNERS & RELATED SERVICE PROVIDERS
          </Typography>
          <Typography fontSize="22px" py={0.5}>
            Private and Non-Military Providers are not endorsed by the 569th or
            Vehicle Registration.
          </Typography>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER1"
            >
              <Typography>INTERNATIONAL AUTO LOGISTICS IAL SHIPPING</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                Global Auto Logistics
                <br />
                Kapaun AS, Bldg 2806
                <br />
                Hours: 0800-1600 Monday - Friday
                <br />
                Commercial: +49 (0) 631 -3579-0088
                <br />
                DSN: 489-7750
                <br />
                Kaiserslautern.VPC@ialpov.us
                <br />
                <a href="www.pcsmypov.com" style={{ color: "white" }}>
                  www.pcsmypov.com
                </a>
              </Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER2"
            >
              <Typography>VEHICLE INSPECTION</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                Global Auto Logistics
                <br />
                Kapaun AS, Bldg 2806
                <br />
                Hours: 0800-1600 Monday - Friday
                <br />
                Commercial: +49 (0) 631 -3579-0088
                <br />
                DSN: 489-7750
                <br />
                Kaiserslautern.VPC@ialpov.us
                <br />
                <a href="www.pcsmypov.com" style={{ color: "white" }}>
                  www.pcsmypov.com
                </a>
              </Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER3"
            >
              <Typography>RAMSTEIN CUSTOMS OFFICE</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography></Typography>
            </AccordionDetails>
          </Accordion>{" "}
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER4"
            >
              <Typography>RAMSTEIN HOUSEHOLD GOODS</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography></Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER5"
            >
              <Typography>RAMSTEIN LEGAL OFFICE</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography> LEGAL INFO</Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ExpandMore />}
              aria-label="Expand"
              aria-controls="-content"
              id="-header"
            >
              <Typography></Typography>
            </AccordionSummary>
            <AccordionDetails></AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER6"
            >
              <Typography>RAMSTEIN MSF</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography></Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER7"
            >
              <Typography>RAMSTEIN JUNKYARD</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>INFO</Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER8"
            >
              <Typography>RAMSTEIN DEALERSHIP</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography></Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="FIRA SANS Extra Condensed"
              id="PARTNER9"
            >
              <Typography>RAMSTEIN LEMON LOT/SALES</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>INFO</Typography>
            </AccordionDetails>
            {/* TODO: OTHER PARTNERS AND SERVICES NEEDED (Find information) */}
          </Accordion>
        </Grid>
        <Grid
          item
          xs={6}
          sx={{ p: 3, border: "3px solid lightblue", borderRadius: 12 }}
        >
          <Stack spacing={1}>
            <Typography
              color="text.white"
              sx={{ textAlign: isLargeScreen ? "" : "center" }}
            >
              WHAT WE OFFER
            </Typography>
            <Typography sx={{ textAlign: isLargeScreen ? "" : "center" }}>
              INSPECTION PREP CHECKLIST
            </Typography>
            <Button onClick={() => navigate("/CheckDocs4Services")}>
              INSPECTION PREP CHECKLIST
            </Button>

            <Typography sx={{ textAlign: isLargeScreen ? "" : "center" }}>
              PDF GUIDE
            </Typography>
            <Button
              onClick={() =>
                window.open("./Vehicle_Registration_pdf.pdf", "_blank")
              }
            >
              PDF GUIDE
            </Button>
          </Stack>
        </Grid>
        <Grid
          item
          xs={6}
          sx={{
            border: "3px solid lightblue",
            borderRadius: 12,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Stack direction={"row"} spacing={3}>
            <Button onClick={() => navigate("/QueueIn")}>QUEUE-IN</Button>
            <Button sx={btn_maps_hrs} endIcon={<Map />}>
              Maps
            </Button>
          </Stack>
        </Grid>
        <Grid
          item
          xs={12}
          sx={{ p: 3, borderRadius: 12, border: "3px solid lightblue" }}
        >
          <Stack
            direction="row"
            sx={{ justifyContent: "center", alignItems: "center" }}
          >
            <Stack>
              <Typography
                color="#EFBAC5"
                fontFamily="Roboto Condensed"
                textAlign="center"
              >
                <b> Contact Us </b>
                <br />
                569th USFPS <br /> Vehicle Registration <br />
                Ramstein Air Base
                <br />
                HOURS
                <br />
                Emailing our org. box is the best way to contact us: <br />
                569USFPS.S5BV.VehicleRegistration@us.af.mil
                <br />
                Phone
                <br />
                DSN
              </Typography>
            </Stack>
          </Stack>
        </Grid>
      </Grid>
      {/* </Stack> */}
    </>
  );
}
