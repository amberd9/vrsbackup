import DerosDate from "../components/registration/DerosDate";
import NatoConfirmation from "../components/registration/NatoConfirmation";
import CancelPresentationIcon from "@mui/icons-material/CancelPresentation";
import { Stack, Button, Dialog, IconButton } from "@mui/material";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { useState } from "react";

const newUserDialog = ({ newUserDialogOpen, setNewUserDialogOpen }) => {
  const [closeRequested, setCloseRequested] = useState(false);

  useGSAP(
    () => {
      console.log(closeRequested);
      // animate modal when close button is clicked
      if (closeRequested) {
        // animate '.dialog' component to the values defined in the object
        gsap.to(".dialog", {
          opacity: 0,
          // close modal after animation is complete
          onComplete: () => setNewUserDialogOpen(false),
        });
      }
    },
    { dependencies: [closeRequested] }
  );

  return (
    <Dialog open={newUserDialogOpen} className="dialog">
      <Stack sx={styles.container}>
        <IconButton
          sx={{
            position: "absolute",
            top: "5px",
            right: "5px",
          }}
          onClick={() => setCloseRequested(true)}
        >
          <CancelPresentationIcon />
        </IconButton>
        <NatoConfirmation />
        <DerosDate />
        <Button
          size="small"
          variant="contained"
          sx={styles.button}
          onClick={() => setCloseRequested(true)}
        >
          Continue
        </Button>
      </Stack>
    </Dialog>
  );
};

const styles = {
  container: {
    alignSelf: "center",
    position: "relative",
    justifyContent: "space-evenly",
    padding: "2rem",
  },
  text: { fontStyle: "italic", fontSize: "1rem" },
  button: { alignSelf: "center", fontSize: ".8rem" },
};

export default newUserDialog;
