import {
  Box,
  Container,
  Typography,
  Stepper,
  Step,
  StepLabel,
  Button,
} from "@mui/material";
import * as React from "react";
import { queueInMain } from "../imgs/index.js";
import ServiceQueueInPage from "./ServiceQueueInPage.jsx";
import { useNavigate } from "react-router-dom";
import LocationQueueInPage from "./LocationQueueInPage.jsx";
import QueueDashboard from "./QueueDashboard.jsx";
import MainHeaderServices from "../components/MainHeaderServices.jsx";
const steps = ["Select Service", "Select Location", "Join Queue"];
export default function QueueIn() {
  const [activeStep, setActiveStep] = React.useState(0);
  const navigate = useNavigate();
  const handleNext = () => {
    if (steps.length - 1 === activeStep) navigate("/UserDashboard");
    else setActiveStep(activeStep + 1);
  };
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  const services = [
    "Initial Registration",
    "Transfer from DOD ID",
    "Expired Registration",
    "Change of Information",
    "Lost/Stolen Plates",
  ];
  //State to see which Service is selected
  const [serviceCheckedIndex, setServiceCheckedIndex] = React.useState(null);
  //State to see which Location is selected
  const [locationCheckedIndex, setLocationCheckedIndex] = React.useState(null);

  return (
    <Box className="user_dashboard_page">
      <MainHeaderServices />
      <Container maxWidth="xl">
        <Stepper activeStep={activeStep} alternativeLabel sx={{ my: 2 }}>
          {steps.map((step) => (
            <Step key={step}>
              <StepLabel>{step}</StepLabel>
            </Step>
          ))}
        </Stepper>
        {activeStep === 0 && (
          <ServiceQueueInPage
            serviceCheckedIndex={serviceCheckedIndex}
            setServiceCheckedIndex={setServiceCheckedIndex}
          />
        )}
        {activeStep === 1 && (
          <LocationQueueInPage
            locationCheckedIndex={locationCheckedIndex}
            setLocationCheckedIndex={setLocationCheckedIndex}
          />
        )}
        {activeStep === 2 && <QueueDashboard />}
        <Box sx={{ display: "flex", flexDirection: "row", pt: 2 }}>
          <Button
            color="inherit"
            disabled={activeStep === 0}
            onClick={handleBack}
            sx={{ mr: 1 }}
          >
            Back
          </Button>
          <Box sx={{ flex: "1 1 auto" }} />
          <Button onClick={handleNext}>
            {activeStep === steps.length - 1 ? "Finish" : "Next"}
          </Button>
        </Box>
      </Container>
    </Box>
  );
}
