import {
  Box,
  Chip,
  Divider,
  Stack,
  Typography,
  Radio,
  Button,
} from "@mui/material";
import * as React from "react";
import { FixedSizeList } from "react-window";
import { CheckCircle, PostAdd } from "@mui/icons-material";
const LocationQueueInPage = ({
  locationCheckedIndex,
  setLocationCheckedIndex,
}) => {
  //TODO:Add Image locationQueueIn.png
  const locations = [
    "Kapaun",
    "Filler Location",
    "Filler Location 2",
    "Filler Location 3 ",
  ];

  return (
    <Stack direction={"row"} spacing={3}>
      <Box
        sx={{
          width: "40%",
          border: "2px solid lightblue",
          mb: 5,
          backgroundColor: "#1F1E31",
        }}
      >
        <Typography
          variant="h3"
          sx={{
            textAlign: "center",
            color: "#fff",
            backgroundColor: "#91A930",
          }}
        >
          Location Selection
        </Typography>
        <Divider />
        <FixedSizeList
          height={300}
          width="100%"
          itemSize={50}
          itemCount={locations.length}
        >
          {({ index, style }) => (
            <Stack alignSelf="start" style={style} direction="row">
              <Radio
                checked={locationCheckedIndex === index}
                onChange={(event) => setLocationCheckedIndex(index)}
              />
              <Typography variant="h6" sx={{ fontStyle: "italic" }}>
                {locations[index]}
              </Typography>
            </Stack>
          )}
        </FixedSizeList>
      </Box>
      <Stack
        padding={5}
        sx={{
          border: "2px solid lightblue",
          backgroundColor: "#1F1E31",
        }}
      >
        <Stack spacing={3}>
          <Stack
            direction={"row"}
            sx={{
              borderRadius: 3,
              border: "2px solid lightblue",
              p: 3,
            }}
          >
            <Stack flex={1} spacing={3}>
              <Typography variant="h4"> [Selected Location]</Typography>
              <Typography>Walk-Ins Allowed ::: OR ::: Must Queue</Typography>
            </Stack>
            <Divider
              orientation="vertical"
              variant="middle"
              flexItem
              sx={{ m: 1 }}
            />
            <Stack
              direction={"row"}
              justifyContent={"space-around"}
              spacing={5}
            >
              <Stack spacing={3}>
                <Chip
                  label="10 people"
                  variant="outlined"
                  sx={{ fontSize: "1.5rem" }}
                />

                <Typography variant="h4">Position in Queue</Typography>
              </Stack>
              <Stack j spacing={3}>
                <Chip
                  label="50 mins"
                  variant="outlined"
                  sx={{ fontSize: "1.5rem" }}
                />
                <Typography variant="h4">Wait Time</Typography>
              </Stack>
            </Stack>
          </Stack>
          <Stack direction={"row"} spacing={3}>
            <Stack
              sx={{
                borderRadius: 3,
                border: "2px solid lightblue",
                p: 3,
              }}
            >
              <Typography textAlign={"center"} variant="h5">
                Do you have everything you need?
              </Typography>
              <Button
                sx={{
                  backgroundColor: "#91A930",
                  color: "#fff",
                  borderRadius: 3,
                }}
                endIcon={<CheckCircle />}
              >
                Documents Check
              </Button>
            </Stack>
            <Stack
              sx={{
                borderRadius: 3,
                border: "2px solid lightblue",
                p: 3,
              }}
            >
              <Typography variant="h5" textAlign={"center"}>
                Prefer to plan ahead?
              </Typography>
              <Button
                sx={{
                  backgroundColor: "#181E00",
                  color: "#fff",
                  borderRadius: 3,
                }}
                endIcon={<PostAdd />}
              >
                Make an appointment
              </Button>
            </Stack>
          </Stack>
        </Stack>
      </Stack>
    </Stack>
  );
};

export default LocationQueueInPage;
