import UserDashboard from "./UserDashboard";
import LandingPage from "./LandingPage";
import Error404 from "./Error404";
import MSFverify from "./Services/MSFverify";
import StartBasicDocsChecks from "./Services/ServicePathStart";
import MultipleServicesStart from "./Services/MultipleServicesStart";
import Service from "./Services/Service";
import HowDidYouTransfer from "../components/Dashboard/Requests/HowDidYouTransfer";
import NewArrivalInitial from "../components/Dashboard/Requests/NewArrivalInitial";
export {
  UserDashboard,
  Service,
  MultipleServicesStart,
  LandingPage,
  StartBasicDocsChecks,
  Error404,
  MSFverify,
  HowDidYouTransfer,
  NewArrivalInitial,
};
