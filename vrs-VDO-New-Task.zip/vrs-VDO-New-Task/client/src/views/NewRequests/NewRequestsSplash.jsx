import { Box, Button, Divider, Stack, Typography } from "@mui/material";
import { VRSNewRequestsPanel } from "../../imgs/RequestPageImages/index.js";
import { useNavigate } from "react-router-dom";

export default function VRSNewRequestsSplash() {
  const navigate = useNavigate();
  //TODO The redux has not been established
  //Jacobson revision 04.04. author: Giri
  return (
    <>
      <Stack spacing={2} padding={2}>
        <Typography
          align="center"
          sx={{
            fontSize: "36px",
            color: "#EBFFE7",
            fontFamily: "Fira Sans Extra Condensed",
          }}
        >
          ARE YOU NEEDING TO MANAGE MULTIPLE VEHICLES TODAY?
        </Typography>
        <Stack direction="row">
          <Box width="35%" />
          <Divider flexItem sx={{ width: "350px", color: "#adc91e" }} />
          <Box width="35%" />
        </Stack>

        <Stack>
          <Box
            align="center"
            sx={{
              width: "1000px",
              padding: 3,
              border: "2px solid #6D85D6",
              backgroundColor: "#1E2F5160",
              borderRadius: 4,
            }}
          >
            <img
              src={VRSNewRequestsPanel}
              alt="VRSNewRequestsPanel"
              height={550}
              align="center"
            />
            <Box display="flex" justifyContent="space-evenly" align="center">
              <Button
                variant="contained"
                color="secondary"
                sx={{
                  backgroundColor: "#00DAF1",
                  color: "#00142A",
                  fontSize: "24px",
                  borderRadius: 3,
                  borderStyle: "solid",
                  borderWidth: 3,
                  borderColor: "#0C79D1",
                  minWidth: "100px",
                  maxHeight: "50px",
                }}
                onClick={() => {
                  navigate("/NewRequests/Add-Vehicles");
                }}
              >
                YES
              </Button>
              <Button
                variant="contained"
                color="secondary"
                sx={{
                  backgroundColor: "#00DAF1",
                  color: "#00142A",
                  fontSize: "24px",
                  borderRadius: 3,
                  borderStyle: "solid",
                  borderWidth: 3,
                  borderColor: "#0C79D1",
                  minWidth: "100px",
                  maxHeight: "50px",
                }}
                onClick={() => {
                  navigate("/NewRequests/VehicleType");
                }}
              >
                NO
              </Button>
            </Box>{" "}
          </Box>
        </Stack>
      </Stack>
    </>
  );
}
