import { Box, Grid, Stack, Toolbar, Typography } from "@mui/material";
import MainHeader from "../../components/MainHeader";
import { Outlet } from "react-router-dom";
import RequestNav from "../../components/RequestPage/RequestNav.jsx";

export default function NewRequestsPage() {
  return (
    <Box className="new_requests_page">
      <MainHeader />

      <Stack direction="row">
        <Box>
          <RequestNav />
        </Box>
        <Stack alignItems="center" justifyContent="center" sx={{ flexGrow: 1 }}>
          <Toolbar pb={2} sx={{ flexGrow: 1 }}>
            <Stack
              flex={1}
              direction="row"
              alignItems="center"
              justifyContent="center"
              spacing={10}
            >
              <Typography>Contact Us</Typography>
              <Typography>Documents and Forms</Typography>
              <Typography>Tools and Resources</Typography>
            </Stack>
          </Toolbar>
          <Grid item xs={12}></Grid>
          <Box align="center" sx={{ width: 1 }} padding={4}>
            <Outlet />
          </Box>
        </Stack>
      </Stack>
    </Box>
  );
}
