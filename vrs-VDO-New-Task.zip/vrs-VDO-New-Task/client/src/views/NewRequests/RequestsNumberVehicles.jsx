import { Box, Button, Stack, Typography } from "@mui/material";
import CurrentVehiclesMiniCards from "../../components/Dashboard/Vehicles/CurrentVehiclesMiniCards";
import InputNumberOfVehicles from "../../components/NewRequests/InputNumberOfVehicles";
import { useState } from "react";
import VehicleCountAlert from "../../components/Services/VehicleCountAlert";
import VehicleConfirmationModal from "../../components/Services/VehicleConfirmationModal";
import AddVehicleModal from "../../components/Dashboard/Vehicles/AddVehicleModal";
import App from "../../App";
import { svc_btn_purple } from "../../components/Services/WalkthruCSS";

const RequestsNumberVehicles = ({}) => {
  //TODO The redux has not been established
  const [povCountOpen, setPovCountOpen] = useState(true);
  const [VehicleConfirmationOpen, setVehicleConfirmationOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);

  // revision - Jacobson on 4/8/24
  // TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE
  // TODO: NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY
  // TODO: USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES
  return (
    <>
      {/* TODO: CONTINUE BUTTON NEEDS TO REROUTE DEPENDING ON QUEUE OR SERVICE ACCESS POINT */}
      <VehicleCountAlert
        open={povCountOpen}
        handleClose={() => setPovCountOpen(false)}
      />
      <VehicleConfirmationModal
        open={VehicleConfirmationOpen}
        handleClose={() => setVehicleConfirmationOpen(false)}
      />
      <AddVehicleModal open={addOpen} handleClose={() => setAddOpen(false)} />
      <Stack
        className="sticky"
        spacing={10}
        pb={7}
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          overflowY: "auto",
        }}
        direction="row"
      >
        {/* TODO: LOGIC STATMENT OR NEW PAGE THAT DOES NOT SHOW MY PROFILE LIST VEHICLES TO THOSE NOT LOGGED IN
      KEEP CODE HERE FOR NOW UNTIL WORKED */}
        {/* {App.("/QueueIn") ? ( */}
        <Box justifyContent="space-evenly" />
        {/* : ( */}
        <Stack>
          <Typography
            align="center"
            sx={{ fontSize: "20px", fontFamily: "Fira Sans Extra Condensed" }}
          >
            PROFILE VEHICLES
          </Typography>

          <CurrentVehiclesMiniCards />
        </Stack>
        {/* )} */}
        <Stack justifyContent="space-evenly">
          <Typography
            align="center"
            sx={{ fontSize: "30px", fontFamily: "Fira Sans Extra Condensed" }}
          >
            LET US KNOW HOW MANY VEHICLES YOU NEED ASSISTANCE WITH
          </Typography>
          <InputNumberOfVehicles />
          <Typography
            align="center"
            sx={{ fontSize: "22px", fontFamily: "Fira Sans Extra Condensed" }}
          >
            Select vehicles from your existing profile list on the left. <br />{" "}
            <br />
            If the vehicle you need is not listed in your profile list, use the
            counter tool instead.
          </Typography>
          <Stack direction="row-reverse" justifyContent="space-evenly">
            <Stack>
              <Button onClick={() => setAddOpen(true)}>Add to Profile</Button>
            </Stack>
            <Typography
              align="right"
              sx={{
                align: "right",
                fontSize: "18px",
                fontFamily: "Roboto Condensed",
              }}
            >
              You may add a previously unlisted vehicle to your profile <br />
              by selecting the "ADD TO PROFILE" option. <br />
              <br />
            </Typography>
          </Stack>
        </Stack>
        <Stack justifyContent="flex-end" align="left">
          <Button
            onClick={() => setVehicleConfirmationOpen(true)}
            sx={{
              ...svc_btn_purple,
              width: 150,
              mr: 3,
              borderColor: "#caa6fc",
            }}
          >
            CONTINUE
          </Button>
        </Stack>
      </Stack>
    </>
  );
};
export default RequestsNumberVehicles;
