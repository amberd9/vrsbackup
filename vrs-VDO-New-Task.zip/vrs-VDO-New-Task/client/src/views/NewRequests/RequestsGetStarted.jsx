import { Box, Button, Stack, Typography } from "@mui/material";
import React from "react";
import { VRSRequestsGetStarted } from "../../imgs/RequestPageImages/index.js";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import { useNavigate } from "react-router-dom";
import { svc_blue_btn } from "../../components/Services/WalkthruCSS.jsx";

export default function VRSRequestsGetStartedPage() {
  const navigate = useNavigate();
  return (
    <Stack>
      <Box align="center">
        <Box
          display="flex"
          justifyContent="space-evenly"
          alignContent="center"
          padding={2}
        >
          <Typography
            sx={{ color: "#EBFFE7", fontFamily: "Fira Sans Extra Condensed" }}
            variant="h5"
            fontSize="36px"
            padding={2}
            mr={3}
          >
            GREAT! <br /> LET'S GET YOU STARTED ON YOUR PAPERWORK
          </Typography>
        </Box>
        <Box padding={6}>
          <Button
            variant="contained"
            sx={svc_blue_btn}
            startIcon={<CheckCircleOutlineIcon />}
            onClick={() => navigate("/NewRequests/Splash-Page")}
          >
            GET STARTED
          </Button>
        </Box>
        <Box
          component="img"
          src={VRSRequestsGetStarted}
          alt="VRSRequestsGetStarted"
          sx={{
            maxHeight: 800,
            maxWidth: 800,
          }}
        ></Box>
      </Box>
    </Stack>
  );
}
