import React from "react";
import {
  Box,
  Chip,
  Divider,
  Stack,
  Typography,
  Radio,
  Button,
} from "@mui/material";
import {
  CheckCircle,
  HourglassBottom,
  Info,
  Map,
  PostAdd,
} from "@mui/icons-material";
import { queueMainDashboard } from "../imgs";
import { useNavigate } from "react-router-dom";
const QueueDashboard = () => {
  const navigate = useNavigate();
  return (
    <Stack direction={"row"} spacing={3}>
      <Stack
        flex={1}
        p={1}
        sx={{
          flexGrow: "1.6",
          border: "2px solid lightblue",
          backgroundColor: "#1F1E31",
        }}
      >
        <Box sx={{ display: "flex", justifyContent: "space-evenly" }}>
          <Button
            onClick={() => navigate("/UserDashboard")}
            sx={{
              backgroundColor: "#22006B",
              borderRadius: 3,
              border: "3px solid lightblue",
            }}
          >
            Dashboard
          </Button>
          <Stack justifyContent={"center"} alignContent={"center"}>
            <Typography variant="h4" textAlign={"center"}>
              You are now in Queue!
            </Typography>
          </Stack>
          <Info />
        </Box>

        <Stack direction={"row"}>
          <Stack>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <img src={queueMainDashboard} width={"200px"} />

              <Stack justifyContent={"space-evenly"}>
                <Chip
                  label="10 people"
                  variant="outlined"
                  sx={{ fontSize: "1.5rem" }}
                />

                <Typography variant="h4">Position in Queue</Typography>
              </Stack>
              <Stack justifyContent={"space-evenly"}>
                <Chip
                  label="50 mins"
                  variant="outlined"
                  sx={{ fontSize: "1.5rem" }}
                />
                <Typography variant="h4">Wait Time</Typography>
              </Stack>
            </Stack>
            {/* pass in queue id number */}
            <Stack direction={"row"} spacing={3} mb={5}>
              <Typography variant="h5">Need More Time?</Typography>
              <Button
                sx={{
                  backgroundColor: "#84C1FF",
                  color: "#000",
                  borderRadius: 3,
                }}
              >
                Leave Queue
              </Button>
              <Typography variant="h5">Need Directions?</Typography>
              <Button
                sx={{
                  backgroundColor: "#1A1A2B",
                  borderRadius: 3,
                  border: "3px solid lightblue",
                }}
                endIcon={<Map />}
              >
                MAPS
              </Button>
            </Stack>
          </Stack>
        </Stack>
        {/* Did you know you can walk-in for this service? & then a leave queue button */}
        <Stack direction="row" spacing={3}>
          <Button
            sx={{
              backgroundColor: "#1A1A2B",
              borderRadius: 3,
              border: "3px solid lightblue",
              width: "120px",
            }}
            endIcon={<HourglassBottom />}
          >
            HOURS
          </Button>
          <Stack direction={"row"} spacing={1}>
            <Typography variant="h5" sx={{ color: "#fff" }}>
              Your Queue ID Number is:
            </Typography>
            <Typography variant="h6" sx={{ color: "#91A930" }}>
              [XXXXX]
            </Typography>
            <Typography variant="h6" sx={{ color: "#91A930" }}>
              (please write this down)
            </Typography>
          </Stack>
        </Stack>
      </Stack>
      <Stack
        flex={1}
        p={1}
        spacing={3}
        sx={{
          border: "2px solid lightblue",
          backgroundColor: "#1F1E31",
        }}
      >
        {/* This is for everyone in queue the other is for your queue */}
        <Typography variant="h4" textAlign={"center"}>
          Queue Status
        </Typography>

        <Stack direction={"row"} justifyContent={"space-between"}>
          <Stack justifyContent={"space-evenly"} spacing={3}>
            <Chip
              label="10 people"
              variant="outlined"
              sx={{ fontSize: "1.5rem" }}
            />

            <Typography variant="h4">Position in Queue</Typography>
          </Stack>
          <Stack justifyContent={"space-evenly"} spacing={3}>
            <Chip
              label="50 mins"
              variant="outlined"
              sx={{ fontSize: "1.5rem" }}
            />
            <Typography variant="h4">Wait Time</Typography>
          </Stack>
        </Stack>

        <Typography variant="h5" textAlign={"center"}>
          Do you have everything you need?
        </Typography>
        <Button
          sx={{ backgroundColor: "#91A930", color: "#fff", borderRadius: 3 }}
          endIcon={<CheckCircle />}
        >
          Documents Check
        </Button>
        <Typography variant="h5" textAlign={"center"}>
          Prefer to plan ahead?
        </Typography>
        <Button
          sx={{
            backgroundColor: "#181E00",
            color: "#fff",
            borderRadius: 3,
          }}
          endIcon={<PostAdd />}
        >
          Make an appointment
        </Button>
      </Stack>
    </Stack>
  );
};

export default QueueDashboard;
