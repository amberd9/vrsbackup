import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Grid,
  IconButton,
  Stack,
  Typography,
  useMediaQuery,
} from "@mui/material";
import NewUserDialog from "./NewUserDialog";
import ReturningUserDialog from "./ReturningUserDialog";
import LandingNavBar from "../components/navBars/LandingPageNav";
import { useNavigate } from "react-router-dom";
import {
  ArrowDownwardRounded,
  ExpandMore,
  Facebook,
  Map,
  SearchTwoTone,
} from "@mui/icons-material";
import {
  eightsix,
  fivesixnine,
  sword,
  usag,
  vehiclelanding,
} from "../imgs/index.js";
//TODO: work on view for smaller screens also when navbar is hit it scrolls to each portion
import {
  accordion_decoration,
  box_pink_orange,
  btn_svc_hist_light_blue,
  btn_svc_history_purple,
  landing_box_dark,
  landing_box_light,
  typ_fira_subheader,
  typ_fira_title,
  typ_roboto_header,
  typ_roboto_lightitalic,
  typ_roboto_sub,
} from "../components/Services/WalkthruCSS.jsx";

const LandingPage = () => {
  const navigate = useNavigate();
  const isLargeScreen = useMediaQuery("(min-width:1000px)");

  // TODO: fix sticky buttons for LandingNavBar; make anchors
  return (
    <>
      <Stack flex={1}>
        <LandingNavBar />
        <Stack className="bg_landing_page" pb={2}>
          <Stack
            align="center"
            height="100vh"
            justifyContent="center"
            alignItems="center"
          >
            <Typography
              sx={{
                ...typ_fira_title,
                color: "#9775fa",
                filter: "drop-shadow(1.5px 1px 1px #aff)",
                fontSize: 70,
                fontWeight: 400,
              }}
              textAlign="center"
              // mt={20}
              mb={20}
            >
              WELCOME TO VEHICLE REGISTRATION
            </Typography>
            <IconButton href="#register_title">
              <ExpandMore sx={{ fontSize: 120, color: "#ff2d46" }} />
            </IconButton>
          </Stack>
          {/* <Box
            component="img"
            className="sticky"
            src={vehiclelanding}
            width="100%"
            zIndex={0}
          /> */}
          <Grid container justifyContent="space-between" rowGap={10} mb={0}>
            <Box id="register_title" sx={{ mt: -10 }} />
            <Grid item xs={12}>
              <Stack spacing={1.5} sx={{ alignItems: "center" }}>
                <Typography
                  sx={{
                    ...typ_fira_title,
                    fontWeight: 400,
                    // fontSize: "60px",
                    color: "#fdb924",
                    filter: "drop-shadow(1.5px 1px 1px #000)",
                  }}
                >
                  REGISTER FOR AN ACCOUNT WITH KAPAUN VEHICLE REGISTRATION{" "}
                  <br />
                </Typography>
                <Typography
                  sx={{
                    ...typ_fira_subheader,
                    fontSize: "40px",
                    fontStyle: "italic",
                    textAlign: "center",
                    filter: "drop-shadow(1.5px 1px 1px #000)",
                  }}
                >
                  {"\u25CF\u0020"}
                  Manage and track services for each of your vehicles. <br />
                  {"\u25CF\u0020"}
                  Utilize planning tools and access vehicle resources. <br />
                  {"\u25CF\u0020"}
                  Schedule appointments and use our Queue-In system to meet all
                  your vehicle needs.
                </Typography>
                <Box height="50px" />
                <Button
                  sx={{
                    ...btn_svc_history_purple,
                    backgroundColor: "#00DAF1",
                    borderColor: "#0C79D1",
                    minWidth: 180,
                    color: "#00142A",
                  }}
                  onClick={() => navigate("/UserDashboard/vehicles")}
                >
                  Log In
                </Button>
                <Box>
                  <Typography
                    sx={{
                      ...typ_roboto_sub,
                      filter: "drop-shadow(1.5px 1px 1px #000)",
                      fontSize: "35px",
                      color: "#fdb924",
                      filter: "drop-shadow(1.5px 1px 1px #ff773d)",
                      WebkitTextStroke: "1 inset #000",
                      borderStroke: "3.5px #000",
                    }}
                    align="center"
                  >
                    New User?
                  </Typography>
                  <Button
                    sx={{ ...btn_svc_history_purple, minWidth: 250 }}
                    onClick={() => setNewUserDialogOpen(true)}
                  >
                    Register
                  </Button>
                </Box>
              </Stack>
            </Grid>
          </Grid>
          <Box id="about_us_title" height="200px" />
          <Stack
            direction="row"
            justifyContent="space-evenly"
            alignItems="center"
            align="center"
            gap={2}
            px={2}
          >
            <Box
              sx={{
                ...landing_box_light,
                fontSize: "40px",
                fontFamily: "Roboto Condensed",
                py: 2,
              }}
            >
              <Typography
                sx={{
                  ...typ_roboto_header,
                  fontSize: "50px",
                  color: "#fdb924",
                }}
                align="center"
              >
                ABOUT US
              </Typography>
              <Typography
                sx={{
                  ...typ_roboto_header,
                  fontSize: "40px",
                  color: "#fdb924",
                }}
                align="left"
              >
                MISSION:
              </Typography>
              <Typography
                sx={{
                  ...typ_roboto_header,
                  fontSize: "24px",
                  fontWeight: "350",
                }}
              >
                Support and provide USAREUR vehicle registration/de-registration
                services for all SOFA affiliated personnel within the KMC area
                to include Army Kasernes, Air Base & Stations, GSUs and NATO
                members.
              </Typography>
              <Typography
                sx={{
                  ...typ_roboto_header,
                  fontSize: "24px",
                  fontWeight: "350",
                }}
                color="text.tan"
              >
                The Vehicle Processing Center consists of three SEPARATE
                entities:
                <br />
                <br />
                <Typography
                  sx={{
                    ...typ_roboto_header,
                    fontSize: "24px",
                    fontWeight: "350",
                  }}
                  color="text.lightblue"
                >
                  Vehicle Registration - 569th USFPS
                  <br />
                  <br />
                  International Auto Logistics - Shipping office
                  <br />
                  <br />
                  86th Kapaun Vehicle Safety Inspection - 86th VRS
                </Typography>
                <br />
                VRS is an appointment-based system and provides queue-in
                services on an emergency basis. The queue-in system is first
                come, first serve and only processes a handful of people each
                day for a select number of services. As such, we highly
                encourage that you create an account and schedule an appointment
                with us.
                <br />
                <br />
                Please keep in mind that Vehicle Registration handles hundreds
                of customers a day so we apologize if we are unable to answer
                the phone when you call. We are currently assisting customers at
                our desks.
              </Typography>
            </Box>
            <Stack>
              <Box
                sx={{
                  ...landing_box_light,
                  minWidth: "300px",
                  py: 2,
                }}
              >
                <Stack alignItems="center" justifyContent="center" pb={2}>
                  <IconButton
                    onClick={() =>
                      window.open(
                        "https://www.facebook.com/KapaunRMV/",
                        "_blank"
                      )
                    }
                  >
                    <Facebook sx={{ fontSize: 82, color: "#fddb91" }} />
                  </IconButton>
                  <Box height="25px" />
                  <Button
                    variant="text"
                    sx={{
                      ...btn_svc_hist_light_blue,
                      borderWidth: 4,
                      maxHeight: 50,
                    }}
                  >
                    CONTACT US
                  </Button>
                </Stack>
              </Box>
              <Box height="80px" />
              <Stack
                justifyContent="space-between"
                alignItems="center"
                py={4}
                sx={{
                  // ...box_pink_orange,
                  width: 350,
                  align: "center",
                }}
              >
                <Stack spacing={4} justifyContent="center">
                  <Button
                    sx={btn_svc_hist_light_blue}
                    onClick={() => navigate("/QueueIn")}
                  >
                    JOIN SERVICE QUEUE
                  </Button>
                  <Button
                    sx={{
                      ...btn_svc_history_purple,
                      fontSize: 27,
                      filter: {
                        dropShadow: "(rgba(0, 0, 0, 0.1)",
                        boxShadow:
                          "rgba(50, 50, 93, 0.25) 0px 50px 100px -20px inset",
                      },
                    }}
                  >
                    Find Locations
                  </Button>
                </Stack>
              </Stack>
            </Stack>
          </Stack>
          <Box id="partners_title" height="80px" />
          <Stack
            justifyContent="space-evenly"
            direction="row"
            alignItems="center"
          >
            <Stack
              alignItems="center"
              sx={{
                ...landing_box_dark,
                align: "center",
                minHeight: "400px",
              }}
            >
              <Stack spacing={2}>
                <Typography
                  sx={{
                    ...typ_fira_title,
                    fontSize: "48px",
                    textAlign: "center",
                    color: "#fdb924",
                  }}
                >
                  OUR SERVICES
                </Typography>
                <Typography
                  align="center"
                  sx={{
                    color: "#daf",
                    filter: "drop-shadow(1.5px 1px 0px #40009b30)",
                    fontSize: "25px",
                    textAlign: isLargeScreen ? "" : "center",
                  }}
                >
                  REQUIREMENTS
                </Typography>
                <Box align="center">
                  <Button
                    sx={{
                      ...btn_svc_hist_light_blue,
                      borderWidth: 4,
                      maxHeight: 50,
                      fontWeight: "light",
                      minWidth: "150px",
                    }}
                    onClick={() =>
                      window.open("./Vehicle_Registration_pdf.pdf", "_blank")
                    }
                  >
                    PDF GUIDE
                  </Button>
                </Box>
                <Typography
                  align="center"
                  sx={{
                    color: "#daf",
                    filter: "drop-shadow(1.5px 1px 0px #40009b30)",
                    fontSize: "25px",
                    textAlign: isLargeScreen ? "" : "center",
                  }}
                >
                  INSPECTION PREP CHECKLIST
                </Typography>
                <Box align="center">
                  <Button
                    sx={{
                      ...btn_svc_history_purple,
                      fontSize: 27,
                      filter: {
                        dropShadow: "(rgba(0, 0, 0, 0.1)",
                        boxShadow:
                          "rgba(50, 50, 93, 0.25) 0px 50px 100px -20px inset",
                      },
                    }}
                    onClick={() => navigate("/CheckDocs4Services")}
                    startIcon={<SearchTwoTone />}
                  >
                    INSPECTIONS
                  </Button>
                </Box>
              </Stack>
            </Stack>
            <Stack
              justifyContent="space-evenly"
              alignItems="center"
              py={5}
              sx={{ ...landing_box_dark, align: "center" }}
            >
              <Stack>
                <Typography
                  sx={{
                    ...typ_fira_subheader,
                    fontSize: "45px",
                    fontStyle: "italic",
                    textAlign: "center",
                    filter: "drop-shadow(2px 1px 2px #435fdb )",
                  }}
                >
                  PARTNERS & RELATED SERVICE PROVIDERS
                </Typography>
                <Typography
                  sx={{
                    ...typ_roboto_lightitalic,
                    fontSize: "18px",
                    color: "#d9ff05",
                  }}
                  align="center"
                  py={0.5}
                >
                  Private and Non-Military Providers are not endorsed by the
                  569th or Vehicle Registration.
                </Typography>
                <Accordion sx={accordion_decoration}>
                  <AccordionSummary
                    expandIcon={<ArrowDownwardRounded />}
                    fontFamily="FIRA SANS Extra Condensed"
                    id="PARTNER2"
                  >
                    <Typography>VEHICLE INSPECTION</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>
                      Global Auto Logistics
                      <br />
                      Kapaun AS, Bldg 2806
                      <br />
                      Hours: 0800-1600 Monday - Friday
                      <br />
                      Commercial: +49 (0) 631 -3579-0088
                      <br />
                      DSN: 489-7750
                      <br />
                      Kaiserslautern.VPC@ialpov.us
                      <br />
                      <a
                        href="www.pcsmypov.com"
                        target="_blank"
                        style={{ color: "white" }}
                      >
                        www.pcsmypov.com
                      </a>
                    </Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion sx={accordion_decoration}>
                  <AccordionSummary
                    expandIcon={<ArrowDownwardRounded />}
                    fontFamily="FIRA SANS Extra Condensed"
                    id="PARTNER1"
                  >
                    <Typography>
                      INTERNATIONAL AUTO LOGISTICS IAL SHIPPING
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>
                      Global Auto Logistics
                      <br />
                      Kapaun AS, Bldg 2806
                      <br />
                      Hours: 0800-1600 Monday - Friday
                      <br />
                      Commercial: +49 (0) 631 -3579-0088
                      <br />
                      DSN: 489-7750
                      <br />
                      Kaiserslautern.VPC@ialpov.us
                      <br />
                      <a href="www.pcsmypov.com" style={{ color: "white" }}>
                        www.pcsmypov.com
                      </a>
                    </Typography>
                  </AccordionDetails>
                </Accordion>
                <br /> <br />
                <Accordion sx={accordion_decoration}>
                  <AccordionSummary
                    expandIcon={<ArrowDownwardRounded />}
                    fontFamily="FIRA SANS Extra Condensed"
                    id="PARTNER3"
                  >
                    <Typography>RAMSTEIN CUSTOMS OFFICE</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography></Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion sx={accordion_decoration}>
                  <AccordionSummary
                    expandIcon={<ArrowDownwardRounded />}
                    fontFamily="FIRA SANS Extra Condensed"
                    id="PARTNER4"
                  >
                    <Typography>RAMSTEIN HOUSEHOLD GOODS</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography></Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion sx={accordion_decoration}>
                  <AccordionSummary
                    expandIcon={<ArrowDownwardRounded />}
                    fontFamily="FIRA SANS Extra Condensed"
                    id="PARTNER5"
                  >
                    <Typography>RAMSTEIN LEGAL OFFICE</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography> LEGAL INFO</Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion sx={accordion_decoration}>
                  <AccordionSummary
                    color="#FFACE9"
                    expandIcon={<ArrowDownwardRounded />}
                    aria-label="Expand"
                    aria-controls="-content"
                    id="-header"
                  >
                    <Typography>RAMSTEIN USAREUR LICENSING</Typography>
                  </AccordionSummary>
                  <AccordionDetails></AccordionDetails>
                </Accordion>
                <Accordion sx={accordion_decoration}>
                  <AccordionSummary
                    expandIcon={<ArrowDownwardRounded />}
                    fontFamily="FIRA SANS Extra Condensed"
                    id="PARTNER6"
                  >
                    <Typography>RAMSTEIN MSF</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography></Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion sx={accordion_decoration}>
                  <AccordionSummary
                    expandIcon={<ArrowDownwardRounded />}
                    fontFamily="FIRA SANS Extra Condensed"
                    id="PARTNER7"
                  >
                    <Typography>RAMSTEIN JUNKYARD MWR</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>INFO</Typography>
                  </AccordionDetails>
                </Accordion>
              </Stack>
            </Stack>
          </Stack>
          <Box id="contact_us_title" height="80px" />
          <Stack
            direction="row-reverse"
            justifyContent="space-evenly"
            alignItems="center"
            mx={2}
          >
            <Stack
              justifyContent="space-between"
              alignItems="center"
              flex={1}
              py={2}
              sx={{
                ...box_pink_orange,
                border: "5px ridge #39003385 ",
                background: "#1D114845",
                p: 2,
                align: "center",
              }}
            >
              <Stack>
                <Typography
                  align="center"
                  sx={{
                    ...typ_fira_title,
                    color: "#1D1148",
                    filter: "drop-shadow(2px 3px 3px #d5f99a)",
                    fontSize: "48px",
                    textAlign: isLargeScreen ? "" : "center",
                  }}
                >
                  CONTACT US
                </Typography>
                <Typography
                  sx={{
                    ...typ_fira_subheader,
                    fontSize: "30px",
                    fontStyle: "italic",
                    textAlign: "center",
                    filter: "drop-shadow(2px 1px 2px #435fdb )",
                  }}
                >
                  569th USFPS <br /> Vehicle Registration <br />
                  Ramstein Air Base
                  <Typography
                    align="center"
                    sx={{
                      ...typ_fira_title,
                      color: "#1D1148",
                      filter: "drop-shadow(1.5px 1px 1px #aff)",
                      fontSize: "42px",
                      textAlign: isLargeScreen ? "" : "center",
                    }}
                  >
                    HOURS
                  </Typography>
                  Emailing our org. box is the best way to contact us: <br />
                  569USFPS.S5BV.VehicleRegistration@us.af.mil
                  <br />
                  Phone
                  <br />
                  DSN
                </Typography>
              </Stack>
            </Stack>
          </Stack>
        </Stack>
      </Stack>
    </>
  );
};

export default LandingPage;
