
import React from "react";
import { hhg3Motorcycle } from "../imgs";
import { useNavigate } from "react-router-dom";
import CheckBoxTemplate from '../components/NewRequests/CheckBoxTemplate.jsx';
const label = { inputProps: { "aria-label": "Checkbox demo" } };

const HHGClass1License = () => {
  const navigate = useNavigate();
  return (
    <CheckBoxTemplate
    header1="You will need the following documents to help us."
    header2="service you for this request."
    cardHeader=" I verify I have and will present a valid USAREUR license with Class 1."
    cardFooter=" Resources (Click Here)"
    footerLink=""
    backLink="/HHGShipping"
    continueLink="/LienMemorandum"
    image={hhg3Motorcycle}
  />
  );
};

export default HHGClass1License;
