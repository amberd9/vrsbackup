import {
  Stack,
  Checkbox,
  ListItemText,
  Typography,
  Button,
  Divider,
  Fab,
  Stepper,
  Step,
  StepLabel,
  IconButton,
  InputLabel,
  Icon,
  CircularProgress,
} from "@mui/material";
import "../components/Services/walkthru.css";
import {
  btn_maps_hrs,
  circle_fab,
  circle_fab_blue,
  circle_fab_lightblue,
  svc_blue_btn,
  svc_btn_green,
  svc_btn_purple,
  typ_roboto_header,
  typ_roboto_sub,
} from "../components/Services/WalkthruCSS.jsx";
import { Outlet, useNavigate } from "react-router-dom";
import MainHeaderServices from "../components/MainHeaderServices";
import LocationQueueInPage from "./LocationQueueInPage";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Chip from "@mui/material/Chip";
import { useState } from "react";
import {
  DoneAllRounded,
  DoneOutlineRounded,
  Groups2Rounded,
  MapRounded,
  MeetingRoomRounded,
  SkipPreviousRounded,
} from "@mui/icons-material";
import QueueAddVehiclesModal from "./QueueAddVehiclesModal.jsx";
import {
  astrooutoflaptop,
  hours,
  locationQueueIn,
  maps,
  queueInMain,
  queueMainDashboard,
} from "../imgs/index.js";
import QueueSelectLocation from "./QueueSelectLocation.jsx";
import QueueInfoModal from "./QueueInfoModal.jsx";

const QueueFinalStage = () => {
  //State to see which Service is selected
  const [serviceCheckedIndex, setServiceCheckedIndex] = useState(null);
  // //State to see which Location is selected
  const [locationCheckedIndex, setLocationCheckedIndex] = useState(null);
  const [activeStep, setActiveStep] = useState(0);
  const navigate = useNavigate();
  const steps = ["Select Service", "Select Location", "Join Queue"];

  const handleNext = () => {
    if (steps.length - 1 !== activeStep) setActiveStep(activeStep + 1);
  };
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  const [multVehicleOpen, setMultVehicleOpen] = useState(false);
  //functions for selection list

  return (
    <>
      <Box
        flex={1}
        className="user_dashboard_page"
        sx={{
          "::-webkit-scrollbar-thumb": {
            background: "#0060A943",
          },
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <MainHeaderServices />
        <Stack>
          <Stepper activeStep={activeStep} alternativeLabel sx={{ my: 0.5 }}>
            {steps.map((step) => (
              <Step key={step}>
                <StepLabel>{step}</StepLabel>
              </Step>
            ))}
          </Stepper>
        </Stack>

        <Stack py={2} direction="row" justifyContent="space-evenly">
          <IconButton disabled={activeStep === 0} onClick={handleBack}>
            <SkipPreviousRounded
              sx={{
                position: "absolute",
                left: "5%",
                top: "80%",
                fontSize: "100px",
                color: "#daf349",
              }}
            />
          </IconButton>
          <Box
            py={2}
            alignItems="center"
            justifyContent="space-evenly"
            sx={{
              background: "#4B004320",
              border: "solid 4px #3E3A5154",
              borderRadius: 4,
              width: "1200px",
            }}
          >
            <Stack alignItems="space-between" direction="row">
              <Box
                component="img"
                src={queueMainDashboard}
                alt="astrocomputer"
                height="400px"
              />
              <Box width={80} />
              <Stack>
                <Box justifyContent="space-between" align="center">
                  <Typography
                    fontSize={50}
                    fontFamily="FIRA SANS EXTRA CONDENSED"
                    py={1}
                  >
                    YOU ARE NOW IN THE QUEUE!
                  </Typography>
                  <CircularProgress />
                  <Stack
                    direction="row"
                    justifyContent="space-around"
                    alignItems="center"
                  >
                    <Typography fontSize={26} fontFamily="Roboto Condensed">
                      Your Queue ID Number is:
                    </Typography>
                    <Box width={50} />
                    <Button sx={svc_btn_green}> ID: 2347 </Button>
                  </Stack>
                  <Box height={50} />

                  <Box width={40} />
                  <Stack direction="row">
                    <Box align="center">
                      <Fab
                        variant="circular"
                        sx={{
                          height: 155,
                          width: 155,
                          fontSize: 45,
                          backgroundColor: "#590D50",
                          color: "#CB72B7",
                        }}
                      >
                        12
                      </Fab>
                      <Typography>
                        <br /> POSITION IN THE QUEUE
                      </Typography>
                    </Box>
                    <Box width={60} />
                    <Box>
                      <Fab
                        variant="circular"
                        sx={{
                          height: 155,
                          width: 155,
                          fontSize: 45,
                          backgroundColor: "#590D50",
                          color: "#CB72B7",
                        }}
                      >
                        12
                      </Fab>
                      <Typography>
                        <br /> WAIT TIME
                      </Typography>
                    </Box>
                  </Stack>
                </Box>
                <Box height={50} />
              </Stack>
            </Stack>
            <Stack alignItems="center" justifyContent="center" direction="row">
              <Typography my={4} sx={{ ...typ_roboto_sub }}>
                LOCATION DETAILS
              </Typography>{" "}
              <Box width={50} />
              <Button
                type="submit"
                sx={btn_maps_hrs}
                onClick={() => console.log("maps will open")}
              >
                <Box component="img" padding={1} src={maps} alt="test" />
                MAPS
              </Button>
            </Stack>
            <Box align="center">
              <Typography sx={{ ...typ_roboto_header }}>
                [WALK-INS ALLOWED - MUST QUEUE]
              </Typography>{" "}
              <Box height={30} />
              <Button
                type="submit"
                sx={btn_maps_hrs}
                onClick={() => console.log("hours will open")}
              >
                <Box
                  component="img"
                  padding={1}
                  height={60}
                  src={hours}
                  alt="test"
                />
                HOURS
              </Button>
            </Box>
          </Box>
          <Stack justifyContent="space-evenly" alignItems="center" spacing={8}>
            <Box
              align="center"
              sx={{
                background: "#1F1E3174",
                border: "solid 7px #141523",
                borderRadius: 4,
                // width: "400px",
              }}
            >
              <Typography sx={{ ...typ_roboto_sub }}>QUEUE STATUS</Typography>
              <Stack direction="row" justifyContent="center">
                <Box>
                  <Fab
                    variant="circular"
                    sx={{
                      height: 80,
                      width: 80,
                      fontSize: 25,
                      backgroundColor: "#590D50",
                      color: "#CB72B7",
                    }}
                  >
                    12
                  </Fab>
                  <Typography>
                    <br /> POSITION IN THE QUEUE
                  </Typography>
                </Box>
                <Box width={40} />
                <Box>
                  <Fab
                    variant="circular"
                    sx={{
                      height: 80,
                      width: 80,
                      fontSize: 25,
                      backgroundColor: "#590D50",
                      color: "#CB72B7",
                    }}
                  >
                    12
                  </Fab>
                  <Typography>
                    <br /> WAIT TIME
                  </Typography>
                </Box>
              </Stack>
            </Box>
            <Box
              align="center"
              sx={{
                background: "#74657774",
                border: "solid 4px #89177590",
                borderRadius: 4,
                height: "250px",
                width: "500px",
              }}
            >
              <Typography my={4} sx={{ ...typ_roboto_sub }}>
                DO YOU HAVE EVERYTHING YOU NEED?
              </Typography>
              <Button
                type="submit"
                size="large"
                minHeight={90}
                startIcon={<DoneOutlineRounded />}
                onClick={() => navigate("/CheckDocs4Services")}
                sx={{ ...svc_btn_green }}
              >
                DOCUMENTS CHECK
              </Button>
            </Box>
            <Box
              align="center"
              sx={{
                background: "#523C5680",
                border: "solid 4px #841A7280",
                borderRadius: 4,
                height: "250px",
                width: "500px",
              }}
            >
              <Typography my={4} sx={{ ...typ_roboto_sub }}>
                PREFER TO PLAN AHEAD?
              </Typography>
              <Button
                type="submit"
                startIcon={<Groups2Rounded />}
                onClick={() => navigate("/MultipleServicesStart")}
                sx={{ borderRadius: 4, height: 58 }}
              >
                MAKE APPOINTMENT
              </Button>
            </Box>{" "}
          </Stack>{" "}
        </Stack>
      </Box>
    </>
  );
};

export default QueueFinalStage;
