import {
  Stack,
  Checkbox,
  ListItemText,
  Typography,
  Button,
  Divider,
  Fab,
  Stepper,
  Step,
  StepLabel,
  IconButton,
  InputLabel,
  Collapse,
} from "@mui/material";
import "../components/Services/walkthru.css";
import {
  circle_fab,
  paginationGreen,
  que_bg_box_dark,
  que_bg_box_light,
  svc_blue_btn,
  svc_btn_green,
  svc_btn_purple,
  typ_roboto_header,
  typ_roboto_sub,
} from "../components/Services/WalkthruCSS.jsx";
import { Outlet, useNavigate } from "react-router-dom";
import MainHeaderServices from "../components/MainHeaderServices";
import LocationQueueInPage from "./LocationQueueInPage";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Chip from "@mui/material/Chip";
import { useState } from "react";
import { SkipPreviousRounded } from "@mui/icons-material";
import QueueAddVehiclesModal from "./QueueAddVehiclesModal.jsx";
import { queueInMain } from "../imgs/index.js";
import QueueSelectLocation from "./QueueSelectLocation.jsx";
import QueueInfoModal from "./QueueInfoModal.jsx";

const QueueIn = () => {
  //State to see which Service is selected
  const [serviceCheckedIndex, setServiceCheckedIndex] = useState(null);
  //State to see which Location is selected
  const [locationCheckedIndex, setLocationCheckedIndex] = useState(null);
  const [activeStep, setActiveStep] = useState(0);
  const navigate = useNavigate();
  const steps = ["Select Service", "Select Location", "Join Queue"];
  const handleNext = () => {
    if (steps.length - 1 !== activeStep) setActiveStep(activeStep + 1);
  };
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  const [multVehicleOpen, setMultVehicleOpen] = useState(false);
  //functions for selection list
  const ITEM_HEIGHT = 120;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4 + ITEM_PADDING_TOP,
        width: 650,
        background: "#200B5B53",
        color: "#E7DEFF",
        borderRadius: 12,
        hover: "#4E1BE5",
        border: "solid px #a5c077",
      },
    },
  };
  const [service, setService] = useState([]);
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setService(typeof value === "string" ? value.split(",") : value);
  };
  const names = [
    "Arrival Private Shipment",
    "Arrival IAL Shipment",
    "Arrival HHG Shipment",
    "Arrival Driving EU",
    "Arrival Driving NON-EU",
    "Gained/Retained Logistical Support", // #Career Change
    "Separating/Retiring: Staying in DEU with Logistical Support",
    "Separating/Retiring: Staying in DEU without Logistical Support",
    "Separating/Retiring: Leaving DEU",
    "Separating/Retiring: Terminal Leave",
    "Bought NEW EU SPEC Vehicle from Local National/Dealership",
    "Bought OLD EU SPEC Vehicle from Local National/Dealership",
    "Bought NEW US SPEC Vehicle from Local National/Dealership",
    "Bought OLD US SPEC Vehicle from Local National/Dealership",
    "Sold EU SPEC Vehicle to Local National/Dealership",
    "Sold US SPEC Vehicle to Local National/Dealership",
    "Selling Vehicle to DOD ID Holder",
    "Buying Vehicle from DOD ID Holder",
    "Disposing Vehicle with MWR",
    "Disposing Vehicle NOT with MWR",
    "Need to Ship Vehicle, but has Temp Plates",
    "Need to Sell Vehicle, but Registration is Expired",
    "Need to Sell Vehicle, but has Temp Plates",
    "Departure IAL Shipment",
    "Departure Private Shipment",
    "Departure HHG Shipment",
    "Departure Driving",
    "Departure Shipment Request for QQ Shipping Plates",
    "Disability Placard",
    "Fuel Ration Request",
    "Suspense Clearance",
    "License Suspended/Revoked",
    "Insurance Suspended",
    "Insurance Cancelled",
    "Deployment Services",
    "Need Power of Attorney",
    "Need an Agent Owner",
    "Renew Registration: Permanent Plates",
    "Renew Registration: Non-Operational",
    "Initial Registration: Non-Operational",
    "Expired Registration: Permanent Plates",
    "Expired Registration: Non-Operational", //Becomes nonop renewal
    "Expired Registration: Temp Plates",
    "Expired Registration: 2nd Temp Plates",
    "Request for Initial Temp Plates",
    "Request for Second Set Temp Plates",
    "Request for Third Set Temp Plates",
    "Request for Permanent Plates",
    "Cannot Pass Inspection (has Permanent Plates)",
    "Update or Change Registration Information",
    "Add a Joint Owner or Additional Driver",
    "Update Personal Information (Rank, Name, Unit..)",
    "Update Address",
    "Update Insurance",
    "Remove Lien Holder",
    "Lost or Stolen Registration",
    "Replace Inspection Sticker",
    "Replace Environmental Sticker",
    "Lost or Stolen Plates",
    "Seized Plates",
  ];

  return (
    <>
      <QueueAddVehiclesModal
        open={multVehicleOpen}
        handleClose={() => setMultVehicleOpen(false)}
      />
      <Box
        flex={1}
        className="user_dashboard_page"
        sx={{
          "::-webkit-scrollbar-thumb": {
            background: "#200B5B43",
          },
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        {/* TODO: FIX - STEPPER NAV */}
        <MainHeaderServices />
        <Stack>
          <Stepper activeStep={activeStep} alternativeLabel sx={{ my: 0.5 }}>
            {steps.map((step) => (
              <Step key={step}>
                <StepLabel>{step}</StepLabel>
              </Step>
            ))}
            {/* {activeStep === 0 && ({ serviceCheckedIndex = serviceCheckedIndex}; {setServiceCheckedIndex=setServiceCheckedIndex})}; */}
            {/* {activeStep === 1}? : <Collapse></Collapse> : */}

            {/* (
            {activeStep === 1} ? {navigate("/QueueIn/LocationSelection")}: {}); */}
            {/* && (
                <LocationQueueInPage
                locationCheckedIndex={locationCheckedIndex}
                setLocationCheckedIndex={setLocationCheckedIndex}
                />
              )} */}
            {/* {activeStep === 2} */}
            {/* // && <QueueDashboard /> */}
          </Stepper>
        </Stack>
        {/* </Box>
    </>
  );
}; 
export default QueueIn; */}
        <Stack>
          <Stack direction="row" py={2} justifyContent="space-evenly">
            <Box
              sx={{
                background: "#6A5B9B14",
                border: "solid 5px #3E3A51",
                borderRadius: 4,
                width: "800px",
              }}
            >
              <Box align="center">
                <Typography
                  fontSize={30}
                  fontFamily="Roboto Condensed"
                  py={1}
                  flexShrink="shrink"
                  px={20}
                >
                  SERVICE SELECTION
                </Typography>

                <FormControl
                  sx={{
                    display: "flex",
                    m: 1,
                    width: 650,
                    background: "#200B5B43",
                    borderColor: "#a5c077",
                    borderWidth: 3,
                    borderStyle: "solid",
                    borderRadius: 4,
                  }}
                >
                  <InputLabel id="label"></InputLabel>
                  <Select
                    sx={{ display: "flex" }}
                    multiple
                    open={open}
                    onOpen={handleOpen}
                    onClose={handleClose}
                    autoWidth
                    value={service}
                    onChange={handleChange}
                    labelId="label"
                    id="select"
                    renderValue={(selected) => (
                      <Box
                        sx={{
                          display: "flex",
                          flexWrap: "wrap",
                          gap: 1,
                          borderRadius: 12,
                        }}
                      >
                        {selected.map((value) => (
                          <Chip
                            key={value}
                            label={value}
                            variant="outlined"
                            //   TODO: MAKE CHIPS DELETABLE onDelete={handleDelete(value)}
                            sx={{
                              background: "#536dfe20",

                              color: "#e2d8ff",
                              border: "solid 1.5px #0F0D13",

                              fontFamily: "Roboto Condensed",
                              fontSize: "18px",
                              display: {
                                filter: "drop-shadow(1px 1px 0.5px  #a5c07790)",
                              },
                            }}
                          />
                        ))}
                      </Box>
                    )}
                    MenuProps={MenuProps}
                  >
                    {names.map((name) => (
                      <MenuItem key={name} value={name}>
                        <Checkbox
                          sx={{ background: "#1F133E63", color: "#B7D32E" }}
                          checked={service.indexOf(name) > -1}
                        />
                        <ListItemText primary={name} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>{" "}
              <Box
                component="img"
                src={queueInMain}
                alt="astrocomputer"
                height="350px"
                sx={{ position: "absolute", bottom: "30%", left: "31%" }}
              />
            </Box>
            <Box
              align="center"
              sx={{
                background: "#1F1E3174",
                border: "solid 7px #141523",
                borderRadius: 4,
                width: "1400px",
              }}
            >
              <Stack alignItems="center" justifyContent="center">
                <Stack
                  direction="row"
                  alignItems="center"
                  sx={{
                    my: 5,
                    background: "#1F1E3174",
                    border: "solid 5px #6A5B9B",
                    borderRadius: 4,
                    p: 4,
                    width: "1100px",
                  }}
                >
                  <Stack alignItems="center">
                    <Typography sx={{ ...typ_roboto_header }}>
                      [WALK-INS ALLOWED - MUST QUEUE]
                    </Typography>
                    <Typography my={4} sx={{ ...typ_roboto_sub }}>
                      NEED TO SERVICE MULTIPLE VEHICLES?
                    </Typography>
                    <Button
                      type="submit"
                      sx={{ ...svc_btn_purple }}
                      onClick={() => setMultVehicleOpen(true)}
                    >
                      ADD ADDITIONAL VEHICLE
                    </Button>
                  </Stack>
                  <Divider width="2px" orientation="vertical" color="#D2F041" />
                  <Box
                    ml="7%"
                    sx={{
                      background: "#645C7F44",
                      border: "solid 3px #B0A4DC",
                      borderRadius: 4,
                      height: "250px",
                      width: "400px",
                    }}
                  >
                    <Typography sx={typ_roboto_sub}>QUEUE STATUS</Typography>
                    <Stack direction="row" justifyContent="space-evenly">
                      <Box>
                        <Fab variant="circular" sx={{ ...circle_fab }}>
                          12
                        </Fab>
                        <Typography>
                          <br /> IN QUEUE
                        </Typography>
                      </Box>
                      <Box>
                        <Fab
                          variant="circular"
                          sx={{
                            fontSize: 34,
                            height: 100,
                            width: 100,
                            color: "#6a5b9b",
                            background: "#CBBEFF",
                            // sx={{ ...circle_fab }}>
                          }}
                        >
                          220
                        </Fab>
                        <Typography>
                          <br />
                          WAIT TIME
                        </Typography>
                      </Box>
                    </Stack>
                  </Box>
                </Stack>
                <Stack
                  direction="row"
                  justifyContent="space-around"
                  alignItems="center"
                  spacing={8}
                >
                  <Box sx={que_bg_box_light}>
                    <Typography my={4} sx={{ ...typ_roboto_sub }}>
                      DO YOU HAVE EVERYTHING YOU NEED?
                    </Typography>
                    <Button
                      type="submit"
                      onClick={() => navigate("/CheckDocs4Services")}
                      sx={{ ...svc_blue_btn }}
                    >
                      DOCUMENTS CHECK
                    </Button>
                  </Box>
                  <Box sx={que_bg_box_dark}>
                    <Typography my={4} sx={{ ...typ_roboto_sub }}>
                      PREFER TO PLAN AHEAD?
                    </Typography>
                    <Button
                      type="submit"
                      onClick={() => navigate("/UserDashboard/appointments")}
                      sx={{ ...svc_btn_green }}
                    >
                      MAKE APPOINTMENT
                    </Button>
                  </Box>
                </Stack>
              </Stack>
              <Box align="right" mx={5} my={5}>
                <Button
                  type="submit"
                  onClick={
                    ({ handleNext },
                    () => navigate("/QueueIn/LocationSelection"))
                  }
                  sx={svc_blue_btn}
                >
                  {activeStep === steps.length - 1 ? "Finish" : "Next"}
                </Button>
              </Box>
            </Box>
          </Stack>
          <IconButton
            disabled={activeStep === 0}
            type="submit"
            onClick={({ handleBack }, () => navigate("/"))}
          >
            <SkipPreviousRounded sx={paginationGreen} />
          </IconButton>
        </Stack>
      </Box>
    </>
  );
};
export default QueueIn;
