import { Stack, Typography, Button, Divider, Fab } from "@mui/material";
import "../components/Services/walkthru.css";
import {
  btn_maps_hrs,
  svc_btn_green,
  typ_roboto_sub,
  svc_btn_pink,
} from "../components/Services/WalkthruCSS.jsx";
import { useNavigate } from "react-router-dom";
import MainHeaderServices from "../components/MainHeaderServices";
import Box from "@mui/material/Box";

const CheckDocs4Services = () => {
  const navigate = useNavigate();
  return (
    <>
      <Box
        className="services_bg services_bgtransp"
        sx={{
          "::-webkit-scrollbar-thumb": {
            background: "#0060A943",
          },
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <Stack alignItems="center" sx={{ mt: 3 }}>
          <Button sx={svc_btn_pink} onClick={() => navigate("/UserDashboard")}>
            Dashboard
          </Button>
        </Stack>
        <Stack py={2} direction="row" justifyContent="space-evenly">
          <Box
            py={2}
            alignItems="center"
            justifyContent="space-evenly"
            sx={{
              background: "#4B004320",
              border: "solid 4px #3E3A5154",
              borderRadius: 4,
              width: "1200px",
            }}
          >
            <Stack alignItems="space-between" direction="row">
              <Stack>
                <Box justifyContent="space-between" align="center">
                  <Typography
                    fontSize={50}
                    fontFamily="FIRA SANS EXTRA CONDENSED"
                    py={1}
                  >
                    Want to save your progress?
                  </Typography>
                  <Divider
                    sx={{
                      borderBottom: "4px solid green",
                      width: "80%",
                    }}
                  />
                  <Stack
                    direction="row"
                    justifyContent="space-around"
                    alignItems="center"
                  >
                    <Typography fontSize={26} fontFamily="Roboto Condensed">
                      Need to find an important document or come back after
                      dinner? Want to be able to verify your documents meet the
                      requirements?
                    </Typography>
                  </Stack>
                  <Box height={50} />
                  <Box width={40} />
                  <Stack
                    sx={{
                      background: "#523C5680",
                      border: "solid 4px #841A7280",
                      borderRadius: 4,
                      padding: 3,
                      width: "70%",
                    }}
                    justifyContent="space-around"
                    alignItems="center"
                  >
                    <Typography sx={{ ...typ_roboto_sub }}>
                      Your progress and records will be saved automatically if
                      you log in!
                    </Typography>
                    <Stack direction="row">
                      <Box align="center">
                        <Button sx={btn_maps_hrs} onClick={() => navigate("/")}>
                          Login
                        </Button>
                      </Box>
                      <Box width={60} />
                      <Box>
                        <Button
                          sx={svc_btn_green}
                          onClick={() => navigate("/Register")}
                        >
                          Create an Account
                        </Button>
                      </Box>
                    </Stack>
                  </Stack>
                </Box>
                <Box height={50} />
              </Stack>
            </Stack>
            <Stack alignItems="center" justifyContent="center" direction="row">
              <Typography my={4} sx={{ ...typ_roboto_sub }}>
                Staying logged-out? You may generate a pin that will save your
                information for 7 days.
              </Typography>{" "}
            </Stack>
            <Stack
              direction={"row"}
              justifyContent="space-around"
              alignItems="center"
            >
              <Stack
                spacing={3}
                sx={{
                  background: "#523C5680",
                  border: "solid 4px #841A7280",
                  borderRadius: 4,
                  padding: 3,
                  alignItems: "center",
                }}
              >
                <Typography>
                  To skip this walk-through and see a list of requirements ONLY:{" "}
                </Typography>
                <Button sx={btn_maps_hrs} onClick={() => navigate("/")}>
                  {" "}
                  Checklists
                </Button>
              </Stack>
              <Stack
                spacing={1}
                sx={{
                  background: "#523C5680",
                  border: "solid 4px #841A7280",
                  borderRadius: 4,
                  padding: 3,
                  alignItems: "center",
                }}
              >
                <Typography>Pin Number:</Typography>
                <Fab
                  variant="extended"
                  sx={{
                    backgroundColor: "#590D50",
                    color: "#CB72B7",
                  }}
                >
                  123456
                </Fab>
                <Typography>Use this PIN to return at a later time.</Typography>
              </Stack>
            </Stack>
          </Box>
        </Stack>
      </Box>
    </>
  );
};

export default CheckDocs4Services;
