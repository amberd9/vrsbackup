import {
  Button,
  Typography,
  Dialog,
  useMediaQuery,
  DialogContent,
  DialogActions,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Box,
  IconButton,
} from "@mui/material";
import { useState } from "react";
import { astroAppointment } from "../imgs/Avatars/AppointmentPageImages";
import { cancel } from "../imgs";

// Providing a splash screen for the appointments tab in User Dashboard
const AppointmentsSplash = () => {
  const isLargeScreen = useMediaQuery("(min-width:1000px)");
  const [activeStep, setActiveStep] = useState(0);
  const [open, setOpen] = useState(false);

  // Provides next, back, and close functionality
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  const handleComplete = () => {
    setOpen(false);
    setActiveStep(0);
  };

  // Provides the text for each step
  const steps = [
    {
      label: "Appointment Page",
      description: (
        <Typography component="span">
          Use this section to create and review or respond to requests for VRS
          appointment services. <br /> [Note: Use the “Instructions” link for
          additional help.] <br /> To schedule an appointment, VRS must verify
          that all required paperwork is complete & accurate. <br /> Submitting
          documents is easy & helps guarantee a successful visit for everyone.
        </Typography>
      ),
    },
    {
      label: "Appointment Information",
      description: (
        <Typography component="span">
          First, please ensure your vehicle information in the Vehicles tab is
          up to date for a faster submission. <br /> Also update any personal
          information in your User drawer using the “Edit Profile” option.
        </Typography>
      ),
    },
    {
      label: "Appointment Steps",
      description: (
        <Typography component="span">
          To begin, select START NEW REQUEST and follow the prompts. <br />{" "}
          Note: You can access additional hints & tips in the walk-through by
          hovering over items with your cursor. <br /> In this section, you can
          continue previously started requests. <br /> You may also review &
          correct any requests that are returned. <br /> Responses to requests
          will appear as notifications in your User drawer & be sent via e-mail.
        </Typography>
      ),
    },
    {
      label: "Submit Request",
      description: (
        <Typography component="span">
          Once VRS approves your paperwork you may schedule an appointment in
          the “Appointments” tab. <br /> VRS encourages you to plan ahead and
          schedule an appointment for any service with us. <br /> Note: Please
          allow VRS up to 72 hours to respond to requests.
        </Typography>
      ),
    },
  ];
  return (
    <>
      <Box>
        <Button
          size="small"
          color="secondary"
          onClick={() => setOpen(true)}
          sx={{
            borderRadius: 3,
          }}
        >
          Instructions
        </Button>
      </Box>
      <Dialog open={open} onClose={handleComplete} maxWidth="lg">
        <DialogContent sx={{ maxWidth: "1000px" }}>
          <Typography textAlign={"center"} variant="h6">
            Welcome to your Appointments!
          </Typography>
          {/* This is the image for the top right section of the splash page */}
          <Box
            component="img"
            src={astroAppointment}
            alt="Astronaut Laptop"
            sx={{
              height: 100,
              position: "absolute",
              top: 10,
              right: 10,
              display: { xs: "none", sm: "none", md: "block" },
            }}
          />
          {/* Maps the steps */}
          <IconButton
            sx={{ position: "absolute", top: 5, right: 5 }}
            size="small"
            onClick={handleComplete}
          >
            <img src={cancel} alt="cancel" height="30px" />
          </IconButton>
          <Stepper activeStep={activeStep} orientation="vertical">
            {steps.map((step, index) => (
              <Step key={index}>
                <StepLabel>{step.label}</StepLabel>
                <StepContent>
                  <Typography
                    sx={{
                      fontSize: isLargeScreen ? "20px" : "10px",
                    }}
                  >
                    {step.description}
                  </Typography>
                </StepContent>
              </Step>
            ))}
          </Stepper>
        </DialogContent>
        <DialogActions>
          {activeStep === steps.length - 1 ? (
            <Button onClick={handleComplete}>Continue</Button>
          ) : (
            <>
              <Button disabled={activeStep === 0} onClick={handleBack}>
                Back
              </Button>
              <Button variant="contained" onClick={handleNext}>
                Next
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>
    </>
  );
};

export default AppointmentsSplash;
