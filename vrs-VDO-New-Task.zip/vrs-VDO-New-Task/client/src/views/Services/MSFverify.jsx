import { Box, Button, Stack, Typography } from "@mui/material";
import MainHeaderServices from "../../components/MainHeaderServices";

import { friendlyreminder, msflarge, wilkommen } from "../../imgs";
import ServicesNav from "../../components/Dashboard/ServicesNav";
import { useState } from "react";
import UploadMSF from "../../components/Services/UploadMSF";
import { useNavigate } from "react-router-dom";
import RequestNav from "../../components/RequestPage/RequestNav";
import SingleVehicleFinalizedModal from "../../components/Services/SingleVehicleFinalizedModal";
import UploadTemplate from "../../components/Services/UploadTemplate";

// TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE
// TODO: NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY
// TODO: USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES

const MSFverify = () => {
  const [uploadOpen, setUploadOpen] = useState(false);
  const navigate = useNavigate();
  const [singleVehicleFinalizedOpen, setSingleVehicleFinalizedOpen] =
    useState(true);
  return (
    <>
      <UploadMSF open={uploadOpen} handleClose={() => setUploadOpen(false)} />
      <SingleVehicleFinalizedModal
        open={singleVehicleFinalizedOpen}
        handleClose={() => setSingleVehicleFinalizedOpen(false)}
      />
      <Box className="requestentrance_MSF">
        {/* still trying to perfect the class layering of images here....*/}
        <Stack>
          <MainHeaderServices />
          <ServicesNav />
          <Box
            className="sticky2"
            sx={{
              width: "12%",
              position: "fixed",
              mt: 10,
            }}
          >
            <RequestNav />
          </Box>
        </Stack>

        <Typography
          align="center"
          mt={20}
          color="#EBFFE7"
          sx={{ fontSize: "40px", fontFamily: "Fira Sans Extra Condensed" }}
        >
          Please DO NOT forget to bring your valid MSF card to your appointment!
        </Typography>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="center"
          spacing={5}
        >
          <img src={msflarge} height={400} width={780} />
          <Stack>
            <Box height={140} />
            <Button onClick={() => setUploadOpen(true)}>Got It!</Button>
            <Box height={80} />
          </Stack>
          <Stack>
            <Box ml={10} mt={3} align="center">
              <Typography
                color="text.alert"
                sx={{
                  fontStyle: "Italic",
                  fontFamily: "Roboto Condensed",
                  fontSize: "20px",
                  fontWeight: "light",
                }}
              >
                Still need assistance?
              </Typography>
              <Box height={4} />
              <Button>MSF HELP</Button>
            </Box>
          </Stack>
        </Stack>
        <Box py={18}>
          <Typography
            align="center"
            color="#8cffff"
            fontStyle="italic"
            fontWeight="light"
          >
            MSF RESOURCES <br /> <br /> Recreational Vehicles in Deutschland
            <br />
            <br />
          </Typography>
        </Box>
      </Box>
    </>
  );
};
export default MSFverify;
