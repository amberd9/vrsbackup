import React from "react";
import { useNavigate } from "react-router-dom";
import { hhgVerify } from "../../imgs";
import CheckBoxTemplate from '../../components/NewRequests/CheckBoxTemplate.jsx';
import { Stack } from "@mui/material";

const label = { inputProps: { "aria-label": "Checkbox demo" } };

const HHGPaperworkVerify = () => {
  const navigate = useNavigate();
  return (
    <CheckBoxTemplate
    header1="You will need the following documents to help us"
    header2="service you for this request."
    cardHeader={
      <>
        <Stack>
          I verify I have and will present my HHG paperwork that includes VIN,
        </Stack>
        <Stack>
           Make, Model & Year of my vehicle at my appointment.
        </Stack>
      </>
    }
    cardFooter=" Resources (Click Here)"
    footerLink=""
    backLink="/LienMemorandum"
    continueLink="/HHGPaperworkUpload"
    image={hhgVerify}
  />
  );
};

export default HHGPaperworkVerify;
