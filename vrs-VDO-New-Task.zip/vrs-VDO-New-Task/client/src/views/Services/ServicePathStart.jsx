import { Box, Stack } from "@mui/material";
import MainHeaderServices from "../../components/MainHeaderServices";
import { wilkommen } from "../../imgs";
import ServicesNav from "../../components/Dashboard/ServicesNav";
import { Outlet } from "react-router-dom";
import RequestNav from "../../components/RequestPage/RequestNav";
import { hist_nav_style_box } from "../../components/Services/WalkthruCSS";

export default function ServicePathStart() {
  return (
    <Box className="requestentrance">
      <MainHeaderServices />
      <ServicesNav sx={{ background: "#1F1636" }} />
      <Stack direction="row">
        {/* TODO: GET SERVICES/NAV COMPONENT to stick without rendering buttons useless */}
        <RequestNav sx={hist_nav_style_box} />
        <Stack alignItems="center" flex={0.9} justifyContent="center">
          <Box component="img" src={wilkommen} alt="wilkommen" />
          <Outlet />
        </Stack>
      </Stack>
    </Box>
  );
}
