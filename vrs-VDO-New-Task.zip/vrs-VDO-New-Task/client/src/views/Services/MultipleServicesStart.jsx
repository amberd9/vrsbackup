import React from "react";
import { Box, Stack } from "@mui/material";
import MainHeaderServices from "../../components/MainHeaderServices";
import { wilkommen } from "../../imgs";
import ServicesNav from "../../components/Dashboard/ServicesNav";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import InformationalModal from "../../components/Services/InformationalModal";

// TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE  NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY  USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES

const MultipleServicesStart = () => {
  const [modalOpen, setModalOpen] = useState(true);
  // THIS IS FOR THE SERVICES PATH AFTER MULTIPLE VEHICLES QUESTION HAS BEEN ASKED AND ANSWERED
  return (
    <>
      <InformationalModal
        open={modalOpen}
        handleModal={() => setModalOpen(false)}
      />

      <Box className="services_bg services_bgtransp">
        <MainHeaderServices />
        <ServicesNav className="services_bg services_bgtransp" />
        <Stack
          direction="row"
          alignItems="center"
          className="sticky2"
          flex={1}
          position="relative"
          justifyContent="center"
        >
          <Box
            className="sticky2"
            component="img"
            src={wilkommen}
            alt="wilkommen"
            sx={{
              opacity: "20%",
              position: "center",
            }}
          />
        </Stack>
      </Box>
    </>
  );
};
export default MultipleServicesStart;
