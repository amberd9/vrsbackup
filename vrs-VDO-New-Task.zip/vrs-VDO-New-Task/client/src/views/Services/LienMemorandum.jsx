import {
  Box,
  Divider,
  Paper,
  Stack,
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Tooltip,
} from "@mui/material";
import {
  draganddrop as dragAndDrop,
  scanfile,
  uploadMSFred,
  uploadcancel,
  uploadfile as uploadFile,
  lienMemo,
} from "../../imgs";
import { useState } from "react";
import MainHeaderServices from "../../components/MainHeaderServices";
import ServicesNav from "../../components/Dashboard/ServicesNav";
import { FileUploader } from "react-drag-drop-files";
import { useNavigate } from "react-router-dom";
import RequestNav from "../../components/RequestPage/RequestNav";

const LienMemorandum = ({ open, handleClose }) => {
  const navigate = useNavigate();
  const FileTypes = ["jpeg", "jpg", "png", "pdf", "webp"];
  const [file, setFile] = useState();
  const [image, setImage] = useState(null);
  const handleChange = (file) => {
    setFile(file[0]);
    handleView(file[0]);
  };
  const handleView = (uploadedImage) => {
    const reader = new FileReader();
    reader.readAsDataURL(uploadedImage);
    reader.onload = () => {
      setImage(reader.result);
    };
  };

  return (
    <Box
      className="new_requests_page"
      sx={{
        borderRadius: 3,
        border: "2px solid #666886",
      }}
    >
      <Stack className="requestentrance sticky">
        <MainHeaderServices />
        <ServicesNav />
  
        <>
          <Box
            className="upload"
            sx={{
              width: 1000,
              maxWidth: "90vw",

              mx: "auto",
              mt: 4,
              backgroundColor: "#1A1429",
              borderRadius: "0px 0px 12px 12px",
            }}
          >
            <AppBar position="sticky">
              <Toolbar
                className="mainHeaderBar"
                sx={{ flexGrow: 1, justifyContent: "space-between" }}
              >
                <Typography
                  variant="h4"
                  color="#fccfef"
                  fontFamily="Fira Sans Extra Condensed"
                >
                  Please Upload your Lien Memorandum here.
                </Typography>
                <IconButton onClick={handleClose}>
                  <img src={uploadcancel} alt="cancel" height="40px" />
                </IconButton>
              </Toolbar>
            </AppBar>
            <Divider sx={{ border: "2px solid #4B0043" }} />
            <Stack
              sx={{
                p: 2,
                border: "3px solid #4B0043",
                borderTopWidth: 0,
                borderRadius: "0px 0px 12px 12px",
              }}
            >
              <Stack alignItems="flex-end" mr="10%">
                <img src={lienMemo} height={100} />
                <Stack
                  component={Paper}
                  sx={{
                    backgroundColor: "rgba(41, 1, 53, 60%)",
                    fontFamily: "Fira Sans Extra Condensed",
                    border: "1px #EDCDC1 solid",
                    borderRadius: 1,
                    p: 2,
                    width: "85%",
                  }}
                >
                  <Box sx={{ align: "left" }} className="transimg">
                    <img
                      src={uploadMSFred}
                      align="left"
                      alt="MSF Logo"
                      height="60px"
                    />
                  </Box>
                  <Box height="50px" />
                  <Stack alignItems="center">
                    <Stack direction="row" alignItems="center">
                      <FileUploader
                        handleChange={handleChange}
                        name="file"
                        types={FileTypes}
                        multiple={true}
                        label="Upload with Click or Drag and Drop a File Here"
                        hoverTitle="Drop File Here to Upload"
                        children={
                          <>
                            <Stack direction="row" alignItems="center">
                              <Box width="250px" align="right" mx="20px">
                                <>
                                  <Typography
                                    fontSize="20px"
                                    fontFamily="Roboto Condensed"
                                  >
                                    Browse/Choose File to Upload
                                  </Typography>
                                  <Typography
                                    fontSize="20px"
                                    fontFamily="Roboto Condensed"
                                  >
                                    OR
                                  </Typography>
                                  <Typography
                                    fontSize="20px"
                                    fontFamily="Roboto Condensed"
                                  >
                                    Drag and Drop File to Upload
                                  </Typography>
                                </>
                              </Box>
                              <Button variant="text">
                                <Stack
                                  direction="row-reverse"
                                  alignItems="center"
                                  justifyContent="flex-end"
                                >
                                  <Box
                                    component="img"
                                    src={dragAndDrop}
                                    alt="Drag and Drop"
                                    height="80px"
                                  />
                                  <img
                                    src={uploadFile}
                                    alt="Upload File"
                                    height="80px"
                                  />
                                </Stack>
                              </Button>
                              <Stack direction="row" justifyContent="right">
                                <Tooltip
                                  title={
                                    <Typography>
                                      Scanning documents is mobile only.
                                    </Typography>
                                  }
                                >
                                  <img
                                    src={scanfile}
                                    alt="Scan File"
                                    height="90px"
                                  />
                                  <Box width="100px" align="right"></Box>
                                </Tooltip>
                              </Stack>
                            </Stack>
                          </>
                        }
                      />
                    </Stack>
                    <Box height="50px" />
                  </Stack>
                </Stack>
                <Stack
                  component={Paper}
                  sx={{
                    backgroundColor: "rgba(41, 1, 53, 60%)",
                    fontFamily: "Fira Sans Extra Condensed",
                    border: "1px #EDCDC1 solid",
                    borderRadius: 1,
                    m: "15px 0px 25px 5px",
                    p: 2,
                    width: "600px",
                  }}
                >
                  <Typography
                    fontFamily="Roboto Condensed"
                    color="#F3DDF1"
                    align="right"
                  >
                    {file
                      ? `UPLOADED FILE: ${file.name}`
                      : `Please upload a valid Lien Memorandum.`}
                    <br />
                  </Typography>
                  <Stack direction="row"></Stack>
                  {image && <img src={image} width="60%" />}
                </Stack>
              </Stack>
              <Stack direction="row" justifyContent="right">
                <Button
                  color="secondary"
                  size="small"
                  sx={{
                    backgroundColor: "#384606",
                    borderColor: "#e0ff2f",
                    color: "#e0ff2f",
                  }}
                  onClick={() => navigate("/HHGPaperworkVerify")}
                >
                  CONTINUE
                </Button>
              </Stack>
            </Stack>
          </Box>
        </>
        <Typography textAlign={"center"}>
          Please Note: You are REQUIRED to bring ALL required documents to your
          appointment or services will not be rendered! Uploading documents on
          this website does not substitute your physical presentation of any
          required document at your appointment time.
        </Typography>
      </Stack>
    </Box>
  );
};

export default LienMemorandum;
