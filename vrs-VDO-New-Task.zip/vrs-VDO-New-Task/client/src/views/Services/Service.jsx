import { Box, Button, Stack } from "@mui/material";
import MainHeaderServices from "../../components/MainHeaderServices";
import ServicesNav from "../../components/Dashboard/ServicesNav";
import { Outlet } from "react-router-dom";
import { useState } from "react";
import { astroreddragon, astroservices } from "../../imgs";
import {
  btn_maps_hrs,
  hist_nav_style_box,
} from "../../components/Services/WalkthruCSS";
import RequestNav from "../../components/RequestPage/RequestNav";
import zIndex from "@mui/material/styles/zIndex";

const Service = () => {
  const [startSnack, setStartSnack] = useState(true);
  // const [uploadOpen, setUploadOpen] = useState(true);
  // ALL CHOOSE FIRST SERVICE - SITE SHOULD ALREADY TRACK AFFILIATION AND NUMBER AND TYPE OF VEHICLES BEING SERVICED
  return (
    <>
      <Box
        flex={1}
        alignItems="center"
        className="services_bg services_bgtransp"
      >
        <MainHeaderServices sx={{ zIndex: 1 }} />
        <ServicesNav sx={{ zIndex: 3, justifyContent: "space-around" }} />
        <Stack className="sticky2" position="relative" direction="row">
          <Stack>
            <Button
              type="submit"
              sx={{
                ...btn_maps_hrs,
                minHeight: "60px",
                fontSize: "18px",
                zIndex: 2,
              }}
            >
              <Box
                component="img"
                src={astroservices}
                height={50}
                alt="test"
                sx={{ px: 0.5 }}
              />
              MULTIPLE SERVICES NEEDED
            </Button>
            <RequestNav sx={hist_nav_style_box} />{" "}
          </Stack>
          {/* <Box
            component="img"
            className="transimg"
            // src={astroreddragon}
            height={150}
            position="absolute"
            top="-8%"
            left="88%"
            alt="astro_dragon"
          /> */}
        </Stack>

        <Outlet />
      </Box>
    </>
  );
};

export default Service;
