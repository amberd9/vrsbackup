import { Box, Divider, Stack } from "@mui/material";

import MainHeader from "../../components/MainHeader";
import UserNav from "../../components/Dashboard/UserNav";
import { dashboardBG, desertlandscape, reviewmirror } from "../../imgs";

export default function StartBasicDocsChecks() {
  return (
    <Box className="services_main">
      <MainHeader />

      <Stack direction="row">
        <Box className="sticky2" sx={{ width: "100%", position: "fixed" }}>
          <UserNav />
        </Box>
        <Stack flex={1}>
          <Divider color="#A68FEA" sx={{ borderWidth: 4 }} />
          <Box
            className="services_main_review "
            component="img"
            src={reviewmirror}
            sx={{ size: "100px" }}
          />
          <Box
            className="services_main_cardb"
            component="img"
            src={dashboardBG}
          />
          <Box
            className="services_main_desert"
            component="img"
            src={desertlandscape}
          />
        </Stack>
      </Stack>
    </Box>
  );
}
