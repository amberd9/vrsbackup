import { useState } from "react";
import {
  Button,
  Typography,
  Dialog,
  DialogContent,
  DialogActions,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Stack,
  IconButton,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
{
  /* <TODO>modal components that are common and held in modalmanager
import CancelIcon from "../components/Buttons/CancelIcon";</TODO>  */
}
import { cancel } from "../imgs";

const UserDashboardSplash = ({ iopen, handleCancel }) => {
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [open, setOpen] = useState(false);
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  const handleComplete = () => {
    setOpen(false);
  };
  const steps = [
    {
      label: "User Dashboard",
      description: (
        <Typography component="span">
          Help us help you have an easy & fail proof experience with vehicle
          registration!
          <br />
          Note: To revisit any of these instructions, just click on the
          Information button for a quick tutorial.
          <br />
          Many functions on this app have useful tooltips you can access by
          hovering over them with your cursor.
        </Typography>
      ),
    },
    {
      label: "Vehicle Information",
      description: (
        <Typography component="span">
          Here you may enter & track any stored information you have on your
          vehicles.
          <br />
          Remember to update your vehicle and profile information in this
          section for easier scheduling.
          <br />
          Note: Official changes to your registration (name, marriage, etc.)
          must still be done in person at VRS.
        </Typography>
      ),
    },
    {
      label: "Pending, past or new appointments",
      description: (
        <Typography component="span">
          To schedule an appointment, first visit the “Requests” tab to start a
          NEW request where VRS will help ensure that all your required
          paperwork is ready ahead of your visit.
          <br />
          <br />
          In Requests, you may also review or respond to any updates on any
          current or past requests.
          <br />
          <br />
          Once VRS approves your paperwork you may schedule an appointment at
          the “Appointments” tab.
          <br />
          <br />
          You may also manage any existing appointments or ones you've been
          approved for.
        </Typography>
      ),
    },
    {
      label: "Queue In",
      description: (
        <Typography component="span">
          We encourage you to plan ahead and schedule an appointment, but you
          may also choose instead to enter the Queue for most registration
          services.
          <br />
          The Queue-In service is managed on a first come, first serve basis.
          <br />
          Note: You may still use the “Check Documents” tool or PDF Guide to
          prepare for a successful visit even when choosing to use our Queue or
          walk-in services.
        </Typography>
      ),
    },
  ];
  return (
    <Dialog open={iopen} onClose={handleCancel} maxWidth="lg">
      <DialogContent>
        <Stack direction="row">
          <Typography textAlign="center" variant="h4">
            Welcome to your dashboard!
          </Typography>
          <IconButton
            sx={{ position: "absolute", top: 5, right: 5 }}
            size="small"
            onClick={handleCancel}
          >
            <img src={cancel} alt="cancel" height="30px" />
          </IconButton>
        </Stack>
        <Stepper activeStep={activeStep} orientation="vertical">
          {steps.map((step, index) => (
            <Step key={index}>
              <StepLabel>{step.label}</StepLabel>
              <StepContent sx={{ width: 800, maxWidth: "90vw" }}>
                <Typography>{step.description}</Typography>
              </StepContent>
            </Step>
          ))}
        </Stepper>
      </DialogContent>
      <DialogActions>
        {activeStep === steps.length - 1 ? (
          <Button onClick={handleComplete}>Continue</Button>
        ) : (
          <Stack direction="row" justifyContent="space-between" flex={1} mx={1}>
            <Button disabled={activeStep === 0} onClick={handleBack}>
              Back
            </Button>
            <Button variant="contained" onClick={handleNext}>
              Next
            </Button>
          </Stack>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default UserDashboardSplash;
