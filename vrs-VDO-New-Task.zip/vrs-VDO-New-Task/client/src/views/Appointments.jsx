import {
  Box,
  Button,
  Card,
  CardMedia,
  Stack,
  Typography,
  TextField,
  CardActions,
  Grid,
} from "@mui/material";
import { Map, PersonAddAlt1, Cancel, Edit } from "@mui/icons-material";
import { LocalizationProvider, DateCalendar } from "@mui/x-date-pickers";
// Needed to import this separately from above due to path finding issues
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import AppointmentsSplash from "./AppointmentsSplash";
import { useNavigate } from "react-router-dom";
import { astroCardAppointment } from "../imgs";

const Appointments = () => {
  const navigate = useNavigate();
  return (
    <>
      <Stack
        display="flex"
        spacing="1%"
        ml="11%"
        mt="1%"
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          overflowY: "auto",
          overflowX: "auto",
          borderRadius: 4,
        }}
      >
        <AppointmentsSplash />
        <Grid container justifyContent="space-evenly">
          <Grid item xs={12} sm={12} md={12} lg={5.5} xl={5.5} px={2}>
            <Card
              sx={{
                border: "2px solid #666886",
                borderRadius: 4,
                width: "100%",
              }}
              align="center"
            >
              <CardMedia>
                <Box
                  component="img"
                  src={astroCardAppointment}
                  alt="Astronaut id"
                  minHeight={120}
                  maxHeight={150}
                />
              </CardMedia>
              <Button
                sx={{ borderRadius: 4 }}
                startIcon={<PersonAddAlt1 />}
                onClick={() => navigate("/UserDashboard/scheduleappointment")}
              >
                Make A New Appointment
              </Button>
              <Typography variant="h6" padding={2}>
                You Have 2 Upcoming Appointments
              </Typography>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DateCalendar />
              </LocalizationProvider>
            </Card>
          </Grid>

          <Grid item xs={12} sm={12} md={12} lg={5.5} xl={5.5} px={2}>
            <Card
              sx={{
                border: "2px solid #666886",
                borderRadius: 4,
                width: "100%",
              }}
            >
              <Typography variant="h6" align="center">
                Appointment Details
              </Typography>
              <Box sx={{ padding: 2 }}>
                <TextField label="Appt. ID" variant="outlined" />
              </Box>
              <Stack padding={2} spacing={2}>
                <Box>
                  <TextField label="Date" variant="outlined" />
                  <Button
                    label="Maps"
                    variant="outlined"
                    startIcon={<Map />}
                    sx={{ minWidth: "14rem", minHeight: "3.5rem" }}
                  >
                    MAP
                  </Button>
                </Box>
                <Box>
                  <TextField label="Time" variant="outlined" />
                  <TextField label="Location" variant="outlined" />
                </Box>
              </Stack>
              <Stack padding={2} spacing={2}>
                <TextField
                  label="POV"
                  variant="outlined"
                  multiline
                  maxRows={2}
                />

                <TextField
                  label="Service Type/Info"
                  variant="outlined"
                  multiline
                  maxRows={3}
                />
                <TextField
                  label="Considerations [i.e. Agent or Buyer Name]"
                  variant="outlined"
                  multiline
                  maxRows={3}
                />
              </Stack>
              <CardActions sx={{ justifyContent: "space-evenly", py: 3 }}>
                <Button startIcon={<Edit />}>EDIT</Button>
                <Button startIcon={<Cancel />}>CANCEL</Button>
              </CardActions>
            </Card>
          </Grid>
        </Grid>
      </Stack>
    </>
  );
};

export default Appointments;
