import { Box, Divider, Stack } from "@mui/material";
import DashNav from "../components/Dashboard/DashNav";
import MainHeader from "../components/MainHeader";
import UserNav from "../components/Dashboard/UserNav";
import { Outlet } from "react-router-dom";

export default function UserDashboard() {
  return (
    <Box className="user_dashboard_page">
      <MainHeader />
      <Stack flex={1}>
        <DashNav />
        <Divider variant="fullWidth" sx={{ borderWidth: 3 }} />
      </Stack>
      <Stack direction="row" flex={1} height="calc(100svh - 11.5rem)">
        <UserNav />
        <Box
          flex={1}
          sx={{ overflowY: "auto", maxHeight: "calc(100svh - 11.5rem)" }}
        >
          <Outlet />
        </Box>
      </Stack>
    </Box>
  );
}
