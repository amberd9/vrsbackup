import { Box, Button, Stack, Typography } from "@mui/material";
import React from "react";
import { hhg2Motorcycle, hhgMotorcycle } from "../imgs";
import { useNavigate } from "react-router-dom";
import MainHeaderServices from "../components/MainHeaderServices";
import ServicesNav from "../components/Dashboard/ServicesNav";

const HHGShipping = () => {
  const navigate = useNavigate();
  return (
    <Box className="new_requests_page">
      <Stack className="requestentrance sticky">
        <MainHeaderServices />
        <ServicesNav />
        <Box
          className="sticky2"
          sx={{ width: "100%", position: "fixed" }}
        ></Box>
      </Stack>
      <Stack spacing={3}>
        <Typography
          textAlign={"center"}
          variant="h1"
          sx={{
            color: "#fff",
            fontSize: { lg: "40px", xs: "20px" },
            fontFamily: "Fira Sans Extra Condensed",
          }}
        >
          Did you ship your motorcycle(s) through House Hold Goods?
        </Typography>
        <Stack direction={"row"} justifyContent={"space-evenly"}>
          <Stack>
            <Stack>
              <img src={hhgMotorcycle} />
            </Stack>
            <Button onClick={() => navigate("/WhichMethodUsed")}>NO</Button>
          </Stack>
          <Stack>
            <Stack>
              <img src={hhg2Motorcycle} />
            </Stack>
            <Button onClick={() => navigate("/HHGClass1License")}>Yes</Button>
          </Stack>
        </Stack>
        <Stack spacing={2} sx={{ textAlign: "center" }}>
          <Typography variant="h5">
            *Please Note: Sponsor MUST be present for ALL initial registrations
            OR spouse MUST have a POA.
          </Typography>
          <Typography variant="h5">
            *You will first need to register your POV BEFORE you try to pick up!
          </Typography>
          {/* TODO: Link needs to be implemented where "(Click Here)" is */}
          <Typography variant="h5">
            Need an Agent Owner or POA? (Click Here)
          </Typography>
        </Stack>
        <Typography
          variant="h6"
          sx={{
            textAlign: "center",
            color: "#91A930",
          }}
        >
          Resources (Click Here)
        </Typography>
      </Stack>
    </Box>
  );
};

export default HHGShipping;
