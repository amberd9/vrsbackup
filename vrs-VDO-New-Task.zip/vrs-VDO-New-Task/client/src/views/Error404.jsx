import { Typography, Box, Button } from "@mui/material";
import HomeNav from "../components/Buttons/HomeNav";

const Error404 = () => {
  return (
    <Box align="center" className="error404">
      <Typography variant="h5" align="center" my={5}>
        Error 404: Page Not Found - We're working diligently to get the issue
        solved!
      </Typography>
      <Button onClick={() => window.history.back()}>Go Back</Button>
      <HomeNav />
    </Box>
  );
};

export default Error404;
