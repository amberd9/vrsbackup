import eightsix from "./LandingPageImages/eightsix.svg";
import fivesixnine from "./LandingPageImages/fivesixnine.svg";
import sword from "./LandingPageImages/sword.svg";
import usag from "./LandingPageImages/usag.svg";
import userAstroAgent from "./DashboardImgs/userAstroAgent.png";
import userAstronautSedan from "./DashboardImgs/userAstronautSedan.png";
import userAstroPurpleMotor from "./DashboardImgs/userAstroPurpleMotor.png";
import userAstroShoppingCart from "./DashboardImgs/userAstroShoppingCart.png";
import userAstroYellowSports from "./DashboardImgs/userAstroYellowSports.png";
import appBarStars from "./DashboardImgs/appBarStars.svg";
import vrslogo from "./DashboardImgs/vrslogo.svg";
import stars from "./LandingPageImages/stars.svg";
import stars2 from "./LandingPageImages/stars2.png";
import stars3 from "./LandingPageImages/stars3.png";
import openrequestsmini from "./DashboardImgs/openrequestsmini.png";
import openrequestslarge from "./DashboardImgs/openrequestslarge.png";
import returnedrequestsmini from "./DashboardImgs/returnedrequestsmini.png";
import returnedrequestslarge from "./DashboardImgs/returnedrequestslarge.png";
import closedrequestsmini from "./DashboardImgs/closedrequestsmini.png";
import closedrequestslarge from "./DashboardImgs/closedrequestslarge.png";
import userAstroServices from "./DashboardImgs/userAstroServices.png";
import userRoboServices from "./DashboardImgs/userRoboServices.png";
import dashboardBG from "./Services/dashboardBG.png";
import desertlandscape from "./Services/desertlandscape.png";
import reviewmirror from "./Services/reviewmirror.webp";
import hhgVerify from "./Services/hhgVerify.png";
// import reviewmirror from "./Services/reviewmirror.png";
// import reviewmirror from "./Services/reviewmirror.svg";
import lienMemo from "./Services/lienMemo.png";
import queueMainDashboard from "./QueueInImages/queueMainDashboard.png";
import hhgMotorcycle from "./HHGimages/hhgMotorcycle.png";
import hhg2Motorcycle from "./HHGimages/hhg2Motorcycle.png";
import hhg3Motorcycle from "./HHGimages/hhg3Motorcycle.png";
import astrodrivinginredtruck from "./DashboardImgs/astrodrivinginredtruck.png";
import bluejeeptravelbg from "./Services/bluejeeptravelbg.webp";
import servicesSignout from "./Services/servicesSignout.webp";
import vrslogoservices from "./vrslogoservices.png";
import wilkommen from "./Services/wilkommen.webp";
import msflarge from "./Services/msflarge.webp";
import friendlyreminder from "./Services/friendlyreminder.webp";
import vehicle from "./vehicle.svg";
import logout from "./logout.svg";
import vehiclelanding from "./LandingPageImages/vehiclelanding.webp";
import landingcar1 from "./LandingPageImages/landingcar1.webp";
import queueInMain from "./QueueInImages/queueInMain.png";
import locationQueueIn from "./QueueInImages/locationQueueIn.png";
import uploadMSF from "./Services/uploadMSF.webp";
import uploadMSFred from "./Services/uploadMSFred.webp";
import servicesbackground from "./Services/servicesbackground.webp";
import servicesbackgroundtransparent from "./Services/servicesbackgroundtransparent.webp";
import scanfile from "./Services/scanfile.webp";
import draganddrop from "./Services/draganddrop.webp";
import uploadfile from "./Services/uploadfile.webp";
import uploadcancel from "./Services/uploadcancel.webp";
import green_car from "./green_car.png";
import cancel from "./cancel.png";
import uploadfileoptionscolumn from "./Services/uploadfileoptionscolumn.webp";
import astroReadingWCoffee from "./astroReadingWCoffee.webp";
import astroTV from "./astroTV.webp";
import astromoneyman from "./astromoneyman.webp";
import astroPinkDabber from "./astroPinkDabber.webp";
import astrochill from "./astrochill.webp";
import astroarmsfoldedleaning from "./astroarmsfoldedleaning.webp";
import astropuplescootershopping from "./astropuplescootershopping.webp";
import avatar2 from "./Avatars/avatar2.svg";
import germanleaving from "./Avatars/germanleaving.webp";
import astroCardAppointment from "./Avatars/AppointmentPageImages/astroCardAppointment.webp";
import astrocomputerrobofix from "./astrocomputerrobofix.webp";
import astrooutoflaptop from "./QueueInImages/astrooutoflaptop.webp";
import maps from "./QueueInImages/maps.png";
import hours from "./QueueInImages/hours.png";
import jugglingastro from "./Services/jugglingastro.webp";
import purplenav from "./purplenav.webp";
import astroservices from "./astroservices.webp";
import astroufo from "./LandingPageImages/astroufo.webp";
import astroreddragon from "./astroreddragon.webp";
import updateregistrationportal from "./Services/updateregistrationportal.webp";
import initialregportal from "./Services/initialregportal.webp";
import deregistration from "./Services/deregistration.webp";
import groupPOA from "./Services/groupPOA.webp";
import newjobwpeople from "./Services/newjobwpeople.webp";
import boughtcarpic from "./Services/boughtcarpic.webp";
import newarrivals from "./Services/newarrivals.webp";
import relocatingportal from "./Services/relocatingportal.webp";
import soldcarportal from "./Services/soldcarportal.webp";
import disposalportal from "./Services/disposalportal.webp";
import astrogas from "./Services/astrogas.webp";
import astrobluesportscar from "./Services/astrobluesportscar.webp";
import astrocelltravel from "./Services/astrocelltravel.webp";
import astroredmotorcycle from "./Services/astroredmotorcycle.webp";
import astrojointownermoped from "./Services/astrojointownermoped.webp";
import astromoonhello from "./Services/astromoonhello.webp";
import astroannouncement from "./Services/astroannouncement.webp";
import astrohandicapnonop from "./Services/astrohandicapnonop.webp";
import pinkastrotraveller from "./Services/pinkastrotraveller.webp";
import astrorocketbackpack from "./Services/astrorocketbackpack.webp";
import manInSuit from "./maninsuite.png";
export {
  manInSuit,
  astrorocketbackpack,
  pinkastrotraveller,
  astrohandicapnonop,
  astroannouncement,
  astromoonhello,
  astrojointownermoped,
  astroredmotorcycle,
  astrocelltravel,
  astrobluesportscar,
  astrogas,
  disposalportal,
  soldcarportal,
  relocatingportal,
  groupPOA,
  newarrivals,
  boughtcarpic,
  newjobwpeople,
  deregistration,
  initialregportal,
  updateregistrationportal,
  astroufo,
  astroreddragon,
  astroservices,
  purplenav,
  jugglingastro,
  hours,
  maps,
  astrooutoflaptop,
  astrocomputerrobofix,
  astroCardAppointment,
  germanleaving,
  avatar2,
  astropuplescootershopping,
  astroarmsfoldedleaning,
  astrochill,
  astroPinkDabber,
  astromoneyman,
  astroTV,
  astroReadingWCoffee,
  cancel,
  green_car,
  servicesbackgroundtransparent,
  servicesbackground,
  uploadcancel,
  logout,
  uploadfileoptionscolumn,
  uploadfile,
  draganddrop,
  scanfile,
  uploadMSFred,
  uploadMSF,
  friendlyreminder,
  msflarge,
  servicesSignout,
  vehicle,
  vehiclelanding,
  landingcar1,
  stars2,
  stars3,
  eightsix,
  fivesixnine,
  sword,
  usag,
  appBarStars,
  vrslogo,
  stars,
  userAstroAgent,
  userAstroPurpleMotor,
  userAstroShoppingCart,
  userAstroYellowSports,
  userAstronautSedan,
  openrequestsmini,
  openrequestslarge,
  returnedrequestsmini,
  returnedrequestslarge,
  closedrequestsmini,
  closedrequestslarge,
  userAstroServices,
  userRoboServices,
  dashboardBG,
  desertlandscape,
  reviewmirror,
  astrodrivinginredtruck,
  queueInMain,
  locationQueueIn,
  queueMainDashboard,
  hhgMotorcycle,
  hhg2Motorcycle,
  hhg3Motorcycle,
  bluejeeptravelbg,
  vrslogoservices,
  wilkommen,
  lienMemo,
  hhgVerify,
};
