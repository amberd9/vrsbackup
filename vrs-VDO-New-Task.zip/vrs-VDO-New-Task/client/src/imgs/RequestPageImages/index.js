import ClosedRequest from "./ClosedRequest.svg";
import OpenRequest from "./OpenRequest.svg";
import ReturnedRequest from "./ReturnedRequest.svg";
import ClosedRequestAstronaut from "./ClosedRequestAstronaut.svg";
import OpenRequestAstronaut from "./OpenRequestAstronaut.svg";
import ReturnedRequestAstronaut from "./ReturnedRequestAstronaut.svg";
import ReceivedMailAstronaut from "./ReceivedMailAstronaut.webp";
import VRSNewRequestsPanel from "./VRSNewRequestsPanel.webp";
import VRSRequestsGetStarted from "./VRSRequestsGetStarted.webp";
import Motorcycle from "./Motorcycle.webp";
import OrangeCar from "./OrangeCar.webp";
import SeeYouSoon from "./SeeYouSoon.png";
import IALCar from "./IALCar.png";
import LockedHouse from "./LockedHouse.png";
import greenmotorcycle from "./greenmotorcycle.webp";
import redSUV from "./redSUV.webp";
import BothMethodsCar from "./BothMethodsCar.webp";
import DroveCar from "./DroveCar.webp";
import ShippedCar from "./ShippedCar.webp";
import EmailRequests from "./EmailRequests.webp";
import DoDIDImage from "./DoDIDImage.webp"
import MoneyImage from "./MoneyImage.webp"
import PCSOrdersImage from "./PCSOrdersImage.webp"
import PreviousRegistrationImage from "./PreviousRegistrationImage.webp"
import USAREURImage from "./USAREURImage.webp"

export {
  redSUV,
  greenmotorcycle,
  ClosedRequest,
  OpenRequest,
  ReturnedRequest,
  ClosedRequestAstronaut,
  OpenRequestAstronaut,
  ReturnedRequestAstronaut,
  VRSNewRequestsPanel,
  VRSRequestsGetStarted,
  Motorcycle,
  OrangeCar,
  SeeYouSoon,
  ReceivedMailAstronaut,
  IALCar,
  LockedHouse,
  BothMethodsCar,
  DroveCar,
  ShippedCar,
  EmailRequests,
  DoDIDImage,
  MoneyImage,
  PCSOrdersImage,
  PreviousRegistrationImage,
  USAREURImage
};
