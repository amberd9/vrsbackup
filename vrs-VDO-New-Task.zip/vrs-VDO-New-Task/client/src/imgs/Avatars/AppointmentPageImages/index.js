import ClosedVehicle from "./ClosedVehicle.svg";
import OpenVehicle from "./OpenVehicle.svg";
import ReturnedVehicle from "./ReturnedVehicle.svg";
import astroAppointment from "./AstroAppointment.webp";

export { ClosedVehicle, OpenVehicle, ReturnedVehicle, astroAppointment };
