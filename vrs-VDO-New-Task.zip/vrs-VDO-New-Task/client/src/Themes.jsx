import { ThemeProvider, CssBaseline } from "@mui/material";
import createTheme from "@mui/material/styles/createTheme";
// NOTE:   sx={{ ...svc_blue_btn, borderColor: "#daf" }}
export const userDashboard = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#536dfe",
      dark: "#3846B6",
      contrastText: "#e1e4f9",
      // "#2A2D54",
      // "#e1e4f9",
    },
    secondary: {
      main: "#18ffff",
      dark: "#00e5ff",
      contrastText: "#024548",
    },
    tertiary: {
      main: "#ffb74d",
      contrastText: "#2B1700",
    },
    buttonsTertiary: {
      main: "#392000",
      contrastText: "#ffb74d",
    },
    buttonsCancel: {
      main: "#392000",
      contrastText: "#ffb74d",
    },
    background: {
      paper: "rgba(11,11,30,0.95)",
      // paper2: "#272332",
      default: "#110e22",
    },
    text: {
      primary: "#CBBEFF",
      secondary: "#ffb74d",
      tertiary: "#CBBEFF",
      stroke: "#2A2D54",
      disabled: "#316469",
      hint: "#8c9eff",
      fontFamily: "Fira Sans Extra Condensed",
    },
    info: {
      main: "#0091ea",
    },
    success: {
      main: "#009688",
    },
    divider: "#AAA3F0",
    // divider: "#eab294",
  },
  components: {
    MuiIcon: {
      defaultProps: {
        sx: { color: "#2BDEC8", fontSize: "large" },
      },
    },
    MuiTooltip: {
      defaultProps: {
        arrow: true,
        disableInteractive: true,
        slotProps: {
          arrow: { sx: { color: "#2A2D54" } },
          tooltip: {
            sx: { backgroundColor: "#2A2D54", color: "#c1dbf4" },
          },
        },
      },
    },
    MuiButton: {
      defaultProps: {
        variant: "contained",
        // color: "#33285E",
        fontFamily: "Fira Sans Extra Condensed",
        fontWeight: "Medium",
        fontSize: "22px",
      },
      styleOverrides: {
        root: {
          fontSize: "large",
          fontWeight: "Medium",
          borderRadius: 4,
          borderWidth: 4,
          borderStyle: "solid",
          boxShadow: "17px, 17px, 0rgba",
        },
      },
    },
    MuiTypography: {
      defaultProps: {
        // align: "center",
        fontFamily: "Roboto Condensed",
        fontWeight: "Regular",
        fontSize: "20px",
        // fontFamily: "Fira Sans Extra Condensed",
        // fontWeight: "Medium",
        // fontSize: "22px",
      },
      styleOverrides: {
        root: {
          // fontSize: "18px",
          // fontWeight: "Medium",
          // boxShadow: "17px, 17px, 0rgba",
        },
      },
    },
    //     // styleOverrides: {
    //     //   root: {
    //     // fontSize: "large",
    //     // borderRadius: 3,
    //     // borderWidth: 2,
    //     // borderStyle: "solid",
    //     // borderColor: "#AAA3F0",
    //   },
    //     },
    //   },
    // },
  },
});

export const UserDashboardThemeProvider = ({ children }) => {
  return (
    <ThemeProvider theme={userDashboard}>
      <CssBaseline />
      {children}
    </ThemeProvider>
  );
};

const servicePath = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#f374d5",
      contrastText: "#210d2b",
    },
    secondary: {
      main: "#e0ff4f",
      dark: "#cfea2e",
      contrastText: "#272f0b",
    },
    background: {
      paper: "#170d26",
      //  "rgba(14,4,16,0.86)",
      default: "#12060e",
    },
    text: {
      primary: "#f8bbd0",
      secondary: "#c9e25c",
      disabled: "#e6d5d7",
      hint: "#dfdaff",
      fontFamily: "Fira Sans Extra Condensed",
    },
    info: {
      main: "#1BE7FF",
    },
    success: {
      main: "#64dd17",
    },
    divider: "#936996",
    error: {
      main: "#f50057",
    },
  },
  components: {
    MuiIcon: {
      defaultProps: {
        sx: { color: "#2BDEC8", fontSize: "large" },
      },
    },
    MuiTooltip: {
      defaultProps: {
        arrow: true,
        disableInteractive: true,
        slotProps: {
          arrow: { sx: { color: "#936996" } },
          tooltip: {
            sx: { backgroundColor: "#936996", color: "#f7caec" },
          },
        },
      },
    },

    MuiButton: {
      defaultProps: {
        sx: {
          variant: "contained",
          backgroundColor: "#181E00",
          color: "#B7D32E",
          fontSize: "18px",
          borderRadius: 3,
          borderStyle: "solid",
          borderWidth: 2,
          borderColor: "#6C7F00",
        },
        // "pink &&": {
        //   sx: {
        //     backgroundColor: "#630858",
        //     color: "#f9a9f0",
        //     borderColor: "#ef15e4",
        //     "&:hover": {
        //       // height: "40px",
        //       opacity: 0.6,
        //       // transition: all 0.2s ease-in-out,
        //       // }
        //     },
        //   },
        // },
      },
    },
  },

  MuiTypography: {
    defaultProps: {
      sx: {
        fontFamily: "Fira Sans Extra Condensed",
        color: "#f4a4e1",

        borderRadius: 3,
        borderColor: "#EA33D7",
      },
    },
  },
});

export const ServicePathThemeProvider = ({ children }) => {
  return (
    <ThemeProvider theme={servicePath}>
      <CssBaseline />
      {children}
    </ThemeProvider>
  );
};

const queue = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#4c36d2",
      dark: "#8673c9",
      // light: "",
      contrastText: "#d7cfff",
    },
    secondary: {
      main: "#e0ff2f",
      dark: "#e0ff28",
      contrastText: "#384606",
    },
    // lightblue: { main: "#C5EDFF" },
    background: {
      paper: "rgba(24,21,30,0.86)",
      default: "#101014",
    },
    text: {
      primary: "#e4dcf5",
      dark: "#181E00",
      main: "#181E00",
      secondary: "#adc91e",
      disabled: "#b2bf92",
      hint: "#e7e2ff",
      lightblue: "#EAEAFF",
      tan: "#FCDCE3",
      alert: "#fc14c6",
      // error: "",
    },
    success: {
      main: "#00c853",
      dark: "#00c853",
    },
    divider: { main: "#e1bee7", dark: "#e1bee7" },
    error: {
      main: "#ff5449",
      dark: "#ff5449",
    },
    info: {
      main: "#1be7ff",
      dark: "#30cddc",
      contrastText: "#00838f",
    },
  },
  components: {
    MuiIcon: {
      styleOverrides: {
        root: { color: "#390033", fontSize: "large" },
      },
    },
    MuiTooltip: {
      defaultProps: {
        arrow: true,
        disableInteractive: true,
        slotProps: {
          arrow: { sx: { color: "#390033" } },
          tooltip: {
            sx: { backgroundColor: "#390033", color: "#c1dbf4" },
          },
        },
      },
    },
    Typography: {
      defaultProps: {
        fontFamily: "Fira Sans Extra Condensed",
        fontColor: "#CACCB2",
        fontSize: "32px",
      },
    },
    MuiButton: {
      variants: [
        {
          // Style only applicable to buttons with the props "variant=solid" and "color=primary"
          props: { variant: "solid", color: "primary" },
          style: {
            backgroundColor: "#181E00",
            color: "#B7D32E",
            fontSize: "18px",
            borderRadius: 3,
            borderStyle: "solid",
            borderWidth: 2,
            borderColor: "#6C7F00",
          },
        },
      ],
      defaultProps: {
        variant: "solid",
      },
    },
    styleOverrides: {
      root: {
        fontSize: "large",
        fontWeight: "Medium",
        borderRadius: 12,
        borderWidth: 3,
        borderStyle: "solid",
        filter: { boxShadow: "2px" },
      },
    },
  },
});

export const QueueThemeProvider = ({ children }) => {
  return (
    <ThemeProvider theme={queue}>
      <CssBaseline />
      {children}
    </ThemeProvider>
  );
};
export const queueTheme = { queue };
export const serviceTheme = { servicePath };
export const userTheme = { userDashboard };
