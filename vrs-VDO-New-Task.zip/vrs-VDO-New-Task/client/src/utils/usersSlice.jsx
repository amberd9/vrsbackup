import { createSlice } from "@reduxjs/toolkit";

export const usersSlice = createSlice({
  name: "user",
  initialState: {
    username: "",
    selectedVehicle: {},
    selectedRequest: {},
    isAdmin: false,
  },
  reducers: {
    updateSelectedVehicle: (state, { payload }) => {
      state.selectedVehicle = payload;
    },
    updateAllState: (state, { payload }) => {
      state = { ...state, ...payload };
    },
    updateSelectedRequest: (state, { payload }) => {
      state.selectedRequest = payload;
    },
  },
});

// Action creators are generated for each case reducer function
export const { updateSelectedVehicle, updateAllState, updateSelectedRequest } =
  usersSlice.actions;

export default usersSlice.reducer;
