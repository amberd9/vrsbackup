// import { createSlice } from "@reduxjs/toolkit";

// export const keycloakSlice = createSlice({
//   name: "keycloak",
//   initialState: {
//     initialized: false,
//   },
//   reducers: {
//     updateKeycloakSlice: (state, { payload }) => {
//       state.initialized = payload.initialized;
//     },
//   },
// });

// // Action creators are generated for each case reducer function
// export const { updateKeycloakSlice } = keycloakSlice.actions;

// export default keycloakSlice.reducer;
