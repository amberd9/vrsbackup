import { configureStore } from "@reduxjs/toolkit";
import UsersSliceReducer from "./usersSlice";

export default configureStore({
  reducer: {
    user: UsersSliceReducer,
  },
});
