// import { ModalManager } from "@mui/material";
// import AddVehicleModal from "../components/Dashboard/Vehicles/AddVehicleModal";
// TODO: EASIER MANAGEMENT OF A WORLD FULL OF MODALS THAT HAVE REPEATED ELEMENTS?
// const ModalManager = ({ closePage = () => null, modalOpen = "" }) => {
//   const [modalOpen, setModalOpen] = useState(false);
//   const closeModal = () => {
//     // setModalOpen(false);
//     setModalOpen("");
//   };
//   return (
//     <>
//       <AddVehicleModal
//         closePage={closeModal}
//         open={modalOpen === "AddVehicleModal"}
//       />

//     </>
//   );
// };

// {
//   /* <ModalOne
//   closeFn={closeFn}
//   open={modal === 'modal-one'} />

// <ModalTwo
//   closeFn={closeFn}
//   open={modal === 'modal-two'} />

// <ModalThree
//   closeFn={closeFn}
//   open={modal === 'modal-three'} />
// </>
// ) */
// }

// export default ModalManager;
