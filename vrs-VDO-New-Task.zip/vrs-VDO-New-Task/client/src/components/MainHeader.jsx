import { Button, IconButton, Stack, TextField, Tooltip } from "@mui/material";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";

import { useNavigate } from "react-router-dom";
import { FacebookRounded, QrCode2Rounded } from "@mui/icons-material";
import { eightsix, logout, vrslogo } from "../imgs";

export default function MainHeader() {
  const navigate = useNavigate();
  return (
    <AppBar position="sticky">
      <Toolbar className="mainHeaderBar" pb={2} sx={{ flexGrow: 1 }}>
        <Stack flex={1} direction="row" alignItems="center" spacing={10}>
          <Box>
            <Box component="img" src={vrslogo} height={60} mr={2} />
            <img src={eightsix} height={58} />
          </Box>
          <TextField placeholder="Search" size="small" />
        </Stack>
        <Typography
          fontSize="46px"
          noWrap
          // color="text.secondary"
          fontWeight="medium"
          fontFamily="Fira Sans Extra Condensed"
          letterSpacing={3.0}
          lineHeight={1.7}
          sx={{
            display: {
              xs: "none",
              sm: "block",
              filter: "drop-shadow(2px 3px 0px #db5304)",
            },
          }}
        >
          VEHICLE REGISTRATION
        </Typography>
        <Box flex={1} align="right">
          <Tooltip title="Visit us on FB: url.com">
            <FacebookRounded
              color="secondary"
              sx={{ fontSize: "30px", mr: 2, mt: 2 }}
            />
          </Tooltip>
          <QrCode2Rounded
            color="secondary"
            sx={{ fontSize: "30px", mr: 2, mt: 2 }}
          />
          <Tooltip title="Sign-Out">
            <img
              src={logout}
              height={40}
              sx={{ fontSize: "42px" }}
              onClick={() => navigate("/")}
            />
          </Tooltip>
        </Box>
      </Toolbar>
    </AppBar>
  );
}
