import {
  Box,
  Divider,
  Paper,
  Stack,
  AppBar,
  Toolbar,
  Typography,
  Button,
  Modal,
  IconButton,
  Tooltip,
  Dialog,
  Collapse,
  Chip,
} from "@mui/material";
import {
  draganddrop as dragAndDrop,
  scanfile,
  uploadfile as uploadFile,
  cancel,
  green_car,
  uploadMSFred,
} from "../../imgs";
import { FileUploader } from "react-drag-drop-files";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, Close } from "@mui/icons-material";
import { typ_roboto_header } from "./WalkthruCSS";

const UploadTemplate = ({ open = true, handleClose }) => {
  const navigate = useNavigate();
  const FileTypes = ["jpeg", "jpg", "png", "pdf", "webp"];
  const [files, setFiles] = useState([]);
  const [image, setImage] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleChange = (files) => {
    setFiles(Object.values(files));
  };

  const handleView = (index) => {
    const reader = new FileReader();
    reader.readAsDataURL(files[index]);
    reader.onload = () => {
      setImage(reader.result);
    };
  };

  useEffect(() => {
    if (files[0]) {
      handleView(0);
      setCurrentIndex(0);
    }
  }, [files]);

  const handleNext = () => {
    let nextIndex = currentIndex + 1;
    if (files.length > 0 && nextIndex <= files.length - 1) {
      setCurrentIndex(nextIndex);
    } else {
      setCurrentIndex(0);
      nextIndex = 0;
    }
    handleView(nextIndex);
  };

  const handlePrev = () => {
    let prevIndex = currentIndex - 1;
    if (prevIndex >= 0) {
      setCurrentIndex(prevIndex);
    } else {
      setCurrentIndex(files.length - 1);
      prevIndex = files.length - 1;
    }
    handleView(prevIndex);
  };
  // TODO FILENAMES AS CHIPS THAT YOU CAN INDIVIDUALLY REMOVE
  return (
    <>
      <Stack>
        {/* <UploadTemplate
        // backdrop="#000"
        open={uploadOpen}
        handleClose={() => setUploadOpen(false)}
        modalbackdrop
      />  */}
        <Modal open={open} onClose={handleClose}>
          {/* <Box>
          <Typography sx={typ_roboto_header}>
            PLEASE UPLOAD YOUR DOCUMENT HERE
          </Typography>
        </Box> */}
          <Box
            className="upload"
            position="relative"
            sx={{
              "::-webkit-scrollbar": { width: 0, height: 0 },
              mt: "10%",
              mx: "auto",
              backgroundColor: "#4B004325",
              border: "1px solid #d892c8",

              borderRadius: "12px",
              width: { md: 800, sm: "90vw", xs: "90vw" },
            }}
          >
            <Stack
              sx={{
                p: 2,
                px: 4,
                border: "8px solid #904082",
                borderRadius: "12px",
                backgroundColor: "#4B004325",
              }}
            >
              <Box height="40px" />
              {/* <Box height="70px" justifyContent="right"></Box> */}
              <Stack>
                <Stack
                  component={Paper}
                  sx={{
                    backgroundColor: "rgba(41, 1, 53, 60%)",
                    // #482d74",
                    //
                    fontFamily: "Fira Sans Extra Condensed",
                    border: "1px #9877af solid",
                    borderRadius: 1,
                    p: 2,
                    // width: "85%",
                  }}
                >
                  <Box sx={{ align: "left" }} className="transimg">
                    <img
                      src={uploadMSFred}
                      align="left"
                      alt="MSF Logo"
                      height="60px"
                    />
                  </Box>
                  <Box height="50px" />
                  <Stack alignItems="center">
                    <Stack direction="row" alignItems="center">
                      <FileUploader
                        handleChange={handleChange}
                        name="file"
                        types={FileTypes}
                        multiple={true}
                        label="Upload with Click or Drag and Drop a File Here"
                        hoverTitle="Drop File Here to Upload"
                        children={
                          <>
                            <Stack direction="row" alignItems="center">
                              <Box width="250px" align="right" mx="20px">
                                <>
                                  <Typography
                                    fontSize="20px"
                                    fontFamily="Roboto Condensed"
                                  >
                                    Browse/Choose File to Upload
                                  </Typography>
                                  <Typography
                                    fontSize="20px"
                                    fontFamily="Roboto Condensed"
                                  >
                                    OR
                                  </Typography>
                                  <Typography
                                    fontSize="20px"
                                    fontFamily="Roboto Condensed"
                                  >
                                    Drag and Drop File to Upload
                                  </Typography>
                                </>
                              </Box>
                              {/* <Button variant="text" > */}
                              <Stack
                                direction="row-reverse"
                                alignItems="center"
                                justifyContent="flex-end"
                              >
                                <Box
                                  component="img"
                                  src={dragAndDrop}
                                  alt="Drag and Drop"
                                  height="80px"
                                />
                                <img
                                  src={uploadFile}
                                  alt="Upload File"
                                  height="80px"
                                />
                              </Stack>
                              {/* </Button> */}
                              <Stack direction="row" justifyContent="right">
                                <Tooltip
                                  title={
                                    <Typography>
                                      Scanning documents is mobile only.
                                    </Typography>
                                  }
                                >
                                  <img
                                    src={scanfile}
                                    alt="Scan File"
                                    height="90px"
                                  />
                                </Tooltip>
                              </Stack>
                            </Stack>
                          </>
                        }
                      />
                    </Stack>
                    <Box height="50px" />
                  </Stack>
                </Stack>

                {/* <CheckBoxOutlined functionality added as auto animation upon upload?> */}
                <Collapse in={Boolean(files.length > 0)}>
                  <Stack
                    component={Paper}
                    sx={{
                      backgroundColor: "#56234340",
                      fontFamily: "Fira Sans Extra Condensed",
                      border: "1px #9877af solid",
                      borderRadius: 1,
                      m: "15px 0px 25px 5px",
                      p: 2,
                      // width: "600px",
                    }}
                  >
                    <Box sx={{ maxHeight: 100, overflowY: "auto" }}>
                      {files.length > 0
                        ? files.map(({ name }, i) => (
                            <Typography
                              key={"file-" + i}
                              fontFamily="Roboto Condensed"
                              color="#F3DDF1"
                              align="right"
                            >
                              {`UPLOADED FILE: ${name}`}
                              <br />
                            </Typography>
                          ))
                        : `Please upload before continuing.`}
                    </Box>
                    <Stack direction="row">
                      <Button
                        size="small"
                        variant="outlined"
                        onClick={() => {
                          setFiles([]);
                          setImage(null);
                        }}
                      >
                        CANCEL
                      </Button>
                    </Stack>
                    <Stack direction="row" justifyContent="space-between">
                      <Button onClick={handlePrev}>
                        <ChevronLeft />
                      </Button>
                      {image && (
                        <Box
                          component="img"
                          alt="uploaded image"
                          src={image}
                          height={250}
                          sx={{ maxWidth: 600 }}
                        />
                      )}
                      <Button onClick={handleNext}>
                        <ChevronRight />
                      </Button>
                    </Stack>
                  </Stack>
                </Collapse>
              </Stack>
            </Stack>
          </Box>
        </Modal>{" "}
      </Stack>
    </>
  );
};

export default UploadTemplate;
