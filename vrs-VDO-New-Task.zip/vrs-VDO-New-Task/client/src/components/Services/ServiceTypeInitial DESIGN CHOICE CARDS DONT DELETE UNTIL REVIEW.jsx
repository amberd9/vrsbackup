import Box from "@mui/material/Box";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Button,
  Card,
  CardActionArea,
  Stack,
  Typography,
  CardMedia,
  CardContent,
} from "@mui/material";
import {
  boughtcarpic,
  deregistration,
  groupPOA,
  initialregportal,
  newarrivals,
  newjobwpeople,
  updateregistrationportal,
} from "../../imgs";
import {
  snackbar_pink,
  stack_svc_box_pink,
  svc_bg_box_pink_medium,
  svc_btn_pink,
  svc_xlbg_pink,
  typ_roboto_lightitalic,
  typ_roboto_normal,
} from "./WalkthruCSS";

const ServiceTypeInitial = () => {
  const navigate = useNavigate();

  return (
    <>
      <Stack
        py={3}
        // alignItems="center"
        flex={1}
        justifyContent="space-around"
        sx={{
          ...stack_svc_box_pink,
          width: "1860px",
          position: "absolute",
          left: "14%",
          top: "10%",
        }}
      >
        <Typography
          align="center"
          fontSize={38}
          fontFamily="FIRA SANS EXTRA CONDENSED"
          mr="2%"
          sx={{ color: "#F3DDF1", filter: "drop-shadow(1px 0px 1px #f2aeeb)" }}
        >
          WHICH EVENT BEST DESCRIBES YOUR CURRENT SITUATION?
        </Typography>
        <Box height={50} />
        <Stack
          direction="row"
          align="center"
          justifyContent="space-evenly"
          alignItems="center"
          flexWrap="wrap"
        >
          <CardActionArea
            justifyContent="center"
            sx={{
              ...snackbar_pink,
              height: 500,
              maxWidth: 500,
              alignItems: "center",
              background: "#220623",
              border: "ridge 9px #904082",
              // outline: "1px dotted #ffb43f",
              outlineOffset: "10px",
              py: 1,
            }}
            onClick={() => navigate("/Service/Initial/Arrival")}
          >
            <CardMedia
              component="img"
              title="new_arrivals"
              src={newarrivals}
              height="300px"
            />

            <Typography sx={{ ...typ_roboto_normal, justifySelf: "center" }}>
              I am a new arrival and shipped <br />
              or drove my vehicle.
            </Typography>
          </CardActionArea>

          <Box
            alignItems="center"
            sx={{
              ...snackbar_pink,
              height: 300,
              maxWidth: 500,
              alignItems: "center",
              background: "#220623",
              border: "ridge 9px #904082",
              // outline: "1px dotted #ffb43f",
              outlineOffset: "10px",

              // fontFamily: "Roboto Condensed",
            }}
          >
            <img src={newjobwpeople} height={120} alt="logistical_support" />
            <Typography sx={{ ...typ_roboto_normal, fontSize: "30px" }}>
              I gained logistical support; <br />I am changing duty status and
              retaining logistical support.
            </Typography>
          </Box>
        </Stack>
        <Box height="70px" />
        <Stack
          direction="row"
          align="center"
          justifyContent="space-evenly"
          alignItems="center"
          flexWrap="wrap"
        >
          <Box
            sx={{
              ...snackbar_pink,
              height: 300,
              maxWidth: 500,
              alignItems: "center",
              background: "#220623",
              border: "ridge 9px #904082",
              // outline: "1px dotted #ffb43f",
              outlineOffset: "10px",
              py: 4,
            }}
          >
            <img src={boughtcarpic} height={130} alt="new_car" />
            <Typography sx={typ_roboto_normal}>
              I bought a new vehicle.
            </Typography>
          </Box>
          <Box
            sx={{
              ...snackbar_pink,
              height: 300,
              maxWidth: 500,
              alignItems: "center",
              background: "#22062390",
              border: "ridge 9px #904082",
              // outline: "1px dotted #ffb43f",
              outlineOffset: "10px",
              py: 2,
            }}
          >
            <img src={groupPOA} height={130} alt="groupPOA" />
            <Typography sx={typ_roboto_normal}>
              I need an Agent Owner or Power of Attorney
            </Typography>
          </Box>
        </Stack>
      </Stack>
      {/* //keep for now please */}
      {/* <Button
        sx={{
          ...svc_btn_pink,
          position: "relative",
          left: "80%",
          // top: "40%",
          bottom: "2%",
        }}
        onClick={() => navigate("/Service/Update")}
      >
        HELP
      </Button> */}
      <Typography
        sx={{
          ...typ_roboto_lightitalic,
          align: "center",
          pb: 10,
          ml: 10,
          color: "#B7D32E",
        }}
      >
        RESOURCES
      </Typography>
    </>
  );
};

export default ServiceTypeInitial;
