import { Box, Button, Stack, Typography, Divider } from "@mui/material";
import { useState } from "react";
import { greenmotorcycle, redSUV } from "../../imgs/RequestPageImages";
import { useNavigate } from "react-router-dom";

// TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE
// TODO: NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY
// TODO: USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES

const MSFaskifneeded = () => {
  const navigate = useNavigate();
  const [singleVehicleFinalizedOpen, setSingleVehicleFinalizedOpen] =
    useState(true);
  return (
    <>
      <Box display="flex" height="800px">
        <Stack spacing={3} padding={3}>
          <Typography
            align="center"
            sx={{
              fontSize: "36px",
              color: "#EBFFE7",
              fontFamily: "Fira Sans Extra Condensed",
            }}
          >
            ARE YOU NEEDING HELP WITH SERVICES FOR A VEHICLE OR A MOTORCYCLE?
          </Typography>
          <Stack direction="row">
            <Box width="35%" />
            <Divider flexItem sx={{ width: "350px", color: "#adc91e" }} />
            <Box width="35%" />
          </Stack>
          <Box width="4px" />
          <Box
            align="center"
            sx={{
              width: "1000px",
              border: "2px solid #6D85D6",
              backgroundColor: "#01081750",
              borderRadius: 4,
            }}
          >
            <Stack direction="row" justifyContent="space-evenly">
              <Box height="200px" py={12} alignContent="top">
                <img src={redSUV} alt="redSUV" height={200} />
              </Box>
              <Box height="200px" pt={22} alignContent="center">
                <img
                  src={greenmotorcycle}
                  alt="GreenMotorcycle"
                  height={270}
                  align="center"
                />
              </Box>
            </Stack>
            <Box py={15} display="flex" justifyContent="space-around">
              <Button
                pt={50}
                variant="contained"
                color="secondary"
                sx={{
                  //TODO: ml not flex - flex needed
                  ml: 8,
                  backgroundColor: "#181E00",
                  color: "#B7D32E",
                  fontSize: "24px",
                  borderRadius: 3,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#6C7F00",
                  minWidth: "100px",
                  maxHeight: "50px",
                }}
                onClick={() => navigate("/MultipleServicesStart")}
                //TODO: linking in a new modal here: onClick={() => setSingleVehicleFinalizedOpen(true)}
              >
                VEHICLE
              </Button>
              <Button
                variant="contained"
                color="secondary"
                sx={{
                  backgroundColor: "#181E00",
                  color: "#B7D32E",
                  fontSize: "24px",
                  borderRadius: 3,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#6C7F00",
                  minWidth: "200px",
                  maxHeight: "50px",
                }}
                onClick={() => navigate("/NewRequests/MSF1")}
              >
                MOTORCYCLE
              </Button>
            </Box>
          </Box>
          <Box align="center" py={2}>
            <Typography
              sx={{
                color: "#D1CDFE",
                fontStyle: "italic",
                fontWeight: "light",
              }}
            >
              MSF RESOURCES <br /> <br /> Recreational Vehicles in Deutschland
              <br />
              <br />
            </Typography>
          </Box>
        </Stack>
      </Box>
    </>
  );
};
export default MSFaskifneeded;
