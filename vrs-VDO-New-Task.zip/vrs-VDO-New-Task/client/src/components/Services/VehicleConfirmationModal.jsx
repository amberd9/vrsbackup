import {
  Box,
  Divider,
  Paper,
  Stack,
  AppBar,
  Toolbar,
  Typography,
  Button,
  Modal,
  IconButton,
  Tooltip,
  ListItem,
  List,
} from "@mui/material";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { uploadcancel } from "../../imgs";
import { EditAttributesOutlined, EditOutlined } from "@mui/icons-material";
import VehiclesFinalizedModal from "./VehiclesFinalizedModal";
import AddVehicleModal from "../Dashboard/Vehicles/AddVehicleModal";
import EditVehicleModal from "../Dashboard/Vehicles/EditVehicleModal";

const VehicleConfirmationModal = ({ open, handleClose }) => {
  const navigate = useNavigate();
  const [VehiclesFinalizedOpen, setVehiclesFinalizedOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  // TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE
  // TODO: NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY
  // TODO: USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES

  return (
    <>
      <VehiclesFinalizedModal
        open={VehiclesFinalizedOpen}
        handleClose={() => setVehiclesFinalizedOpen(false)}
      />
      <AddVehicleModal open={addOpen} handleClose={() => setAddOpen(false)} />
      <Modal
        open={open}
        onClose={handleClose}
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          maxHeight: "90vw",
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <Box
          className="upload"
          sx={{
            width: 1000,
            mx: "auto",
            mt: "20vh",
            backgroundColor: "#1A1429",
            borderRadius: "0px 0px 12px 12px",
          }}
        >
          <Stack
            sx={{
              p: 2,
              border: "2px solid #c8c9b5",
              borderRadius: "12px 12px 12px 12px",
            }}
          >
            <Stack direction="row-reverse" alignItems="flex-start">
              <IconButton onClick={handleClose}>
                <img src={uploadcancel} alt="cancel" height="40px" />
              </IconButton>
              <Stack justifyContent="center">
                <Typography
                  fontSize="30px"
                  fontFamily="Fira Sans Extra Condensed"
                  color="#d35d9c"
                  align="center"
                >
                  <br /> PLEASE CONFIRM YOUR SELECTIONS ARE CORRECT <br />
                </Typography>
                <Typography
                  fontSize="30px"
                  fontFamily="Fira Sans Extra Condensed"
                  color="#e9ead3"
                  align="center"
                  px={5}
                >
                  <br /> You selected help with services for the following
                  vehicles: <br />
                  <br />
                  {"\u25CF\u0020"}
                  REC POV 1<br />
                  {"\u25CF\u0020"} Motorcycle
                </Typography>
                <Typography
                  fontSize="16px"
                  fontFamily="Fira Sans Extra Condensed"
                  color="#f7b9db"
                  align="center"
                  px={5}
                >
                  <br />
                  <br />
                  PRO TIP! <br /> Adding vehicles to your profile can make this
                  process easier in the future. <br /> If you would like to add
                  these [POVs] to your profile without navigating away from your
                  current request, select "Add to Profile" before continuing.
                  <br /> <br />
                </Typography>
              </Stack>
            </Stack>
            <Stack direction="row" justifyContent="space-around">
              <Button
                onClick={() => setAddOpen(true)}
                sx={{
                  fontFamily: "Roboto Condensed",
                  variant: "contained",
                  backgroundColor: "#2b1628",
                  color: "#eface7",
                  fontSize: "16px",
                  borderRadius: 3,
                  px: 2,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#c431b3",
                }}
              >
                ADD TO PROFILE
              </Button>
              <Button
                onClick={handleClose}
                sx={{
                  fontFamily: "Roboto Condensed",
                  variant: "contained",
                  backgroundColor: "#2b1628",
                  color: "#eface7",
                  fontSize: "14px",
                  borderRadius: 3,
                  px: 2,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#c431b3",
                }}
              >
                <EditOutlined /> MAKE CORRECTIONS
              </Button>
              <Button
                sx={{
                  fontFamily: "Roboto Condensed",
                  variant: "contained",
                  backgroundColor: "#630858",
                  color: "#f9a9f0",
                  fontSize: "18px",
                  borderRadius: 3,
                  px: 2,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#ef15e4",
                }}
                onClick={() => setVehiclesFinalizedOpen(true)}
              >
                CONTINUE
              </Button>
            </Stack>
          </Stack>
        </Box>
      </Modal>
    </>
  );
};

export default VehicleConfirmationModal;
