import {
  Box,
  Stack,
  Typography,
  Button,
  Modal,
  IconButton,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { uploadcancel } from "../../imgs";

// TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE
// TODO: NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY
// TODO: USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES

const VehicleCountAlert = ({ open, handleClose }) => {
  const navigate = useNavigate();
  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          maxHeight: "90vw",
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <Box
          className="upload"
          sx={{
            width: 1000,
            mx: "auto",
            mt: "20vh",
            backgroundColor: "#1A1429",
            borderRadius: "0px 0px 12px 12px",
          }}
        >
          <Stack
            sx={{
              p: 2,
              border: "2px solid #B7D32E",
              borderRadius: "12px 12px 12px 12px",
            }}
          >
            <Stack direction="row-reverse" alignItems="flex-start">
              <IconButton onClick={handleClose}>
                <img src={uploadcancel} alt="cancel" height="40px" />
              </IconButton>
              <Typography
                fontSize="24px"
                fontFamily="Fira Sans Extra Condensed"
                color="#e9ead3"
                align="justify"
                px={5}
              >
                <br />
                {/* TODO - CHANGE EMPHASIS COLOR OF INDIVIDUAL WORDS WITHIN TYPOGRAPHY? */}
                Please do NOT double-count vehicles! <br /> <br />
                Vehicles added from your profile list are counted separately
                from vehicles added with the counter tool.
                <br />
                {/* Selections made from the profile list should NOT be included on
                the vehicle counter.*/}
                <br />
                Please use the counter tool to indicate vehicles NOT already
                available for selection in your profile list.
                <br /> <br />
                {/* You can also choose to add vehicles to your profile for easier
                access in the future if you would like.
                <br /> */}
              </Typography>
            </Stack>
            <Box align="right" mr="1%">
              <Button
                onClick={handleClose}
                sx={{
                  variant: "contained",
                  backgroundColor: "#390033",
                  color: "#CBBEFF",
                  fontSize: "20px",
                  borderRadius: 3,
                  px: 2,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#ef15e4",
                }}
              >
                CONTINUE
              </Button>
            </Box>
          </Stack>
        </Box>
      </Modal>
    </>
  );
};

export default VehicleCountAlert;
