import Box from "@mui/material/Box";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Stack, Typography } from "@mui/material";
import {
  deregistration,
  groupPOA,
  initialregportal,
  updateregistrationportal,
} from "../../imgs";
import {
  btn_maps_hrs,
  stack_svc_box_pink,
  svc_bg_box_pink_medium,
  svc_btn_pink,
  svc_xlbg_pink,
  typ_roboto_lightitalic,
  typ_roboto_normal,
} from "./WalkthruCSS";

const ServiceType = () => {
  const navigate = useNavigate();

  return (
    <>
      <Stack
        py={3}
        display="flex"
        flex={1}
        justifyContent="space-around"
        alignItems="space-around"
        sx={{
          ...stack_svc_box_pink,
          width: "1860px",
          position: "absolute",
          left: "14%",
          top: "10%",
        }}
      >
        <Typography
          align="center"
          fontSize={38}
          fontFamily="FIRA SANS EXTRA CONDENSED"
          mr="2%"
          sx={{ color: "#F3DDF1", filter: "drop-shadow(1px 0px 1px #f2aeeb)" }}
        >
          WHICH EVENT BEST DESCRIBES YOUR CURRENT SITUATION?
        </Typography>
        <Box height={25} />
        <Stack
          direction="row"
          align="center"
          justifyContent="space-around"
          alignItems="center"
        >
          <Box
            sx={{
              ...svc_bg_box_pink_medium,
              height: 400,
              maxWidth: 450,
              alignItems: "center",

              background: "#281329",
              border: " 4px inset  #80607d",
              boxShadow:
                // "rgb(200, 208, 231) 3.2px 3.2px 8px 0px inset, rgb(255, 255, 255) -3.2px -3.2px 8px 0px inset",
                " rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset",
              py: 3,
              ":hover": {
                color: "#D5F632",
                background: " #66688620",
                Image: " #66688620",
              },
            }}
            onClick={() => navigate("/Service/Initial")}
          >
            <img src={initialregportal} alt="initial_portal" height="150px" />
            <Typography sx={typ_roboto_normal}>
              I need to complete an initial/new vehicle registration.
            </Typography>
          </Box>
          <Box
            sx={{
              ...svc_bg_box_pink_medium,
              background: "#281329",
              border: " 4px inset  #80607d",
              boxShadow:
                // "rgb(200, 208, 231) 3.2px 3.2px 8px 0px inset, rgb(255, 255, 255) -3.2px -3.2px 8px 0px inset",
                " rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset",
              height: 400,
              maxWidth: 450,
              p: 1,
              ":hover": {
                color: "#D5F632",
                background: " #66688620",
                Image: " #66688620",
              },
            }}
            onClick={() => navigate("/Service/Update")}
          >
            <img
              src={updateregistrationportal}
              alt="updatereg_portal"
              height="150px"
            />
            <Typography sx={{ ...typ_roboto_normal }}>
              I need to renew or update my vehicle registration; <br />
              Get help with plates, tags or related services.
            </Typography>
          </Box>

          <Box
            alignItems="center"
            sx={{
              ...svc_bg_box_pink_medium,
              height: 400,
              maxWidth: 450,
              p: 6,
              background: "#281329",
              border: " 4px inset  #80607d",
              boxShadow:
                " rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset",
              ":hover": {
                color: "#D5F632",
                background: " #66688620",
                Image: " #66688620",
              },
            }}
            onClick={() => navigate("/Service/Deregister")}
          >
            <img src={deregistration} alt="dereg_portal" height="150px" />
            <Typography sx={typ_roboto_normal}>
              I need to deregister my vehicle.
            </Typography>
          </Box>
        </Stack>
        <Box height="100px" />
        <Box align="right" mx="5%">
          <Button
            sx={{
              ...btn_maps_hrs,
              outlineOffset: 4,
              outline: "2px ridge #b7d32e",
              color: "#ffb43f",
              minHeight: "100px",
              fontSize: "20px",
              px: 1,
            }}
          >
            <Box>
              <img src={groupPOA} height={80} alt="groupPOA" />
            </Box>
            I need an Agent Owner; <br /> Power of Attorney
          </Button>
        </Box>
      </Stack>
      {/* <Button
        sx={{
          ...svc_btn_pink,
          position: "relative",
          left: "75%",
          top: "20%",
          // bottom: "22%",
        }}
        onClick={() => navigate("/UserDashboard/Resources")}
      >
        HELP
      </Button> */}

      <Typography
        sx={{
          ...typ_roboto_lightitalic,
          align: "center",
          pb: 10,
          ml: 10,
          color: "#B7D32E",
        }}
      >
        RESOURCES
      </Typography>
    </>
  );
};

export default ServiceType;
