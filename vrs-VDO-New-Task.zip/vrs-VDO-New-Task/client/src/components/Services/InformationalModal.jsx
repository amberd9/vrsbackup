import Box from "@mui/material/Box";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Modal, Stack, Typography } from "@mui/material";
import { astrocomputerrobofix, astroservices } from "../../imgs";
import {
  btn_maps_hrs,
  svc_btn_pink,
  svc_xlbg_pink,
  typ_roboto_lightitalic,
  typ_roboto_lightsmall,
  typ_roboto_sub,
} from "./WalkthruCSS";

const InformationalModal = ({ modalOpen = true, handleModal }) => {
  const [isvisible, setisVisible] = useState(false);
  const [timer, setTimer] = useState(null);
  const navigate = useNavigate();
  const handleClick = (event) => {
    setisVisible(true);
    setTimer(
      setTimeout(() => {
        setisVisible(false);
        navigate("/Service");
      }, 1700)
    );
  };

  const handleClose = () => {
    setisVisible(false);
    navigate("/Service");
    timer && clearTimeout(timer);
  };

  return (
    <>
      <Modal backdrop="static" open={modalOpen} onClose={handleModal}>
        <Stack
          py={3}
          alignItems="center"
          justifyContent="space-evenly"
          sx={{
            background: "#4B004320",
            border: "solid 4px #3E3A5154",
            borderRadius: 4,
            width: "1600px",
            position: "absolute",
            left: "16%",
            top: "15%",
          }}
        >
          <Stack alignItems="center" justifyContent="space-evenly">
            <Typography
              fontSize={40}
              fontFamily="FIRA SANS EXTRA CONDENSED"
              py={1}
              sx={{ color: "#B7D32E", filter: "drop-shadow(1px 1px 1px #aff)" }}
            >
              NOW YOU WILL SELECT THE SERVICE YOU NEED FOR YOUR [FIRST VEHICLE]
            </Typography>

            <Stack direction="row" justifyContent="space-between">
              <Box
                component="img"
                src={astrocomputerrobofix}
                alt="astrocomputer"
                height="350px"
              />
              <Stack align="center" justifyContent="space-evenly">
                <Stack
                  direction="row"
                  align="center"
                  justifyContent="space-evenly"
                  alignItems="center"
                >
                  <Typography sx={typ_roboto_lightitalic}>
                    PLEASE SELECT
                  </Typography>
                  <Typography sx={{ fontStyle: "Bold", fontSize: "25px" }}>
                    "MULTIPLE SERVICES"
                  </Typography>
                  <Typography sx={typ_roboto_lightitalic}>
                    IF YOU NEED ASSISTANCE WITH
                  </Typography>{" "}
                </Stack>
                <Stack
                  direction="row"
                  align="center"
                  justifyContent="space-evenly"
                  alignItems="center"
                >
                  <Typography sx={{ fontStyle: "Bold", fontSize: "25px" }}>
                    MORE THAN ONE
                  </Typography>
                  <Typography sx={typ_roboto_lightitalic}>
                    SERVICE FOR
                  </Typography>

                  <Typography sx={{ fontStyle: "Bold", fontSize: "25px" }}>
                    EACH
                  </Typography>
                  <Typography sx={typ_roboto_lightitalic}>
                    OF, OR ANY
                  </Typography>
                  <Typography sx={{ fontStyle: "Bold", fontSize: "25px" }}>
                    ONE SINGLE
                  </Typography>
                  <Typography sx={typ_roboto_lightitalic}>VEHICLE</Typography>
                </Stack>
                <Stack
                  direction="row"
                  align="center"
                  justifyContent="space-evenly"
                  alignItems="center"
                ></Stack>
                <Typography sx={typ_roboto_lightsmall}>
                  PLEASE COMPLETE EACH SERVICE ONE AT A TIME. <br /> ONCE
                  COMPLETED YOU WILL THEN BE ALLOWED TO SELECT THE NEXT ONE TO
                  START.
                </Typography>
                <Typography sx={typ_roboto_lightsmall}>
                  YOU WILL HAVE THE OPPORTUNITY TO REVIEW ALL SUBMITTED
                  DOCUMENTS <br /> FOR ALL SERVICES ON EACH VEHICLE AT THE END.
                </Typography>
                <Box height={30} />
              </Stack>
            </Stack>

            <Box justifyContent="space-between" align="center">
              <Stack
                alignItems="center"
                justifyContent="center"
                direction="row"
              >
                <Typography
                  sx={{
                    align: "center",
                    fontSize: 30,
                    fontFamily: "Roboto Condensed",

                    py: 1,
                    color: "#4917ed",
                    filter: "drop-shadow(1px 1px .5px #fff)",
                    WebkitTextStroke: "0.5px #c04a76 ",
                  }}
                >
                  I NEED TO COMPLETE MULTIPLE SERVICES FOR AT LEAST ONE VEHICLE
                </Typography>
                <Box width={50} />
                <Button
                  type="submit"
                  sx={{ ...btn_maps_hrs, minHeight: "120px", py: 2 }}
                  onClick={handleClick}
                >
                  <Box
                    component="img"
                    src={astroservices}
                    height={100}
                    alt="test"
                    sx={{ px: 0.5 }}
                  />
                  MULTIPLE SERVICES NEEDED
                </Button>
              </Stack>
            </Box>
            <Box height={50} />
          </Stack>

          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-evenly"
          >
            <Stack align="center" justifyContent="center">
              <Typography sx={{ ...typ_roboto_sub }}>
                I ONLY NEED TO COMPLETE ONE SERVICE TODAY
              </Typography>
              <Typography sx={{ ...typ_roboto_lightitalic }}>
                NOTE: You may change this option at a later point in time if
                needed.
              </Typography>
            </Stack>
            <Box width={50} />
            <Button sx={svc_btn_pink} onClick={handleClick}>
              CONTINUE
            </Button>
            <Modal
              position="relative"
              top="10%"
              left="20%"
              align="center"
              open={isvisible}
              onClose={handleClose}
              alignItems="center"
              sx={{
                ...svc_xlbg_pink,
                height: 300,
                width: 900,
                borderColor: "#f2aeeb",
                position: "absolute",
                left: "32%",
                top: "25%",
                background: "#865f80",
              }}
            >
              <Typography
                fontSize={42}
                fontFamily="FIRA SANS EXTRA CONDENSED"
                py={3.5}
                sx={{
                  color: "#ffb43f",
                  height: 250,
                  filter: "drop-shadow(2px 2px 1px #435fdb )",
                }}
              >
                GREAT! <br /> LET'S GET YOU STARTED <br /> WITH YOUR FIRST
                SERVICE FOR YOUR [1ST] VEHICLE!
              </Typography>
            </Modal>
            <Box height={100} />
          </Stack>
        </Stack>
      </Modal>
    </>
  );
};

export default InformationalModal;
