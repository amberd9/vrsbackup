import Box from "@mui/material/Box";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Stack, Typography } from "@mui/material";
import {
  boughtcarpic,
  deregistration,
  disposalportal,
  groupPOA,
  initialregportal,
  newarrivals,
  newjobwpeople,
  relocatingportal,
  soldcarportal,
  updateregistrationportal,
} from "../../imgs";
import {
  btn_maps_hrs,
  snackbar_pink,
  stack_svc_box_pink,
  svc_bg_box_pink_medium,
  svc_btn_pink,
  svc_xlbg_pink,
  que_bg_box_medium,
  typ_roboto_lightitalic,
  typ_roboto_normal,
} from "./WalkthruCSS";

const ServiceTypeDereg = () => {
  const navigate = useNavigate();

  return (
    <>
      <Stack
        my="1%"
        py={1}
        // alignItems="center"
        display="flex"
        flex={1}
        justifyContent="space-around"
        alignItems="top"
        sx={{
          ...stack_svc_box_pink,
          width: "1860px",
          position: "absolute",
          left: "14%",
          top: "10%",
        }}
      >
        <Stack direction="row-reverse">
          <Box align="right" py={1} mx="1%">
            <Button
              sx={{
                ...btn_maps_hrs,
                outlineOffset: 4,
                outline: "2px ridge #b7d32e",
                color: "#ffb43f",
                fontSize: "20px",
              }}
              height="auto"
              onClick={() => navigate("/Service/Update")}
            >
              <Box>
                <img src={groupPOA} height={80} alt="groupPOA" />
              </Box>
              I need an Agent Owner; <br /> Power of Attorney
            </Button>
          </Box>{" "}
          <Box width="140px" />
          <Typography
            align="center"
            alignItems="top"
            fontSize={38}
            fontFamily="FIRA SANS EXTRA CONDENSED"
            mr="2%"
            sx={{
              color: "#F3DDF1",
              filter: "drop-shadow(1px 0px 1px #f2aeeb)",
            }}
          >
            WHICH EVENT BEST DESCRIBES YOUR CURRENT SITUATION?
          </Typography>
        </Stack>
        <Box height={80} />
        <Stack
          direction="row"
          align="center"
          justifyContent="space-evenly"
          alignItems="center"
        >
          <Box
            justifyContent="center"
            sx={{
              ...que_bg_box_medium,
              height: 300,
              maxWidth: 400,
              alignItems: "center",
              background: "#11173695 ",
              py: 1,
              ":hover": {
                color: "#3cc1d3",
                background: " #66688620",
                Image: " #66688620",
              },
            }}
            onClick={() => navigate("/Service/Update/Renew")}
          >
            <img src={relocatingportal} height={130} alt="relocating" />
            <Typography
              sx={{
                ...typ_roboto_normal,

                justifySelf: "center",
              }}
            >
              I am relocating.
            </Typography>
          </Box>
          <Box
            alignItems="center"
            sx={{
              ...que_bg_box_medium,
              height: 300,
              maxWidth: 400,
              alignItems: "center",
              background: "#11173695 ",
              py: 1,
              ":hover": {
                color: "#D5F632",
                background: " #66688620",
                Image: " #66688620",
              },
            }}
            onClick={() => navigate("/Service/Update/Renew")}
          >
            <img src={newjobwpeople} height={110} alt="logistical_support" />
            <Typography sx={{ ...typ_roboto_normal, fontSize: "26px" }}>
              I am changing jobs and lost logistical support; <br />I am
              separating, retiring or taking terminal.
            </Typography>
          </Box>
          <Box
            sx={{
              ...que_bg_box_medium,
              height: 300,
              width: 400,
              alignItems: "center",
              background: "#11173695 ",
              py: 1,
              ":hover": {
                color: "#D5F632",
                background: " #66688620",
                Image: " #66688620",
              },
            }}
            onClick={() => navigate("/Service/Update/Renew")}
          >
            <img src={soldcarportal} height={130} alt="sold_car" />
            <Typography sx={typ_roboto_normal}>
              I sold or am selling a vehicle.
            </Typography>
          </Box>
          <Box
            sx={{
              ...que_bg_box_medium,
              height: 300,
              maxWidth: 400,
              alignItems: "center",
              background: "#11173695 ",
              py: 1,
              ":hover": {
                color: "#D5F632",
                background: " #66688620",
                Image: " #66688620",
              },
            }}
            onClick={() => navigate("/Service/Update/Renew")}
          >
            <img src={disposalportal} height={130} alt="disposal" />
            <Typography sx={typ_roboto_normal}>
              I am disposing/junking a vehicle.
            </Typography>
          </Box>
        </Stack>
      </Stack>
      {/* </Stack> */}
      <Typography
        sx={{
          ...typ_roboto_lightitalic,
          align: "center",
          pb: 10,
          ml: 10,
          color: "#B7D32E",
          ":hover": {
            color: "#D5F632",
            background: " #66688620",
            Image: " #66688620",
          },
        }}
        onClick={() => navigate("/Service/Update/Renew")}
      >
        RESOURCES
      </Typography>
    </>
  );
};

export default ServiceTypeDereg;
