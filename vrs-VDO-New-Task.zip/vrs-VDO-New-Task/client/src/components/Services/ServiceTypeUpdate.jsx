import Box from "@mui/material/Box";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Stack, Typography } from "@mui/material";
import {
  astroannouncement,
  astrobluesportscar,
  astrocelltravel,
  astrogas,
  astrohandicapnonop,
  astrojointownermoped,
  astromoonhello,
  astroredmotorcycle,
  astrorocketbackpack,
  boughtcarpic,
  deregistration,
  groupPOA,
  initialregportal,
  newarrivals,
  newjobwpeople,
  pinkastrotraveller,
} from "../../imgs";
import {
  btn_maps_hrs,
  snackbar_pink,
  stack_svc_box_pink,
  svc_bg_box_pink_medium,
  que_bg_box_dark,
  typ_roboto_normal,
  svc_btn_pink,
  svc_xlbg_pink,
  typ_roboto_lightitalic,
  typ_roboto_regular,
  typ_roboto_sub,
} from "./WalkthruCSS";
import Error404 from "../../views/Error404";

const ServiceTypeUpdate = () => {
  const navigate = useNavigate();

  return (
    <>
      <Stack direction="row">
        <img
          src={astrorocketbackpack}
          height={430}
          alt="new_arrivals"
          position="relative"
        />
        <Stack
          py={3}
          flex={1}
          justifyContent="space-around"
          sx={{
            ...stack_svc_box_pink,
            width: "1820px",
            position: "absolute",
            left: "14%",
            top: "10%",
          }}
        >
          <Stack direction="row-reverse">
            <Box align="right" mx="1%">
              <Button
                sx={{
                  ...btn_maps_hrs,
                  outlineOffset: 4,
                  outline: "2px ridge #b7d32e",
                  color: "#ffb43f",
                  fontSize: "20px",
                }}
                onClick={() => navigate("/Service/Update")}
              >
                <Box>
                  <img src={groupPOA} height={80} alt="groupPOA" />
                </Box>
                I need an Agent Owner; <br /> Power of Attorney
              </Button>
            </Box>
            <Box width="170px" />
            <Typography
              align="left"
              fontSize={38}
              fontFamily="FIRA SANS EXTRA CONDENSED"
              sx={{
                color: "#F3DDF1",
                filter: "drop-shadow(1px 0px 1px #f2aeeb)",
              }}
            >
              WHICH EVENT BEST DESCRIBES YOUR CURRENT SITUATION?
            </Typography>
          </Stack>
          <Box height={50} />{" "}
          <Stack
            direction="row"
            align="center"
            justifyContent="space-evenly"
            alignItems="top"
            flexWrap="wrap"
            gap={7}
            // flexShrink={2}
          >
            <Box
              alignItems="center"
              justifyContent="center"
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography
                sx={{
                  ...typ_roboto_normal,
                }}
              >
                I need to RENEW my registration.
              </Typography>{" "}
            </Box>
            <Box
              alignItems="center"
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={{ ...typ_roboto_normal }}>
                I need to register a vehicle as NON-OPERATIONAL.
              </Typography>
            </Box>
            <Box
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={typ_roboto_normal}>
                My vehicle’s registration has EXPIRED.
              </Typography>
            </Box>
            <Box
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={typ_roboto_normal}>
                I need ANOTHER SET of TEMP TAGS
              </Typography>
            </Box>{" "}
            <Box
              alignItems="center"
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={{ ...typ_roboto_normal }}>
                I have temp tags but now I need PERMANENT PLATES
              </Typography>
            </Box>
            <Box
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={{ ...typ_roboto_sub, fontSize: "24px" }}>
                I need to update/change my registration due to a change in my
                work status; <br />I need to update/change my registration due
                to military separation/retirement
              </Typography>
            </Box>
            <Box
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={{ ...typ_roboto_normal, fontSize: "32px" }}>
                I have permanent plates but CAN’T PASS INSPECTION
              </Typography>
            </Box>{" "}
            <Box
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={{ ...typ_roboto_normal, fontSize: "31px" }}>
                I need to CHANGE/UPDATE INFORMATION on my registration
              </Typography>
            </Box>
            <Box
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={typ_roboto_normal}>
                I LOST my registration/sticker
              </Typography>
            </Box>
            <Box
              sx={{
                ...que_bg_box_dark,
                border: "3px solid #22b8cf80",
                outline: "dotted 3px #CBBEFF70",
                outlineOffset: "5px",
                height: 200,
                maxWidth: 400,
                alignItems: "center",
                background: "#11173695 ",
                py: 1,
                ":hover": {
                  color: "#D5F632",
                  background: " #66688620",
                  Image: " #66688620",
                },
              }}
              onClick={() => navigate("/Service/Update/Renew")}
            >
              <Typography sx={typ_roboto_normal}>
                My plates are LOST/STOLEN
              </Typography>
            </Box>{" "}
          </Stack>
          {/* </Stack> */}
        </Stack>
      </Stack>
      <Typography
        sx={{
          ...typ_roboto_lightitalic,
          align: "center",
          pb: 10,
          ml: 10,
          color: "#B7D32E",
        }}
      >
        RESOURCES
      </Typography>
    </>
  );
};

export default ServiceTypeUpdate;
