import {
  Box,
  Divider,
  Paper,
  Stack,
  AppBar,
  Toolbar,
  Typography,
  Button,
  Modal,
  IconButton,
  Tooltip,
  Collapse,
} from "@mui/material";
import {
  draganddrop as dragAndDrop,
  scanfile,
  uploadMSFred,
  cancel,
  uploadfile as uploadFile,
} from "../../imgs";
import { FileUploader } from "react-drag-drop-files";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, Close } from "@mui/icons-material";

const UploadMSF = ({ open, handleClose }) => {
  const navigate = useNavigate();
  const FileTypes = ["jpeg", "jpg", "png", "pdf", "webp"];
  const [files, setFiles] = useState([]);
  const [image, setImage] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const handleChange = (files) => {
    setFiles(Object.values(files));
  };

  const handleView = (index) => {
    const reader = new FileReader();
    reader.readAsDataURL(files[index]);
    reader.onload = () => {
      setImage(reader.result);
    };
  };

  useEffect(() => {
    if (files[0]) {
      handleView(0);
      setCurrentIndex(0);
    }
  }, [files]);

  const handleNext = () => {
    let nextIndex = currentIndex + 1;
    if (files.length > 0 && nextIndex <= files.length - 1) {
      setCurrentIndex(nextIndex);
    } else {
      setCurrentIndex(0);
      nextIndex = 0;
    }
    handleView(nextIndex);
  };

  const handlePrev = () => {
    let prevIndex = currentIndex - 1;
    if (prevIndex >= 0) {
      setCurrentIndex(prevIndex);
    } else {
      setCurrentIndex(files.length - 1);
      prevIndex = files.length - 1;
    }
    handleView(prevIndex);
  };

  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          maxHeight: "90vw",
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <Box
          className="upload"
          sx={{
            width: 1000,
            maxWidth: "90vw",

            mx: "auto",
            mt: 4,
            backgroundColor: "#1A1429",
            borderRadius: "0px 0px 12px 12px",
          }}
        >
          <AppBar position="sticky">
            <Toolbar
              sx={{
                flexGrow: 1,
                justifyContent: "space-between",
                backgroundColor: "#ef15e410",
              }}
            >
              <Typography
                variant="h4"
                color="#fccfef"
                fontFamily="Fira Sans Extra Condensed"
              >
                Motorcycle Safety Foundation Card
              </Typography>
              <IconButton onClick={handleClose}>
                <img src={cancel} alt="cancel" height="40px" />
              </IconButton>
            </Toolbar>
          </AppBar>
          <Divider sx={{ border: "1px solid #ef15e460" }} />
          <Stack
            sx={{
              p: 2,
              border: "2px solid #ef15e460",
              borderTopWidth: 0,
              borderRadius: "0px 0px 12px 12px",
            }}
          >
            <Stack alignItems="flex-end" mr="10%">
              <Typography
                variant="h5"
                fontFamily="Fira Sans Extra Condensed"
                color="#ffe0f6"
                align="right"
                p="2px"
              >
                <br />
                Please upload a valid Motorcycle Safety Foundation Card here.
                <br />
              </Typography>
              <Stack
                component={Paper}
                sx={{
                  backgroundColor: "#56234330",
                  fontFamily: "Fira Sans Extra Condensed",
                  border: "1px #9877af solid",
                  borderRadius: 1,
                  p: 2,
                  width: "85%",
                }}
              >
                <Box sx={{ align: "left" }} className="transimg">
                  <img
                    src={uploadMSFred}
                    align="left"
                    alt="MSF Logo"
                    height="60px"
                  />
                </Box>
                <Box height="50px" />
                <Stack alignItems="center">
                  <Stack direction="row" alignItems="center">
                    <FileUploader
                      handleChange={handleChange}
                      name="file"
                      types={FileTypes}
                      multiple={true}
                      label="Upload with Click or Drag and Drop a File Here"
                      hoverTitle="Drop File Here to Upload"
                      children={
                        <>
                          <Stack direction="row" alignItems="center">
                            <Box width="250px" align="right" mx="20px">
                              <>
                                <Typography
                                  fontSize="20px"
                                  fontFamily="Roboto Condensed"
                                >
                                  Browse/Choose File to Upload
                                </Typography>
                                <Typography
                                  fontSize="20px"
                                  fontFamily="Roboto Condensed"
                                >
                                  OR
                                </Typography>
                                <Typography
                                  fontSize="20px"
                                  fontFamily="Roboto Condensed"
                                >
                                  Drag and Drop File to Upload
                                </Typography>
                              </>
                            </Box>
                            <Stack
                              direction="row-reverse"
                              alignItems="center"
                              justifyContent="flex-end"
                            >
                              <Box
                                component="img"
                                src={dragAndDrop}
                                alt="Drag and Drop"
                                height="80px"
                              />
                              <img
                                src={uploadFile}
                                alt="Upload File"
                                height="80px"
                              />
                            </Stack>
                            <Stack direction="row" justifyContent="right">
                              <Tooltip
                                title={
                                  <Typography>
                                    Scanning documents is mobile only.
                                  </Typography>
                                }
                              >
                                <img
                                  src={scanfile}
                                  alt="Scan File"
                                  height="90px"
                                />
                              </Tooltip>
                            </Stack>
                          </Stack>
                        </>
                      }
                    />
                  </Stack>
                  <Box height="50px" />
                </Stack>
              </Stack>

              {/* TODO: <CheckBoxOutlined functionality added as auto animation upon upload?> */}
              <Collapse in={Boolean(files.length > 0)}>
                <Stack
                  component={Paper}
                  sx={{
                    backgroundColor: "#56234340",
                    fontFamily: "Fira Sans Extra Condensed",
                    border: "1px #9877af solid",
                    borderRadius: 1,
                    m: "15px 0px 25px 5px",
                    p: 2,
                    // width: "600px",
                  }}
                >
                  <Box sx={{ maxHeight: 100, overflowY: "auto" }}>
                    {files.length > 0
                      ? files.map(({ name }, i) => (
                          <Typography
                            key={"file-" + i}
                            fontFamily="Roboto Condensed"
                            color="#F3DDF1"
                            align="right"
                          >
                            {`UPLOADED FILE: ${name}`}
                            <br />
                          </Typography>
                        ))
                      : `Please upload a valid MSF card before continuing.`}
                  </Box>
                  <Stack direction="row">
                    <Button
                      size="small"
                      variant="outlined"
                      onClick={() => {
                        setFiles([]);
                        setImage(null);
                      }}
                    >
                      CANCEL
                    </Button>
                  </Stack>
                  <Stack direction="row" justifyContent="space-between">
                    <Button onClick={handlePrev}>
                      <ChevronLeft />
                    </Button>
                    {image && (
                      <Box
                        component="img"
                        alt="uploaded image"
                        src={image}
                        height={250}
                        sx={{ maxWidth: 600 }}
                      />
                    )}
                    <Button onClick={handleNext}>
                      <ChevronRight />
                    </Button>
                  </Stack>
                </Stack>
              </Collapse>
            </Stack>
            <Box height="40px" />
            <Stack direction="row" justifyContent="right">
              <Button
                color="primary"
                size="small"
                onClick={() => navigate("/MultipleServicesStart")}
                sx={{
                  fontFamily: "Roboto Condensed",
                  variant: "contained",
                  backgroundColor: "#630858",
                  color: "#f9a9f0",
                  fontSize: "18px",
                  borderRadius: 3,
                  px: 2,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#ef15e4",
                  height: "40px",
                }}
              >
                CONTINUE
              </Button>
            </Stack>
          </Stack>
        </Box>
      </Modal>
    </>
  );
};

export default UploadMSF;
