//BACKGROUNDS AND BOXES

import { Paper } from "@mui/material";
// export const Componentdesign ={
export const que_bg_box_medium = {
  background: "#16141B73",
  borderColor: "#3E3A51",
  filter: { boxShadow: "2px" },
  outline: "3px ridge #4917ed",
  outlineOffset: "5px",
  fontSize: 18,
  borderRadius: 7,
  borderStyle: "solid",
  transition: "all 0.2s ease-in-out",
};

export const que_bg_box_light = {
  background: "#645C7F74",
  border: "solid 3px #CBBEFF70",
  borderRadius: 4,
  height: "250px",
  width: "500px",
};

export const landing_box_light = {
  background: "#645C7F34",
  border: "solid 3px #b1a4d5",
  outline: "5px ridge #74c6e8",
  outlineOffset: "-17px",
  fontFamily: "Roboto Condensed",
  fontWeight: "400",
  // fontSize: "32px",
  // minWidth: "60%",
  borderRadius: 4,
  px: 5,
};

export const box_pink_orange = {
  background: "#90408220",
  border: "ridge 3px #fd689f",
  outline: "5px dotted #d959a6",
  outlineOffset: "-17px",
  fontFamily: "Roboto Condensed",
  fontWeight: "400",
  // fontSize: "32px",
  // minWidth: "60%",
  borderRadius: 4,
  px: 5,
};

export const landing_box_dark = {
  background: "#10739e35",

  // "#645C7F54",
  border: "solid 4px #111736",
  outline: "7px ridge #085faf",
  outlineOffset: "7px",
  fontFamily: "Roboto Condensed",
  fontWeight: "400",
  borderRadius: 4,
  px: 5,
};

export const accordion_decoration = {
  background: "#645C7F34",
  border: "solid 3px #b1a4d5",

  fontFamily: "Roboto Condensed",
  fontWeight: "400",
};

export const que_bg_box_dark = {
  background: "#1F1E3165",
  border: "solid 7px #141523",
  borderRadius: 4,
  height: "250px",
  width: "500px",
  boxShadow:
    "rgba(0, 58, 117, 0.1) 0px 2px 1px inset, rgba(11, 13, 14, 0.5) 0px -3px 0px inset, rgb(11, 13, 14) 0px 1px 2px 0px",
  fontSize: 18,
  transition: "all 0.2s ease-in-out",
};

export const stack_svc_box_pink = {
  background: "#4B004320",
  border: "solid 4px #3E3A5154",
  borderRadius: 4,
};

export const svc_xlbg_pink = {
  background: { paper: "#14B004311" },
  border: "ridge 7px #904082",
  alignItems: "center",
  borderRadius: 7,
  fontSize: 36,
  outline: "8px ridge #ffb43f",
  outlineOffset: "10px",
  fontFamily: "Fira Sans Extra Condensed",
  fontWeight: 450,
  transition: "all 0.2s ease-in-out",
  "-webkit-text-stroke": "0.5px #4917ed ",
  "border-stroke": "3.5px #4917ed ",
  // filter:
  boxShadow:
    "rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset,",
};

// KEEP THESE COMMENTS - THEY ARE TO USE TO COPY INTO OTHER MODULES.
// filter: "box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px inset, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset",
// box-shadow: rgb(114, 114, 114) 0px 0px 10px 5px inset;
//poofy-rounded box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px 0px, rgba(0, 0, 0, 0.09) 0px 4px 2px 0px, rgba(0, 0, 0, 0.09) 0px 8px 4px 0px, rgba(0, 0, 0, 0.09) 0px 16px 8px 0px, rgba(0, 0, 0, 0.09) 0px 32px 16px 0px,
//shadowed low elevation: box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset,
//crystal clear glass  box-shadow: rgb(200, 208, 231) 3.2px 3.2px 8px 0px inset, rgb(255, 255, 255) -3.2px -3.2px 8px 0px inset,
//glass at an angle rgba(0, 0, 0, 0.1) 0px 10px 15px -3px inset, rgba(0, 0, 0, 0.1) 0px 4px 6px -4px,

// component={Paper}  color="#2c143f" // border="#f2aeeb 2px solid"

export const svc_bg_box_pink_medium = {
  background: "#29192C85",
  border: "solid 3px #513E4F",
  borderRadius: 7,
  fontSize: 36,
  fontFamily: "Fira Sans Extra Condensed",
  fontWeight: 450,
  height: "900px",
  width: "1700px",
  transition: "all 0.2s ease-in-out",
  boxShadow:
    "rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset",
  filter: {
    // boxShadow:
    //   "rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset",
    dropShadow: "#000 4px 4px 4px 50 inset",
  },
};

export const svc_portal_inset_pink_box = {
  // uses pink medium box as base though!

  alignItems: "center",
  background: "#281329",
  border: " 4px inset  #80607d",
  boxShadow:
    // "rgb(200, 208, 231) 3.2px 3.2px 8px 0px inset, rgb(255, 255, 255) -3.2px -3.2px 8px 0px inset",
    " rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset",
  py: 3,
};

export const snackbar_pink = {
  background: "#A45F9950",
  border: "solid 7px #300F3C",
  color: "#f9afff",
  borderRadius: 5,
  height: 200,
  width: 700,
  fontSize: 25,
  fontFamily: "Fira Sans Extra Condensed",
  fontWeight: 300,
  transition: "all 0.2s ease-in-out",
  filter: "drop-shadow(1px 1px 1px #F3DDF1)",
  filter:
    "box-shadow: rgb(200, 208, 231) 3.2px 3.2px 8px 0px inset, rgb(255, 255, 255) -3.2px -3.2px 8px 0px inset,",
};

// ##c04a76 #5e2071 #281329 #257794 #bbc4bc #1e1a1c #ffb43f #a5a9d7 #74c6e8 #435fdb #111736

export const hist_nav_style_box = {
  background: { paper: "#4E3C5528" },
  border: "solid 4px #141524",
  borderRadius: 3,
  fontSize: 26,
  fontFamily: "Roboto Condensed",
  fontWeight: 350,
  height: "1600px",
  width: "400px",
  transition: "all 0.2s ease-in-out",
  boxShadow:
    "rgb(200, 208, 231) 3.2px 3.2px 8px 0px inset, rgb(255, 255, 255) -3.2px -3.2px 8px 0px inset",
  filter: {
    dropShadow: "#000 0px 4px 4px 25 inset",
  },
};

//BUTTONS

// export const all_btns = {
//   fontFamily: "Roboto Condensed",
//   fontSize: "24px",
//   borderRadius: 3,
//   borderStyle: "solid",
//   paddingInline: 2,
//   borderWidth: 2,
//   minWidth: "200px",
//   maxHeight: "50px",
// };

export const btn_restart = {
  backgroundColor: "#561D29 ",
  color: "#FFB2BD",
  fontSize: "28px",
  borderStyle: "solid",
  borderWidth: 2,
  borderColor: "#922E46",
  borderRadius: 3,
  maxHeight: "60px",
  fontFamily: "Roboto Condensed",
  filter:
    "drop-shadow(rgba(0, 0, 0, 0.1) 0px 10px 15px -3px inset, rgba(0, 0, 0, 0.1) 0px 4px 6px -4px,)",
  transition: "all 0.2s ease-in-out",
  "&:hover": {
    transform: "scale(1.05)",
    backgroundColor: "#64072550",
  },
};

export const btn_svc_history_purple = {
  backgroundColor: "#E7DEFF",
  color: "#33285E",
  fontSize: "28px",
  borderStyle: "solid",
  borderWidth: 4,
  // borderColor: "#B7D32E",
  borderColor: "#493E76",
  borderRadius: 3,
  minWidth: "100px",
  maxHeight: "60px",
  fontFamily: "Fira Sans Extra Condensed",
  fontWeight: 400,
  filter: "drop-shadow(rgba(0, 0, 0, 0.1) ",
  transition: "all 0.2s ease-in-out",
  "&:hover": {
    transform: "scale(1.05)",
    backgroundColor: "#61308240",
    color: "#530858",
  },
};

export const btn_svc_hist_light_blue = {
  backgroundColor: "#00DAF1",
  color: "#001C38",
  fontSize: "28px",
  borderStyle: "solid",
  borderWidth: 4,
  // borderColor: "#B7D32E",
  borderColor: "#9EEFFD",
  borderRadius: 3,
  minWidth: "100px",
  maxHeight: "60px",
  fontFamily: "Fira Sans Extra Condensed",
  fontWeight: 400,
  filter: "drop-shadow(rgba(0, 0, 0, 0.1) ",
  transition: "all 0.2s ease-in-out",
  "&:hover": {
    transform: "scale(1.05)",
    backgroundColor: "#005B6660",
  },
};

export const svc_btn_pink = {
  backgroundColor: "#630858",
  color: "#f9a9f0",
  fontSize: "20px",
  borderStyle: "solid",
  borderWidth: 3,
  borderColor: "#ef15e4",

  borderRadius: 3,
  minWidth: "100px",
  maxHeight: "60px",
  fontFamily: "Roboto Condensed",
  boxShadow:
    "rgba(50, 50, 93, 0.25) 0px 50px 100px -20px inset, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset",
  filter: {
    dropShadow: "1px 1px 1px #fff0fc",
  },
  transition: "all 0.2s ease-in-out",

  "&:hover": {
    transform: "scale(1.05)",
    backgroundColor: "#63085850",
  },
};

export const svc_btn_pink_light = {
  backgroundColor: "#390033",
  color: "#FFACE9",
  fontSize: "20px",
  borderStyle: "solid",
  borderWidth: 2,
  borderColor: "#EA33D7",
  maxHeight: "50px",
  borderRadius: 3,
  fontFamily: "Roboto Condensed",
  filter: "drop-shadow(1px 1px 1px #63085850)",
  transition: "all 0.2s ease-in-out",
  "&:hover": {
    transform: "scale(1.05)",
    backgroundColor: "#63085850",
  },
};

export const svc_btn_green = {
  backgroundColor: "#677901",
  color: "#181E00",
  fontSize: "20px",
  borderRadius: 3,
  borderStyle: "solid",
  borderWidth: 2,
  borderColor: "#B7D32E",
  maxHeight: "50px",
  fontFamily: "Roboto Condensed",

  boxShadow:
    "rgba(0, 58, 117, 0.1) 0px 2px 1px inset, rgba(11, 13, 14, 0.5) 0px -3px 0px inset, rgb(11, 13, 14) 0px 1px 2px 0px",
};
// #4894501 VILLASENOR 4894500
export const btn_maps_hrs = {
  backgroundColor: "#1A1A2B40",
  color: "#aaddff",
  fontSize: "24px",
  borderRadius: 3,
  borderStyle: "solid",
  borderWidth: 2,
  borderColor: "#618AAD",
  minWidth: "120px",
  maxHeight: "70px",
  fontFamily: "Roboto Condensed",
  boxShadow:
    "rgba(0, 58, 117, 0.1) 0px 2px 1px inset, rgba(11, 13, 14, 0.5) 0px -3px 0px inset, rgb(11, 13, 14) 0px 1px 2px 0px",
};
// NOTE:   sx={{ ...svc_blue_btn, borderColor: "#daf" }}
export const svc_blue_btn = {
  backgroundColor: "#00DAF1",
  color: "#00142A",
  fontSize: "24px",
  borderRadius: 3,
  borderStyle: "solid",
  borderWidth: 4,
  borderColor: "#0C79D1",
  minWidth: "100px",
  maxHeight: "50px",
  fontFamily: "Roboto Condensed",
  boxShadow:
    "rgba(0, 58, 117, 0.1) 0px 2px 1px inset, rgba(11, 13, 14, 0.5) 0px -3px 0px inset, rgb(11, 13, 14) 0px 1px 2px 0px",
};
export const svc_btn_purple = {
  backgroundColor: "#1D1148",
  color: "#CBBEFF",
  fontSize: "20px",
  borderRadius: 3,
  borderStyle: "solid",
  borderWidth: 2,
  borderColor: "#4917ed",
  // 4f2bc6
  maxHeight: "50px",
  width: "auto",
  fontFamily: "Roboto Condensed",

  boxShadow:
    "#2c095e 0px 2px 1px inset, #201F2450 0px -1px 0px inset, #4f2bc6 0px 1px 2px 0px",

  transition: "all 0.2s ease-in-out",
  "&:hover": {
    transform: "scale(1.05)",
    backgroundColor: "#40009b30",
  },
};

//TYPOGRAPHIES
export const typ_fira_title = {
  fontSize: 40,
  color: "#F3DDF1",
  px: 2,
  letterSpacing: 3,
  fontWeight: 450,
  fontFamily: "Fira Sans Extra Condensed",
  filter: "drop-shadow: #000 0px 4px 4px 25 inset",
  py: 1,
  align: "center",
};
export const typ_fira_xLarge_thin = {
  fontSize: 50,
  color: "#F3DDF1",
  px: 2,
  letterSpacing: 1,
  fontWeight: 350,
  fontFamily: "Fira Sans Extra Condensed",

  py: 1,
  align: "center",
};
export const typ_fira_subheader = {
  fontSize: 30,
  color: "#F3DDF1",
  px: 2,
  fontWeight: 250,
  fontFamily: "Fira Sans Extra Condensed",
  py: 1,
  align: "center",
};

export const typ_roboto_header = {
  align: "center",
  fontSize: 32,
  px: 4,
  fontWeight: "Medium",
  fontFamily: "Roboto Condensed",
  py: 1,
};
export const typ_roboto_normal = {
  // align: "center",
  align: "left",
  fontSize: 22,
  px: 4,
  fontWeight: 400,
  fontFamily: "Roboto Condensed",
  py: 1,
};
{
  /* <Stack alignItems="center" justifyContent="space-evenly">
<Typography
  fontSize={40}
  fontFamily="FIRA SANS EXTRA CONDENSED"
  py={1}
  sx={{ color: "#B7D32E", filter: "drop-shadow(1px 1px 1px #aff)" }}
>
     <Stack
                alignItems="center"
                justifyContent="center"
                direction="row"
              >
                <Typography
                  sx={{
                    align: "center",
                    fontSize: 28,
                    fontFamily: "Roboto Condensed",
                    py: 1,
                    color: "#4917ed",
                    filter: "drop-shadow(1px 1px 1px #aff)",
                  }}
                >
*/
}
export const typ_roboto_sub = {
  align: "center",

  fontSize: 25,
  fontFamily: "Roboto Condensed",
  py: 1,
};

export const typ_roboto_lightitalic = {
  align: "center",
  fontSize: 22,
  fontFamily: "Roboto Condensed",
  py: 1,
  fontWeight: "Light",
  fontStyle: "Oblique",
};
export const typ_roboto_lightsmall = {
  align: "center",
  fontSize: 22,
  fontFamily: "Roboto Condensed",
  py: 1,
  fontWeight: "Extra Light",
  fontStyle: "Oblique",
};
export const typ_roboto_regular = {
  align: "center",
  fontSize: 22,
  fontFamily: "Roboto Condensed",
  py: 1,
  fontWeight: "Regular",
  // fontStyle: "Oblique",
};

//note:   "#B7D32E"  d9ff05   e1ff38:

export const typ_servnav = {
  fontSize: "20px",
  color: "#A4BC34",
  fontWeight: "light",
  fontStyle: "oblique",
  fontFamily: "Roboto Condensed",
  letterSpacing: 1,
  stroke: "text.stroke",
  mx: 5,
};

//EXTRAS
//tried to make "circle_fab_dp or circle_fab_darkpurple, but couldnt"

//homenav alternative?
export const homenav_op2 = {
  borderRadius: "5px",
  display: {
    filter: "drop-shadow(3px 4px 0px #d5f99a)",
  },
};

export const circle_fab = {
  fontSize: 34,
  height: 100,
  width: 100,
  borderRadius: 100,
  color: "#F1ECF4",
  borderColor: "#CBBEFF",
  backgroundColor: "#33285E",
};
export const circle_fab_blue = {
  fontSize: 34,
  height: 100,
  width: 100,
  borderRadius: 100,
  color: "#0060A9",
  borderColor: "#CBBEFF",
  backgroundColor: "#00203F",
};
export const circle_fab_lightblue = {
  fontSize: 34,
  height: 100,
  width: 100,
  borderRadius: 100,
  color: "#001C38",
  borderColor: "#CBBEFF",
  backgroundColor: "#6BAEFF",
};
export const scrollbar_color = {
  "::-webkit-scrollbar-thumb": {
    background: "#ffb74d",
  },
  "::-webkit-scrollbar-thumb:hover": {
    background: "#00e5ff",
  },
};
export const scroll = {
  "::-webkit-scrollbar-thumb": {
    background: "#200B5B43",
  },
  overflowY: "auto",
  overflowX: "auto",
};

export const exppic = {
  opacity: "20%",
  position: "center",
};

export const paginationGreen = {
  position: "absolute",
  left: "5%",
  bottom: 50,
  fontSize: "100px",
  color: "#daf349",
  // #d9ff05, "#B7D32E
};

export const wilkommen = {};

//note            // sx={{ ...svc_blue_btn, borderColor: "#daf" }}
//note:
// const theme = createTheme({
//   components: {
//     MuiTypography: {
//       defaultProps: {
//         variantMapping: {
//           h1: 'h2',
//           h2: 'h2',
//           h3: 'h2',
//           h4: 'h2',
//           h5: 'h2',
//           h6: 'h2',
//           subtitle1: 'h2',
//           subtitle2: 'h2',
//           body1: 'span',
//           body2: 'span',
//         },
//       },
//     },
//   },
// });
