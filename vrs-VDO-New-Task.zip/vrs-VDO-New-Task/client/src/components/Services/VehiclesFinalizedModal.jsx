import {
  Box,
  Stack,
  Typography,
  Button,
  Modal,
  IconButton,
  Snackbar,
  Alert,
} from "@mui/material";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { green_car, uploadcancel } from "../../imgs";
import HomeNav from "../Buttons/HomeNav";
import { HouseRounded } from "@mui/icons-material";

// TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE
// TODO: NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY
// TODO: USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES

const VehiclesFinalizedModal = ({ open, handleClose }) => {
  const navigate = useNavigate();
  const action = (
    <IconButton onClick={() => navigate("/UserDashboard/vehicles")}>
      <HouseRounded size="large" color="secondary" />
    </IconButton>
  );

  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          maxHeight: "90vw",
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <Stack
          className="upload"
          sx={{
            width: 900,
            mx: "auto",
            mt: "20vh",
            p: 2,
            border: "2px solid #c8c9b5",
            backgroundColor: "#1A1429",
            borderRadius: "12px 12px 12px 12px",
          }}
        >
          <Snackbar open={open} onClose={handleClose} action={action}>
            <Alert
              onClose={handleClose}
              severity="info"
              variant="filled"
              action={action}
              sx={{
                height: "50px",
                vertical: "top",
                horizontal: "center",
                fontFamily: "Roboto Condensed",
              }}
            >
              Request edits and cancellations are available to you in your
              Requests' section of your User Dashboard.
            </Alert>
          </Snackbar>

          <Stack
            direction="row-reverse"
            justifyContent="space-between"
            alignItems="flex-start"
          >
            <IconButton onClick={handleClose}>
              <img src={uploadcancel} alt="cancel" height="40px" />
            </IconButton>
            <Stack justifyContent="center">
              <Typography
                fontSize="30px"
                fontFamily="Fira Sans Extra Condensed"
                color="#d35d9c"
                align="center"
              >
                GREAT!
              </Typography>
              <Typography
                fontSize="30px"
                fontFamily="Fira Sans Extra Condensed"
                color="#e9ead3"
                align="center"
                px={5}
              >
                Let's get started with your FIRST vehicle.
              </Typography>
              <Typography
                fontSize="20px"
                fontFamily="Fira Sans Extra Condensed"
                color="#f7b9db"
                align="center"
                px={5}
              >
                <br /> We will handle each of your vehicles one at a time and
                will check to make sure you meet all the requirements and have
                all the services you need for each one before you submit your
                request. <br /> <br /> Please complete the following steps for
                your FIRST vehicle ONLY. <br /> You will have the opportunity to
                review each service and its associated document requirements at
                the end of each vehicle request and again for ALL of your
                vehicles before your final submission.
                <br />
              </Typography>
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
              >
                <Box
                  align="left"
                  component="img"
                  src={green_car}
                  alt="green_car"
                  width={125}
                />
                <Button
                  onClick={() => navigate("/MultipleServicesStart")}
                  sx={{
                    fontFamily: "Roboto Condensed",
                    variant: "contained",
                    backgroundColor: "#630858",
                    color: "#f9a9f0",
                    fontSize: "18px",
                    borderRadius: 3,
                    px: 2,
                    borderStyle: "solid",
                    borderWidth: 2,
                    borderColor: "#ef15e4",
                    height: "50px",
                  }}
                >
                  CONTINUE
                </Button>
              </Stack>
            </Stack>
          </Stack>
        </Stack>
      </Modal>
    </>
  );
};

export default VehiclesFinalizedModal;
