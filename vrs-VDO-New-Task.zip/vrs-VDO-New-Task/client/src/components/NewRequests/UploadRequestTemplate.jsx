import { Card, Stack, Typography, Button } from "@mui/material";
import MainHeaderServices from "../MainHeaderServices";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import ServicesNav from "../Dashboard/ServicesNav";
import RequestNav from "../RequestPage/RequestNav";
import UploadTemplate from "../Services/UploadTemplate";

// TODO This might be useless, delete after 5/01/2024 if this message remains.
const UploadFileTemplate = ({
  header1,
  header2,
  footer1,
  footer2,
  backLink,
  continueLink,
}) => {
  const navigate = useNavigate();

  return (
    <Stack>
      <MainHeaderServices />
      <Stack direction="row">
        <RequestNav />
        <Stack padding={2} spacing={2}>
          <ServicesNav />
          <Stack alignItems="center">
            <Typography variant="h6" color="#F3DDF1" fontSize="35px">
              {header1}
            </Typography>
            <Typography variant="h6" color="#F3DDF1" fontSize="35px">
              {header2}
            </Typography>
          </Stack>
          <Stack padding={2} spacing={2} alignItems="center">
            <Card
              sx={{
                borderRadius: 4,
                width: "80%",
                border: "4px solid #904082",
                backgroundColor: "rgba(38, 20, 41, 0.0)",
              }}
            >
              <UploadTemplate />
              <Stack direction="row" justifyContent="space-between" padding={2}>
                <Stack alignItems="start">
                  <Button
                    variant="contained"
                    sx={{
                      borderRadius: 4,
                      border: "4px solid #EA33D7",
                      backgroundColor: "#FFACE9",
                      color: "#390033",
                      fontWeight: 700,
                    }}
                    onClick={() => navigate(`${backLink}`)}
                  >
                    Back
                  </Button>
                </Stack>
                <Stack alignItems="end">
                  <Button
                    variant="contained"
                    sx={{
                      borderRadius: 4,
                      border: "4px solid #EA33D7",
                      backgroundColor: "#FFACE9",
                      color: "#390033",
                      fontWeight: 700,
                    }}
                    onClick={() => navigate(`${continueLink}`)}
                  >
                    CONTINUE
                  </Button>
                </Stack>
              </Stack>
            </Card>
          </Stack>
          <Stack alignItems="center">
            <Card
              sx={{
                borderRadius: 4,
                width: "79%",
                border: "2px solid",
                backgroundColor: "rgba(38, 20, 41, 0.1)",
              }}
            >
              <Stack alignItems="center">
                <Typography color="#F3DDF1" fontSize="15px">
                  {footer1}
                </Typography>
                <Typography color="#F3DDF1" fontSize="15px">
                  {footer2}
                </Typography>
              </Stack>
            </Card>
          </Stack>
        </Stack>
      </Stack>
    </Stack>
  );
};

export default UploadFileTemplate;
