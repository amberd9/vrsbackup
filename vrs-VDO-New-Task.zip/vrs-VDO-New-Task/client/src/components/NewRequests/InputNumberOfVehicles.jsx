import { Box, Card, CardMedia, Stack } from "@mui/material";
import { Motorcycle, OrangeCar } from "../../imgs/RequestPageImages";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import { Fab } from "@mui/material";
import { useState } from "react";
import { Typography } from "@mui/material";

export default function InputNumberOfVehicles() {
  const [orangeCarValue, setOrangeCarValue] = useState(0);
  const [motorcycleValue, setMotorcycleValue] = useState(0);

  // TODO The redux has not been implemented yet
  // TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE
  // TODO: NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY
  // TODO: USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES

  return (
    <Stack display="flex" alignItems="center">
      <Card
        sx={{
          maxWidth: 700,
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          overflowY: "auto",
          border: "2px solid #666886",
          borderRadius: 4,
        }}
      >
        <CardMedia>
          <Stack padding={6} alignItems="center">
            <Stack direction="row" alignItems="center" spacing={5}>
              <Box>
                <Box
                  component="img"
                  src={OrangeCar}
                  alt="Orange Car"
                  maxWidth={200}
                />
              </Box>

              <Box>
                <Box
                  component="img"
                  src={Motorcycle}
                  alt="Motorcycle"
                  maxWidth={200}
                  align="center"
                />
              </Box>
            </Stack>
            <Stack direction="row" spacing={5}>
              <Stack direction="row" justifyContent="center" spacing={2}>
                <Fab
                  size="medium"
                  color="info"
                  onClick={() => setOrangeCarValue(orangeCarValue - 1)}
                  disabled={orangeCarValue === 0}
                >
                  <RemoveIcon />
                </Fab>
                <Stack
                  sx={{
                    minWidth: "5rem",
                    minHeight: "3rem",
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Typography type="number">{orangeCarValue}</Typography>
                </Stack>
                <Fab
                  size="medium"
                  color="info"
                  onClick={() => setOrangeCarValue(orangeCarValue + 1)}
                  disabled={orangeCarValue === 5}
                >
                  <AddIcon />
                </Fab>
              </Stack>
              <Stack direction="row" justifyContent="center" spacing={2}>
                <Fab
                  size="medium"
                  color="info"
                  onClick={() => setMotorcycleValue(motorcycleValue - 1)}
                  disabled={motorcycleValue === 0}
                >
                  <RemoveIcon />
                </Fab>
                <Box
                  sx={{
                    minWidth: "5rem",
                    minHeight: "3rem",
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    alignItems: "center",
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <Typography type="number">{motorcycleValue}</Typography>
                </Box>

                <Fab
                  size="medium"
                  color="info"
                  onClick={() => setMotorcycleValue(motorcycleValue + 1)}
                  disabled={motorcycleValue === 5}
                >
                  <AddIcon />
                </Fab>
              </Stack>
            </Stack>
          </Stack>
        </CardMedia>
      </Card>
    </Stack>
  );
}
