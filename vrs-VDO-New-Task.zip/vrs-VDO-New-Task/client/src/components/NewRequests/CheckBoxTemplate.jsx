import {
  Card,
  CardMedia,
  Stack,
  Typography,
  Button,
  FormControlLabel,
  Checkbox,
  Link,
  Box,
} from "@mui/material";
import MainHeaderServices from "../MainHeaderServices";
import ServicesNav from "../Dashboard/ServicesNav";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import RequestNav from "../RequestPage/RequestNav";

// There may be more than one option for the same prop, this is for better control over text.
const CheckBoxTemplate = ({
  header1,
  header2,
  cardHeader,
  image,
  cardFooter,
  footerLink,
  backLink,
  continueLink,
  cardFooterNote,
}) => {
  const [check, setCheck] = useState(false);
  const navigate = useNavigate();
  return (
    <Stack>
      <MainHeaderServices />
      <Stack direction="row">
        <RequestNav />
        <Stack padding={2} spacing={2}>
          <ServicesNav />
          <Stack alignItems="center">
            <Typography variant="h6" color="#F3DDF1" fontSize="30px">
              {header1}
            </Typography>
            <Typography variant="h6" color="#F3DDF1" fontSize="30px">
              {header2}
            </Typography>
          </Stack>
          <Stack alignItems="center">
            <Card
              sx={{
                borderRadius: 4,
                width: "80%",
                border: "4px solid #904082",
                backgroundColor: "rgba(38, 20, 41, 0.1)",
              }}
            >
              <Stack spacing={4} padding={3}>
                <Stack alignItems="center">
                  <Typography color="#F3DDF1" fontSize="25px">
                    {cardHeader}
                  </Typography>
                  <Stack
                    direction="row"
                    alignItems="center"
                    padding={3}
                    spacing={3}
                  >
                    <CardMedia
                      sx={{
                        borderRadius: 4,
                        border: "2px solid",
                        backgroundColor: "rgba(38, 20, 41, 0.7)",
                      }}
                    >
                      <Box
                        component="img"
                        src={image}
                        padding={2}
                        maxWidth={400}
                        maxHeight={400}
                      />
                    </CardMedia>
                    <FormControlLabel
                      required
                      control={
                        <Checkbox
                          color="success"
                          checked={check}
                          onChange={() => setCheck(!check)}
                          sx={{ "& .MuiSvgIcon-root": { fontSize: 60 } }}
                        />
                      }
                    />
                  </Stack>
                </Stack>
                <Stack direction="row" justifyContent="space-between">
                  <Stack alignItems="start">
                    <Button
                      color="error"
                      sx={{
                        borderRadius: 4,
                        border: "4px solid #904082",
                        backgroundColor: "rgba(38, 20, 41, 0.1)",
                        minWidth: 125,
                      }}
                      onClick={() => navigate(`${backLink}`)}
                    >
                      Back
                    </Button>
                  </Stack>
                  <Stack alignItems="end">
                    <Button
                      color="error"
                      sx={{
                        borderRadius: 4,
                        border: "4px solid #904082",
                        backgroundColor: "rgba(38, 20, 41, 0.1)",
                        minWidth: 125,
                      }}
                      disabled={check === false}
                      onClick={() => navigate(`${continueLink}`)}
                    >
                      CONTINUE
                    </Button>
                  </Stack>
                </Stack>
              </Stack>
            </Card>
          </Stack>
          <Stack alignItems="center">
            <Typography variant="h5" color="#A3C9FE" fontSize="25px">
              {cardFooterNote}
            </Typography>
          </Stack>
          <Stack alignItems="center">
            <Typography variant="h4" color="#D5F632" fontSize="15px">
              {cardFooter} (
              <Link
                href={`${footerLink}`}
                underline="none"
                fontSize="15px"
                color="#D5F632"
              >
                Click Here
              </Link>
              )
            </Typography>
          </Stack>
        </Stack>
      </Stack>
    </Stack>
  );
};

export default CheckBoxTemplate;
