import { AppBar, Toolbar, Button, Box, Stack } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { eightsix, fivesixnine, sword, usag } from "../../imgs";

function LandingNavBar() {
  const btStyle = {
    variant: "text",
    sx: { color: "#fff" },
  };
  return (
    <Stack>
      <AppBar>
        <Toolbar
          sx={{
            justifyContent: "space-between",
            alignItems: "center",
            background: "#002",
          }}
        >
          <Box pt={1}>
            <Box component="img" src={eightsix} alt="" height={50} />
            <Box component="img" src={fivesixnine} alt="" height={50} />
            <Box component="img" src={sword} alt="" height={50} />
            <Box component="img" src={usag} alt="" height={50} />
          </Box>
          <Box>
            <Button {...btStyle} href="#about_us_title">
              About Us
            </Button>
            <Button {...btStyle} href="#partners_title">
              Partners
            </Button>
            <Button {...btStyle} href="#contact_us_title">
              Contact Us
            </Button>
          </Box>
        </Toolbar>
      </AppBar>
    </Stack>
  );
}

export default LandingNavBar;
