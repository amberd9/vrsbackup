import { svc_btn_pink_light } from "../Services/WalkthruCSS";
import DerosDate from "./DerosDate";
import NatoConfirmation from "./NatoConfirmation";
import { Typography, Stack, Container, Button, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";

const UserRegistration = () => {
  const navigate = useNavigate();
  return (
    <Container maxWidth="md">
      <Stack alignItems="center" justifyContent="center" gap={4} height="100vh">
        <Typography align="center" variant="h4" mt={4}>
          Vehicle Registration is dedicated to making sure your appointment is
          done right the first time!
        </Typography>
        <NatoConfirmation />
        <DerosDate />
        <Box width="100%" align="right">
          <Button
            sx={svc_btn_pink_light}
            onClick={() => navigate("/userDashboard/vehicles")}
          >
            Continue
          </Button>
        </Box>
      </Stack>
    </Container>
  );
};

export default UserRegistration;
