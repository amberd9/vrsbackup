import { Typography, Stack, Paper, Button } from "@mui/material";
import { svc_btn_pink_light } from "../Services/WalkthruCSS";
import { useNavigate } from "react-router-dom";

const NatoConfirmation = () => {
  const navigate = useNavigate();
  return (
    <Paper elevation={0} sx={styles.card}>
      <Stack>
        <Typography variant="h6" sx={{ textAlign: "center", m: 1 }}>
          Please confirm if you are a NATO employee
        </Typography>
        <Stack>
          <Stack direction="row" justifyContent="space-around" flex={1}>
            <Stack variant="text">
              <img
                src="./confused_astronaut.png"
                style={{
                  maxHeight: "100%",
                  maxWidth: "100%",
                }}
              />
            </Stack>
          </Stack>
          <Stack direction="row" justifyContent="space-evenly" mt={2}>
            <Button sx={svc_btn_pink_light} variant="contained">
              Yes
            </Button>
            <Button sx={svc_btn_pink_light} variant="contained">
              No
            </Button>
          </Stack>
        </Stack>
      </Stack>
    </Paper>
  );
};

const styles = {
  card: {
    height: "fit-content",
    width: "95%",
    maxWidth: "600px",
    alignSelf: "center",
    padding: "1rem",
    backgroundColor: "#221E24",
  },
  button: {
    height: "fit-content",
    alignSelf: "center",
    border: "1px solid #fff",
    backgroundColor: "#00C0AD",
    fontWeight: "bold",
  },
  text: {
    textAlign: "center",
    color: "#FFA857",
    fontWeight: "bold",
  },
};

export default NatoConfirmation;
