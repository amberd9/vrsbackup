import { Typography, Stack, Paper, TextField } from "@mui/material";


const DerosDate = () => {
  return (
    <Paper elevation={0} sx={styles.card}>
      <Typography sx={{ textAlign: "center" }}>
        please enter your DEROS
      </Typography>
      <Stack sx={{ width: "80%", alignSelf: "center" }}>
        <Typography
          sx={{ fontSize: ".7rem", fontWeight: "bold", color: "#FFA857" }}
        >
          DEROS
        </Typography>
        <TextField
          type="date"
          InputProps={{
            sx: { borderRadius: "20px", backgroundColor: "#65666F" },
          }}
          sx={{
            alignSelf: "center",
            width: "100%",
            padding: ".5rem",
          }}
        />
      </Stack>
    </Paper>
  );
};

const styles = {
  card: {
    height: "fit-content",
    minHeight: "150px",
    maxWidth: "600px",
    backgroundColor: "#221E24",
    width: "80%",
    alignSelf: "center",
    padding: "1rem",
    margin: "1rem",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-evenly",
  },
};

export default DerosDate;
