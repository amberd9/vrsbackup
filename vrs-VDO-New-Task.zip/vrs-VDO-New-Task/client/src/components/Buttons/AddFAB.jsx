import { Fab } from "@mui/material";
import { AddCircleOutlineRounded } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export default function AddFAB() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  return (
    <Fab color="secondary" onClick={() => setOpen(true)}>
      <AddCircleOutlineRounded />
    </Fab>
  );
}
