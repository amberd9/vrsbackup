import { Fab } from "@mui/material";
import { OpenInNewRounded } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export default function OpenFAB() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  return (
    <Fab color="secondary" onClick={() => setOpen(true)}>
      <OpenInNewRounded />
    </Fab>
  );
}
