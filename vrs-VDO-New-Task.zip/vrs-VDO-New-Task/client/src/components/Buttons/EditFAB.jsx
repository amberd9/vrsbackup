import { Fab } from "@mui/material";
import { ModeEditRounded } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export default function EditFAB() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  return (
    <Fab color="secondary">
      <ModeEditRounded />
    </Fab>
  );
}
