import { Fab, Tooltip } from "@mui/material";
import { HouseRounded } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

const HomeNav = () => {
  const navigate = useNavigate();
  return (
    <Tooltip title="Return to User Dashboard">
      <Fab
        // variant="extended"   variant="circular"
        color="secondary"
        aria-label="Home"
        onClick={() => navigate("/UserDashboard/vehicles")}
        sx={{
          borderRadius: "5px 30px 5px 35px",

          display: {
            filter: "drop-shadow(3px 4px 0px #d5f99a)",
          },
        }}
      >
        <HouseRounded sx={{ fontSize: "40px" }} />
        {/* <img src={purplenav} height="40px" /> */}
      </Fab>
    </Tooltip>
  );
};

export default HomeNav;
