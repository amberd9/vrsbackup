import { Fab } from "@mui/material";
import { EventAvailableRounded } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export default function ApptFAB() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  return (
    <Fab color="secondary" onClick={() => setOpen(true)}>
      <EventAvailableRounded />
    </Fab>
  );
}
