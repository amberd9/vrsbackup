import { useState } from "react";
import { IconButton } from "@mui/material";
import { cancel } from "../../imgs";

const CancelIcon = ({}) => {
  return (
    <>
      <IconButton sx={{ position: "absolute", top: 5, right: 5 }} size="small">
        <img src={cancel} alt="cancel" height="30px" />
      </IconButton>
    </>
  );
};

export default CancelIcon;
