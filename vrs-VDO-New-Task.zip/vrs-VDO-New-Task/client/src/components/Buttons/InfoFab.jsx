import { Fab, Tooltip } from "@mui/material";
import { HouseRounded } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { purplenav } from "../../imgs";

const HomeNav = () => {
  const navigate = useNavigate();
  return (
    <Tooltip title="Return to User Dashboard">
      <Fab
        // variant="extended"
        onClick={() => navigate("/UserDashboard/vehicles")}
        sx={{
          borderRadius: 4,

          background: "#493E76",
          display: {
            // filter: "drop-shadow(2px 3px 2px #d5f99a)",
          },
        }}
      >
        {/* <HouseRounded sx={{ fontSize: "40px" }} /> */}
        <img src={purplenav} height="40px" />
      </Fab>
    </Tooltip>
  );
};

export default HomeNav;
