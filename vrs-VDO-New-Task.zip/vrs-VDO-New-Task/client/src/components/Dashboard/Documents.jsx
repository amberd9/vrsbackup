import { useState } from "react";
import {
  Stack,
  Button,
  Typography,
  Paper,
  Box,
  Divider,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import { ArrowDownwardRounded } from "@mui/icons-material";
import { ArrowDropDownIcon } from "@mui/x-date-pickers";
import { astroReadingWCoffee } from "../../imgs";

const Documents = () => {
  const [addOpen, setAddOpen] = useState(false);
  const [dbSplashOpen, setDBSplashOpen] = useState(false);
  //   const elementPlacing = { zIndex: 1 };

  {
    /* <Stack justifyContent="bottom" alignSelf="center"> */
  }
  {
    /* <Stack maxWidth="200px" gap={1} ml={3} spacing={1} mt={2.0} justifyContent="center" ml={2}> */
  }
  return (
    <>
      <Stack
        // position="relative"
        direction="row-reverse"
        // alignItems="center"
        justifyContent="space-evenly"
        // justifyContent="center"
        pt="1%"
        display="flex"
        sx={{
          "::-webkit-scrollbar-thumb": {
            background: "#ffb74d",
          },
          "::-webkit-scrollbar-thumb:hover": {
            background: "#00e5ff",
          },
          overflowY: "auto",
          borderRadius: 4,
          backgroundColor: "tertiary",
        }}
      >
        <img src={astroReadingWCoffee} alt="astroreader" height={400} />
        <Stack width="40%">
          <Stack justifyContent="space-evenly">
            <Typography
              fontSize="28px"
              fontFamily="Fira Sans Extra Condensed"
              color="#d35d9c"
              align="center"
            >
              <br /> BROWSE DOCUMENTS BY SERVICE <br />
            </Typography>
            <Typography
              fontSize="22px"
              fontFamily="Fira Sans Extra Condensed"
              color="#e9ead3"
              align="center"
              px={5}
            >
              <br /> Some Documents are controlled items - templates and
              instructions are provided in their place.
              <br /> <br />
            </Typography>
          </Stack>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="Roboto Extra Condensed"
              id="newreg-header"
            >
              <Typography>INITIAL REGISTRATIONS</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>DOCUMENT: AEF-910</Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDropDownIcon />}
              id="regrenew-header"
            >
              <Typography>REGISTRATION RENEWALS</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                NON-OP WAIVER TEMPLATE: ARMY <br /> NON-OP WAIVER TEMPLATE: AIR
                FORCE
              </Typography>
            </AccordionDetails>{" "}
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="Roboto Extra Condensed"
              id="newreg-header"
            >
              <Typography>INITIAL REGISTRATIONS</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>DOCUMENT: AEF-910</Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDropDownIcon />}
              id="regrenew-header"
            >
              <Typography>REGISTRATION RENEWALS</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                NON-OP WAIVER TEMPLATE: ARMY <br /> NON-OP WAIVER TEMPLATE: AIR
                FORCE
              </Typography>
            </AccordionDetails>{" "}
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="Roboto Extra Condensed"
              id="newreg-header"
            >
              <Typography>DE-REGISTRATIONS</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>SHIPPING</Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDropDownIcon />}
              id="regrenew-header"
            >
              <Typography>UPDATE REGISTRATION</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                NAME CHANGE <br /> SEPARATION/RETIREMENT
              </Typography>
            </AccordionDetails>
          </Accordion>
        </Stack>
      </Stack>
      {/* </Stack> */}
      {/* </Stack> */}
    </>
  );
};
export default Documents;
