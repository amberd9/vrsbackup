import {
  Button,
  Box,
  Stack,
  Paper,
  Typography,
  Tabs,
  Tab,
  Divider,
} from "@mui/material";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const DashNav = () => {
  const navigate = useNavigate();
  const [currentTab, setCurrentTab] = useState(1);
  return (
    <>
      <Stack component={Paper}>
        <Stack
          direction="row"
          alignItems="center"
          justify-content="space-between"
          px={2}
        >
          <Typography
            fontSize="32px"
            fontWeight="light"
            fontStyle="Oblique"
            fontFamily="Fira Sans Extra Condensed"
            letterSpacing={2.5}
            sx={{
              display: {
                xs: "none",
                sm: "block",
                filter: "drop-shadow(2px 1px 0px #b6aae870)",
              },
            }}
            flex={1}
            align="center"
          >
            VRS User Dashboard
          </Typography>
          <Typography
            variant="h6"
            fontSize="28px"
            noWrap
            color="text.secondary"
            fontWeight="light"
            fontStyle="Italic"
            fontFamily="Fira Sans Extra Condensed"
            letterSpacing={2.5}
            lineHeight={1.5}
            sx={{ display: { xs: "none", sm: "block" } }}
          >
            Welcome, [User]!
          </Typography>
          <Box flex={1} align="center">
            <Button
              onClick={() => {
                navigate("/QueueIn");
              }}
              variant="contained"
              sx={{
                textColor: "#2A2D54",
                borderWidth: 4,
                borderStyle: "solid",
                borderRadius: 3,
                borderColor: "#AAA3F0",
                fontFamily: "Fira Sans Extra Condensed",
                fontWeight: "Bold",
                fontSize: "24px",
                lineHeight: "1",
              }}
            >
              QUEUE IN
            </Button>
          </Box>
        </Stack>
        <Stack alignItems="center">
          <Tabs
            value={currentTab}
            onChange={(event, newValue) => setCurrentTab(newValue)}
            textColor="primary"
          >
            <Tab
              value={1}
              label="Vehicles"
              onClick={() => navigate("vehicles")}
              textColor="primary"
            />
            <Tab
              value={2}
              label="Requests"
              onClick={() => navigate("requests")}
            />
            <Tab
              value={3}
              label="Appointments"
              onClick={() => navigate("appointments")}
            />
            <Tab
              value={4}
              label="Documents"
              onClick={() => navigate("documents")}
              textColor="primary"
            />
            <Tab
              value={5}
              label="Resources & FAQs"
              onClick={() => navigate("resources")}
              textColor="primary"
            />
            <Tab
              value={6}
              label="Contact"
              onClick={() => navigate("contact")}
              textColor="primary"
            />
            <Tab
              value={7}
              label="Partners"
              onClick={() => navigate("partners")}
              textColor="primary"
            />
            <Tab
              value={8}
              label="Feedback"
              onClick={() => navigate("feedback")}
              textColor="primary"
            />
          </Tabs>
        </Stack>
      </Stack>
    </>
  );
};

export default DashNav;
