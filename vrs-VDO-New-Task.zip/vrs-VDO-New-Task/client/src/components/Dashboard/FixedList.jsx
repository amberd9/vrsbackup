import Card from "@mui/material/Card";
import Divider from "@mui/material/Divider";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Radio from "@mui/material/Radio";
import { FixedSizeList } from "react-window";

const FixedList = ({
  HeaderText,
  FirstLineData,
  SecondLineData,
  checkedIndex,
  setCheckedIndex,
}) => {
  return (
    <Card sx={styles.container}>
      <Typography
        color="#fff"
        variant="h5"
        p=".5rem"
        sx={{ backgroundColor: "#66688650" }}
      >
        {HeaderText}
      </Typography>

      <Divider flexItem />

      <Box>
        <FixedSizeList height={200} width="100%" itemSize={70} itemCount={10}>
          {({ index, style }) => (
            <Stack
              alignSelf="start"
              style={style}
              direction="row"
              justifyContent="stretch"
            >
              <Radio
                checked={checkedIndex === index}
                onChange={(event) => setCheckedIndex(index)}
              />
              <Stack sx={{ justifyContent: "center" }}>
                <Typography
                  variant="h6"
                  sx={{ fontStyle: "italic", textAlign: "start" }}
                >
                  {FirstLineData[index]}
                </Typography>
                <Typography
                  variant="body1"
                  sx={{ fontStyle: "italic", textAlign: "start" }}
                >
                  {SecondLineData[index]}
                </Typography>
              </Stack>
            </Stack>
          )}
        </FixedSizeList>
      </Box>
    </Card>
  );
};

const styles = {
  container: {
    border: "2px solid #666886",
    borderRadius: 4,
    minWidth: "500px",
    maxHeight: "250px",
    m: ".5rem",
    textAlign: "center",
    alignSelf: "center",
  },
};

export default FixedList;
