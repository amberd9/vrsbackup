import {
  Box,
  Button,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
  Stack,
  Fab,
  Typography,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import {
  CampaignRounded,
  EventAvailableTwoTone,
  HandymanTwoTone,
  HourglassTopRounded,
} from "@mui/icons-material";

const UserNav = () => {
  const navigate = useNavigate();
  return (
    <Box justifyContent="flex-Start">
      <List className="avatar2">
        {["Username"].map((text, index) => (
          <ListItem key={text}>
            <ListItemButton>
              <ListItemIcon>{/* <Avatar /> */}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      <List>
        {["Name", "Affiliation/Service"].map((text, index) => (
          <ListItem key={text}>
            <ListItemText primary={text} />
          </ListItem>
        ))}
        <ListItem>
          <Button
            onClick={() => navigate("/EditProfile")}
            sx={{
              textColor: "#2A2D54",
              borderWidth: 4,
              borderStyle: "solid",
              borderRadius: 3,
              borderColor: "#AAA3F0",
              fontFamily: "Fira Sans Extra Condensed",
              fontWeight: "Bold",
              fontSize: "18px",
              lineHeight: ".6",
            }}
          >
            Edit Profile
          </Button>
        </ListItem>
      </List>
      <Divider />
      <List>
        {[
          { text: "Appointments", Icon: EventAvailableTwoTone },
          { text: "Notifications", Icon: CampaignRounded },
          { text: "Account Settings", Icon: HandymanTwoTone },
        ].map(({ text, Icon }, index) => (
          <ListItem key={index} disablePadding>
            <ListItemButton>
              <ListItemIcon>
                <Icon />
              </ListItemIcon>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      <Stack spacing={1} px={1}>
        <Typography variant="h6" color="white">
          Registration Expiration
        </Typography>
        <Fab
          color="secondary"
          onClick={() => navigate("./UserDashboard")}
          variant="extended"
          sx={{ width: "100%", justifyContent: "left" }}
          size="medium"
        >
          <HourglassTopRounded /> # Days Left
        </Fab>
      </Stack>
      <Box spacing={1} px={1} height="290px"></Box>
    </Box>
  );
};

export default UserNav;
