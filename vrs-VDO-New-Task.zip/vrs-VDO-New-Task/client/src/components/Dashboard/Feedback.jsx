import { Stack, Typography } from "@mui/material";
import { astroarmsfoldedleaning, astrochill } from "../../imgs";

const Feedback = () => {
  return (
    <>
      <Stack
        direction="row-reverse"
        justifyContent="space-evenly"
        pt="1%"
        display="flex"
        sx={{
          "::-webkit-scrollbar-thumb": {
            background: "#ffb74d",
          },
          "::-webkit-scrollbar-thumb:hover": {
            background: "#00e5ff",
          },
          overflowY: "auto",
          borderRadius: 4,
          backgroundColor: "tertiary",
        }}
      >
        <Stack direction="row-reverse" justifyContent="center">
          <img src={astrochill} alt="astroreader" height={400} />
          <img src={astroarmsfoldedleaning} alt="astroreader" height={400} />
        </Stack>
        <Stack justifyContent="space-evenly">
          <Typography
            fontSize="28px"
            fontFamily="Fira Sans Extra Condensed"
            color="#d35d9c"
            align="center"
          >
            <br />
            FEEDBACK FORM <br />
          </Typography>
          <Typography
            fontSize="22px"
            fontFamily="Fira Sans Extra Condensed"
            color="#e9ead3"
            align="center"
            px={5}
          >
            <br /> INSTRUCTIONS
            <br /> <br />
          </Typography>
        </Stack>
      </Stack>
    </>
  );
};
export default Feedback;
