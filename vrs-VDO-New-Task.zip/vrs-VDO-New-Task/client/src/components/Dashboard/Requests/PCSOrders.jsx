import CheckBoxTemplate from "../../NewRequests/CheckBoxTemplate";
import { PCSOrdersImage } from "../../../imgs/RequestPageImages";

const PCSOrders = () => {
  return (
    <CheckBoxTemplate
      header1="I verify I have and will present my PCS Orders or proof of Logistical"
      header2="support letter (this applies to military/civilians/NATO members)."
      image={PCSOrdersImage}
      cardFooter="Resources for Logistical Support"
      continueLink="/PCSOrdersUpload"
      // TODO Page for back link missing
      backLink=""
      // TODO Resources for Logistical Support page missing
      footerLink=""
    />
  );
};

export default PCSOrders;
