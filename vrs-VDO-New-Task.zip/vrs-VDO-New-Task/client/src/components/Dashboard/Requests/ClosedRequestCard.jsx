import { useState } from "react";
import {
  Box,
  Card,
  Stack,
  CardMedia,
  CardContent,
  Typography,
  CardActionArea,
  Modal,
  Button,
} from "@mui/material";
import { cancel, closedrequestslarge } from "../../../imgs";
import EditRequest from "./EditRequestModal";

const ClosedRequestCard = ({ open, handleClose, handleOpen = false }) => {
  //dispatch and use selector will be needed in future for linking card content generation to stored user information

  // const dispatch = useDispatch();
  // const { selectedRequest } = useSelector((state) => state.user);
  const [closedOpen, setClosedOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);

  const cardData = [
    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Toyota Truck 1999 <br /> Service: NonOp Registration
          Renewal <br /> Outcome: Completed
        </Typography>
      ),
      image: closedrequestslarge,
      id: 1,
    },
    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Red Porsche
          <br />
          Service: Agent Owner <br />
          Outcome: Canceled.
        </Typography>
      ),
      image: closedrequestslarge,
      id: 2,
    },
    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Mercedes Benz CLS-550
          <br />
          Service: Shipping <br /> Outcome: Completed.
        </Typography>
      ),

      image: closedrequestslarge,
      id: 3,
    },
  ];

  return (
    <>
      {Boolean(handleOpen) || (
        <Fab onClick={handleOpen} color="secondary" size="small">
          <ModeEditRounded />
        </Fab>
      )}
      <EditRequest
        open={editOpen}
        handleClose={() => setEditOpen(false)}
        handleOpen={() => setEditOpen(true)}
        showFab={true}
        // selectedRequest={selectedRequest}
      />
      <Modal open={open} onClose={handleClose}>
        {/* <RequestsMiniCards /> */}
        <Stack>
          <Stack justifyContent="right">
            <Button
              // color="buttonsTertiary"
              onClick={handleClose}
              sx={{ maxWidth: "100px", mt: 20, ml: "70%" }}
            >
              <img src={cancel} alt="cancel" height={50} />
            </Button>
          </Stack>
          <Stack
            direction="row"
            justifyContent="center"
            alignContent="stretch"
            gap={1}
            mt={5}
            sx={{
              "::-webkit-scrollbar": {
                width: 0,
                height: 0,
              },
              overflowY: "auto",
              maxHeight: "80svh",
            }}
            spacing={1}
          >
            {" "}
            {cardData.map((request, index) => {
              const { image, content, id } = request;
              return (
                <Box px={1} key={index}>
                  <Card sx={{ border: "2px solid #666886", borderRadius: 4 }}>
                    <CardActionArea
                      onClick={() => {
                        setEditOpen(true);
                        //dispatch and use selector will be needed in future for linking card content generation to stored user information
                        // dispatch(updateSelectedRequest(request));
                      }}
                    >
                      <CardMedia align="center">
                        <Box
                          component="img"
                          src={image}
                          alt="open request"
                          height={250}
                        />
                      </CardMedia>
                      <CardContent
                        align="center"
                        sx={{ backgroundColor: "#291956" }}
                      >
                        <Typography variant="h5">Request #{id}</Typography>
                        {content}
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </Box>
              );
            })}
          </Stack>
        </Stack>
      </Modal>
    </>
  );
};
export default ClosedRequestCard;
