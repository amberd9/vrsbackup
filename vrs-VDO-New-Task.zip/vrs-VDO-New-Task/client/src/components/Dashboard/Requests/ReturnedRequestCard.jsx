import { useState } from "react";
import {
  Box,
  Card,
  Stack,
  CardMedia,
  CardContent,
  Typography,
  CardActionArea,
  Modal,
  Button,
} from "@mui/material";
import { cancel, returnedrequestslarge } from "../../../imgs";
import EditRequest from "./EditRequestModal";

const ReturnedRequestCard = ({ open, handleClose, handleOpen = false }) => {
  // TODO: USERSLICE AND REDUX DATA ADDING INFORMATION:
  // const dispatch = useDispatch();
  // const { selectedRequest } = useSelector((state) => state.user);
  const [editOpen, setEditOpen] = useState(false);

  const cardData = [
    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Toyota Truck 1999 <br /> Service: NonOp Registration
          Renewal <br /> Outcome: Rejected due to blurry picture. <br />
          reupload registration AEF-1901AA
        </Typography>
      ),
      image: returnedrequestslarge,
      id: 1,
    },
    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Red Porsche
          <br />
          Service: Agent Owner <br />
          Outcome: Rejected - You need an allotment waiver. <br />
          Please download waiver instructions located in Documents tab.
        </Typography>
      ),
      image: returnedrequestslarge,
      id: 2,
    },
    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Mercedes Benz CLS-550
          <br />
          Service: Shipping <br /> Outcome: Cannot ship with Temp plates - you
          must register as a NonOp first.
        </Typography>
      ),

      image: returnedrequestslarge,
      id: 3,
    },
  ];

  return (
    <>
      {Boolean(handleOpen) || (
        <Fab onClick={handleOpen} color="secondary" size="small">
          <ModeEditRounded />
        </Fab>
      )}
      <EditRequest
        open={editOpen}
        handleClose={() => setEditOpen(false)}
        handleOpen={() => setEditOpen(true)}
        showFab={true}
        // selectedRequest={selectedRequest}
      />
      <Modal open={open} onClose={handleClose}>
        <Stack>
          <Stack justifyContent="right">
            <Button
              // color="buttonsTertiary"
              onClick={handleClose}
              sx={{ maxWidth: "100px", mt: 20, ml: "77%" }}
            >
              <img
                src={cancel}
                alt="cancel"
                height={50}
                onClick={handleClose}
                sx={{ maxWidth: "100px", mt: 20, ml: "77%" }}
              />
            </Button>
          </Stack>
          <Stack
            direction="row"
            justifyContent="center"
            gap={1}
            mt={5}
            sx={{
              "::-webkit-scrollbar": {
                width: 0,
                height: 0,
              },
              overflowY: "auto",
              maxHeight: "80svh",
            }}
            spacing={1}
          >
            {cardData.map((request, index) => {
              const { image, content, id } = request;
              return (
                <Box px={1} key={index}>
                  <Card
                    sx={{
                      maxWidth: "550px",
                      border: "2px solid #666886",
                      borderRadius: 4,
                      maxHeight: "500px",
                    }}
                  >
                    <CardActionArea
                      onClick={() => {
                        setEditOpen(true);
                        // dispatch(updateSelectedRequest(request));
                      }}
                    >
                      <CardMedia align="center">
                        <Box
                          component="img"
                          src={image}
                          alt="open request"
                          height={250}
                        />
                      </CardMedia>
                      <CardContent
                        align="center"
                        sx={{ backgroundColor: "#291956" }}
                      >
                        <Typography variant="h5">Request #{id}</Typography>
                        {content}
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </Box>
              );
            })}
          </Stack>
        </Stack>
      </Modal>
    </>
  );
};
export default ReturnedRequestCard;
