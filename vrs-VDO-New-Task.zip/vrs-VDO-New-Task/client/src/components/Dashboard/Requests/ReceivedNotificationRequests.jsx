import { Box, Button, Card, Stack, Typography } from "@mui/material";
import { EmailRequests } from "../../../imgs/RequestPageImages";
import { useNavigate } from "react-router-dom";

export default function ReceivedNotificationRequests() {
  const navigate = useNavigate();
  return (
    <>
      <Stack padding={3} spacing={3}>
        <Stack alignItems="center">
          <Typography variant="h6" color="#F3DDF1">
            Did you receive your notification of arrival in the mail?
          </Typography>
        </Stack>
        <Stack alignItems="center">
          <Card
            sx={{
              borderRadius: 4,
              width: "80%",
              border: "2px solid #513E4F",
              backgroundColor: "rgba(53, 35, 56, 0.5)",
            }}
          >
            <Stack alignItems="center">
              <Box
                component="img"
                src={EmailRequests}
                alt="Email"
                flex
                maxWidth={400}
                sx={{ display: { xs: "none", sm: "none", md: "flex" } }}
              />
            </Stack>
            <Stack direction="row" justifyContent="space-around" padding={3}>
              <Button
                sx={{ minWidth: 100 }}
                onClick={() => navigate("/NoReceivedMail")}
              >
                NO
              </Button>
              <Button
                sx={{ minWidth: 100 }}
                onClick={() => navigate("/ReceivedMail")}
              >
                YES
              </Button>
            </Stack>
            <Stack alignItems="center" spacing={5} padding={2}>
              <Typography color="#E7DEFF">
                *Please Note: Sponsor MUST be present for ALL initial
                registrations OR spouse MUST have a POA.
              </Typography>
              <Typography color="#E7DEFF">
                *You will first need to register your POV BEFORE you try to pick
                up!
              </Typography>
              <Typography color="#FADBE2">
                Need an Agent Owner or POA? (Click Here)
              </Typography>
            </Stack>
          </Card>
        </Stack>
        <Stack alignItems="center">
          <Typography color="#D5F632" variant="h1">
            Resources (Click Here)
          </Typography>
        </Stack>
      </Stack>
    </>
  );
}
