import {
  Box,
  Button,
  Card,
  CardActions,
  CardMedia,
  Stack,
  Tooltip,
  Typography,
} from "@mui/material";
import { IALCar } from "../../../imgs/RequestPageImages";
import { LockedHouse } from "../../../imgs/RequestPageImages";

export default function WhichMethodUsed() {
  return (
    <Stack alignItems="center" padding={2} spacing={2}>
      <Typography variant="h4" color="#F3DDF1">
        Which method(s) did you use to ship your vehicle(s)?
      </Typography>
      <Card
        sx={{
          backgroundColor: "rgba(38, 20, 41, 0)",
          border: "2px",
          borderRadius: 4,
          width: "80%",
          padding: 3,
        }}
        align="center"
        variant="outlined"
      >
        <Card
          sx={{
            border: "2px solid #666886",
            borderRadius: 4,
            width: "80%",
            backgroundColor: "#352338",
          }}
          align="center"
        >
          <CardMedia sx={{ padding: 2 }}>
            <Stack
              direction="row"
              justifyContent="center"
              spacing={20}
              sx={{ width: "80%" }}
            >
              <Box component="img" src={IALCar} alt="IAL Car" maxHeight={150} />

              <Box
                component="img"
                src={LockedHouse}
                alt="Locked House"
                maxHeight={150}
                sx={{
                  backgroundColor: "white",
                  boxShadow: "0 0 8px 8px white ",
                }}
              />
            </Stack>
          </CardMedia>
          <CardActions sx={{ justifyContent: "space-evenly", padding: 3 }}>
            <Tooltip title="International Auto Logistics">
              <Button sx={{ border: "3px solid", minWidth: 100 }}>IAL</Button>
            </Tooltip>
            <Button sx={{ border: "3px solid", minWidth: 100 }}>Both</Button>
            <Button sx={{ border: "3px solid", minWidth: 100 }}>Private</Button>
          </CardActions>
        </Card>
        <Stack alignItems="end" padding={2} sx={{ width: "80%" }}>
          <Box>
            <Button sx={{ border: "3px solid" }}>CONTINUE</Button>
          </Box>
        </Stack>
      </Card>
      {/* TODO Link needs to be implemented for the "(Click Here)" */}
      <Typography color="#D5F632">Resources (Click Here)</Typography>
    </Stack>
  );
}
