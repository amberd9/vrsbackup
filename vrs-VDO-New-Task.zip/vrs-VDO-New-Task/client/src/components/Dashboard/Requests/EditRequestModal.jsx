import { useState } from "react";
import {
  Fab,
  Box,
  Divider,
  Paper,
  Stack,
  TextField,
  ToggleButtonGroup,
  ToggleButton,
  AppBar,
  Toolbar,
  Typography,
  Button,
  Modal,
  Tooltip,
  Chip,
  IconButton,
} from "@mui/material";
import {
  DirectionsCarRounded,
  ConstructionRounded,
  ElectricCarRounded,
  InfoOutlined,
  ModeEditRounded,
  GavelRounded,
  ArticleRounded,
  HomeRepairServiceRounded,
  ManageAccountsRounded,
  PersonAddAlt1Rounded,
} from "@mui/icons-material";
import { openrequestslarge } from "../../../imgs";
import dayjs from "dayjs";
import isSameOrAfter from "dayjs/plugin/isSameOrAfter";
import relativeTime from "dayjs/plugin/relativeTime";
import { btn_maps_hrs } from "../../Services/WalkthruCSS";
import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";

const EditRequestModal = ({
  open,
  handleClose,
  handleOpen = false,
  showFab = false,
}) => {
  // const { selectedRequest } = useSelector((state) => state.user);
  const [pov, setPov] = useState("car");
  const [regType, setRegType] = useState("reg");
  const [iDate, setiDate] = useState(dayjs().add(1, "year"));
  dayjs.extend(isSameOrAfter);
  dayjs.extend(relativeTime);
  const navigate = useNavigate();

  return (
    <>
      {(showFab && Boolean(handleOpen)) || (
        <Fab onClick={handleOpen} color="secondary" size="small">
          <ModeEditRounded />
        </Fab>
      )}

      <Modal open={open} onClose={handleClose}>
        <Box
          sx={{
            width: 1000,
            maxWidth: "90vw",
            mx: "auto",
            mt: 4,
            backgroundColor: "#1A1429",
            borderRadius: "12px 12px 0px 0px",
          }}
        >
          {/* {JSON.stringify(selectedRequest)} */}
          <AppBar position="sticky">
            <Toolbar className="mainHeaderBar" sx={{ flexGrow: 1 }}>
              <Typography
                variant="h4"
                color="##B0F2B4"
                fontFamily="Fira Sans Extra Condensed"
              >
                REQUEST SUMMARY
              </Typography>
            </Toolbar>
          </AppBar>
          <Divider sx={{ border: "2px solid #9078d5" }} />
          <Stack
            sx={{
              p: 2,
              border: "3px solid #9078D5",
              borderTopWidth: 0,
              borderRadius: "0px 0px 12px 12px",
              "::-webkit-scrollbar": {
                width: 0,
                height: 0,
              },
              overflowY: "auto",
              overflowX: "auto",
              maxHeight: "80svh",
            }}
            spacing={1}
          >
            <Stack
              component={Paper}
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              sx={{
                backgroundColor: "#31225B",

                fontFamily: "Fira Sans Extra Condensed",
                border: "3px #CBBEFF solid",
                borderRadius: 4,
                px: 2,
              }}
            >
              <Typography variant="h4" fontFamily="Fira Sans Extra Condensed">
                YOUR REQUEST INFORMATION
              </Typography>
              <img
                src={openrequestslarge}
                alt="openrequest Astronaut"
                height={110}
              />
            </Stack>
            <Stack justifyContent="space-between">
              <Typography
                variant="h5"
                sx={{
                  fontFamily: "Fira Sans Extra Condensed",
                  fontWeight: "light",
                  color: "text.tertiary",
                }}
              >
                Request Details:
              </Typography>
              <Stack direction="row" gap={3}>
                <TextField
                  size="small"
                  variant="outlined"
                  label="Request ID"
                  color="tertiary"
                />
                <TextField
                  size="small"
                  variant="outlined"
                  label="Vehicle"
                  color="tertiary"
                />
                <TextField
                  size="small"
                  variant="outlined"
                  label="Service"
                  color="tertiary"
                />
                <TextField
                  size="small"
                  variant="outlined"
                  label="Status"
                  color="tertiary"
                />
              </Stack>
              <Stack gap={1}>
                <Typography
                  variant="h5"
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "light",
                    color: "text.tertiary",
                  }}
                >
                  Type:
                </Typography>
                <Stack direction="row" spacing={4}>
                  <ToggleButtonGroup size="small" variant="filled" value={pov}>
                    <ToggleButton
                      value="docs"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <ArticleRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Documents
                    </ToggleButton>
                    <ToggleButton
                      value="moto"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <HomeRepairServiceRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Service
                    </ToggleButton>
                    <ToggleButton
                      value="rec"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <ManageAccountsRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Vehicle
                    </ToggleButton>
                    <ToggleButton
                      value="rec"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <GavelRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Agent Owner
                    </ToggleButton>
                  </ToggleButtonGroup>
                  <Tooltip
                    title={
                      <>
                        <Typography>
                          Recreational includes RV, Camper, Quad, etc.
                        </Typography>
                        <Typography>
                          Agent Owner: If you are acting as an Agent Owner for
                          someone elses' vehicle.
                        </Typography>
                      </>
                    }
                  >
                    <IconButton>
                      <InfoOutlined />
                    </IconButton>
                  </Tooltip>
                </Stack>
              </Stack>
              <Stack gap={2} justifyContent="center">
                <Stack gap={2} mt={2}>
                  <Button
                    variant="contained"
                    sx={{
                      fontFamily: "Fira Sans Extra Condensed",
                      fontWeight: "light",
                      color: "text.tertiary",
                      mx: 40,
                    }}
                  >
                    Request Service Change
                  </Button>
                  <Button
                    variant="contained"
                    sx={{
                      fontFamily: "Fira Sans Extra Condensed",
                      fontWeight: "light",
                      color: "text.tertiary",
                      mx: 40,
                    }}
                  >
                    Edit Documents
                  </Button>
                  <Button
                    sx={{
                      ...btn_maps_hrs,
                      fontSize: 20,
                      mx: "32%",
                      borderRadius: 4,
                      width: 350,
                    }}
                    startIcon={<PersonAddAlt1Rounded />}
                    onClick={() =>
                      navigate("/UserDashboard/scheduleappointment")
                    }

                    // TODO: FIXME: {approved ? setDisabled(false) : setDisabled(true)}
                  >
                    Make A New Appointment
                  </Button>
                </Stack>
                <TextField
                  inputProps={{ readOnly: true }}
                  size="small"
                  value={"List of Uploaded Documents"}
                />
              </Stack>
              <Stack mt={2} mx={40}>
                <Chip
                  variant="outlined"
                  color="secondary"
                  sx={{ fontSize: 20 }}
                  label={dayjs(iDate).toNow(true)}
                />
              </Stack>
              <Stack gap={1}>
                <Typography
                  variant="h5"
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "light",
                    color: "text.tertiary",
                  }}
                >
                  Registration Type:
                </Typography>

                <ToggleButtonGroup
                  size="small"
                  variant="filled-nodal"
                  value={regType}
                >
                  <ToggleButton
                    value="reg"
                    onClick={(event, newValue) => {
                      setRegType(newValue);
                    }}
                  >
                    <DirectionsCarRounded
                      sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                    />
                    Permanent Plates
                  </ToggleButton>
                  <ToggleButton
                    value="nonOp"
                    onClick={(event, newValue) => {
                      setRegType(newValue);
                    }}
                  >
                    <ConstructionRounded
                      sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                    />
                    NonOperational
                  </ToggleButton>
                  <ToggleButton
                    value="Temp Plates"
                    onClick={(event, newValue) => {
                      setRegType(newValue);
                    }}
                  >
                    <ElectricCarRounded
                      sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                    />
                    Temp Plates
                  </ToggleButton>
                </ToggleButtonGroup>
              </Stack>
              <Stack direction="row" gap={5} justifyContent="right">
                <Button size="small" color="buttonsTertiary">
                  
                </Button>
                <Button size="small" onClick={handleClose}>
                  CANCEL
                </Button>
              </Stack>
            </Stack>
          </Stack>
        </Box>
      </Modal>
    </>
  );
};

export default EditRequestModal;
