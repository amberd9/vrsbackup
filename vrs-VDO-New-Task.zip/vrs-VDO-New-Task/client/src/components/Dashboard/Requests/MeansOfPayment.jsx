import CheckBoxTemplate from "../../NewRequests/CheckBoxTemplate";
import { MoneyImage } from "../../../imgs/RequestPageImages";
const MeansOfPayment = () => {
  return (
    <CheckBoxTemplate
      header1="I verify I have and will bring with me a means of payment:"
      header2="Credit Card, Debit Card, Money Order, OR Check."
      cardFooter="Pricing Table"
      footerLink=""
      image={MoneyImage}
    />
  );
};

export default MeansOfPayment;
