import React from "react";
import {
  Box,
  Card,
  CardActionArea,
  CardMedia,
  Modal,
  Stack,
  Typography,
} from "@mui/material";
import {
  BothMethodsCar,
  DroveCar,
  ShippedCar,
} from "../../../imgs/RequestPageImages";
import { Outlet, useNavigate } from "react-router-dom";
import MainHeaderServices from "../../MainHeaderServices";
import ServicesNav from "../ServicesNav";
import {
  typ_fira_title,
  typ_fira_xLarge_thin,
  typ_roboto_lightitalic,
  typ_roboto_regular,
  typ_roboto_sub,
} from "../../Services/WalkthruCSS";
import RequestNav from "../../RequestPage/RequestNav";
import { useState } from "react";
import { Outbound } from "@mui/icons-material";

// TODO: MAKE IT SO IF A MOTORCYCLE TYPE IS CHOSEN AT ALL THEN USERS ARE NAVIGATED TO MSF UPLOAD/VERIFY PAGE  NON-MOTORCYCLE SELECTIONS ROUTE TO SERVICES START DIRECTLY  USE CONDITIONAL TO DETERMINE WHICH MODAL TO USE - MULTIPLE VS SINGLE VEHICLES

const NewArrivalInitial = () => {
  //   const [modalOpen, setModalOpen] = useState(false);
  // const [arrival, setArrival] = useState(true);
  // const handleClose = () => navigate(setArrival(false));

  const navigate = useNavigate();
  // THIS IS FOR THE SERVICES PATH AFTER MULTIPLE VEHICLES QUESTION HAS BEEN ASKED AND ANSWERED
  return (
    // <>
    <Stack
      alignItems="center"
      padding={5}
      justifyContent="space-evenly"
      sx={{
        border: "7px solid #904082",
        borderRadius: 4,
        padding: 4,
        display: { xs: "none", sm: "none", md: "flex" },
      }}
      align="center"
      flexWrap="flex"
    >
      <Typography sx={{ ...typ_fira_xLarge_thin }} color="#F3DDF1">
        HOW DID YOU TRANSPORT YOUR VEHICLE?
      </Typography>{" "}
      <Box height="150px" />
      <Stack direction="row">
        <Stack
          sx={{
            border: "2px solid #666886",
            borderRadius: 4,

            backgroundColor: "#352338",
            padding: 2,
            display: { xs: "none", sm: "none", md: "flex" },
            ":hover": {
              color: "#D5F632",
              background: " #66688620",
              Image: " #66688620",
            },
          }}
          onClick={() => navigate("/Service/Arrival/Shipped")}
        >
          <img src={ShippedCar} alt="Shipped Car" height="200px" />
          <Typography sx={typ_roboto_sub}>
            I shipped my vehicle(s) INTO Germany
          </Typography>
        </Stack>
        <Box width="150px" />
        <Stack
          alignItems="center"
          sx={{
            border: "2px solid #666886",
            borderRadius: 4,
            backgroundColor: "#352338",
            padding: 2,
            display: { xs: "none", sm: "none", md: "flex" },
            ":hover": {
              color: "#D5F632",
              background: " #66688620",
              Image: " #66688620",
            },
          }}
          onClick={() => navigate("/Service/Arrival/Drove")}
          align="center"
        >
          <Box
            component="img"
            src={DroveCar}
            alt="Drove Car"
            flex
            maxWidth={400}
            sx={{
              display: { xs: "none", sm: "none", md: "flex" },
            }}
          />
          <Typography sx={typ_roboto_sub}>
            I DROVE to Germany from my previous location.
          </Typography>
        </Stack>
        <Box width="150px" />
        <Stack
          alignItems="center"
          sx={{
            border: "2px solid #666886",
            borderRadius: 4,
            backgroundColor: "#352338",
            padding: 2,
            ":hover": {
              color: "#D5F632",
              background: " #66688620",
              Image: " #66688620",
            },
          }}
          onClick={() => navigate("/Service/Arrival/Shipped")}
          align="center"
        >
          <img
            src={BothMethodsCar}
            alt="Both Methods"
            height="150px"
            sx={{
              display: { xs: "none", sm: "none", md: "flex" },
            }}
          />
          <Typography sx={typ_roboto_sub}>I used both methods.</Typography>
        </Stack>
      </Stack>{" "}
      <Box height="150px" />
      <Typography
        color="#D5F632"
        sx={typ_roboto_sub}
        onClick={() => navigate("/UserDashboard/Resources")}
      >
        Resources
      </Typography>
    </Stack>
  );
};
export default NewArrivalInitial;
