import { useState } from "react";
import { Box, Typography, Button, Modal } from "@mui/material";
import { OpenRequestAstronaut } from "../../../imgs/RequestPageImages";

const OpenRequestsModal = () => {
  const [openModal, setOpenModal] = useState(null);
  const handleCloseModal = () => {
    setOpenModal(null);
  };
  return (
    <>
      <Modal
        display="flex"
        flexDirection="column"
        alignItems="center"
        sx={{
          borderRadius: 2,
          border: "2px solid lightblue",
          padding: 3,
        }}
      >
        <h1 sx={{ backgroundColor: "#1A1623" }}>Open Requests</h1>
        <Box
          sx={{
            borderRadius: 2,
            border: "2px solid lightblue",
            padding: 3,
          }}
        >
          <Typography>Request opened:[Pass in Date]</Typography>
          <Typography>Service [Registration Renewal]</Typography>
          <Typography>Outcome:[#Pass in variable for outcome]</Typography>
        </Box>
        <Button sx={{ mt: 2 }} onClick={handleCloseModal}>
          Close
        </Button>
      </Modal>
    </>
  );
};

export default OpenRequestsModal;
