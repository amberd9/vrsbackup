import { useState } from "react";
import {
  Box,
  Card,
  Stack,
  CardMedia,
  Typography,
  CardContent,
  CardActionArea,
} from "@mui/material";
import {
  closedrequestsmini,
  openrequestsmini,
  returnedrequestsmini,
} from "../../../imgs";
import ReturnedRequestCard from "./ReturnedRequestCard";
import ClosedRequestCard from "./ClosedRequestCard";

const RequestsMiniCards = () => {
  const [returnedOpen, setReturnedOpen] = useState(false);
  const [closedOpen, setClosedOpen] = useState(false);

  return (
    <>
      <ReturnedRequestCard
        open={returnedOpen}
        handleClose={() => setReturnedOpen(false)}
        handleOpen={() => setReturnedOpen(true)}
        showFab={true}
        // selectedRequest={selectedRequest}
      />
      <ClosedRequestCard
        open={closedOpen}
        handleClose={() => setClosedOpen(false)}
        handleOpen={() => setClosedOpen(true)}
        showFab={true}
        // selectedRequest={selectedRequest}
      />
      <Stack
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          overflowY: "auto",
          maxHeight: "90svh",
          border: "2px solid #b693c4",
          borderRadius: 4,
          mb: 3,
          alignItems: "center",

          p: 1,
        }}
      >
        <Stack direction="row" spacing={0.5}>
          <Box px={1}>
            <Card
              id="R1"
              sx={{
                border: "2px solid #ffb74d",
                borderRadius: 4,
                maxHeight: "200px",
                minWidth: "160px",
              }}
            >
              <CardActionArea
                onClick={() => {
                  setOpenRequest(true);
                  // dispatch(updateSelectedRequest(request));
                }}
              >
                <CardMedia align="center">
                  <Box
                    component="img"
                    src={openrequestsmini}
                    sx={{ height: "140px" }}
                  />
                </CardMedia>
                <CardContent
                  align="middle"
                  sx={{ backgroundColor: "#342570", p: 1 }}
                >
                  <Typography> OPEN REQUESTS 3 </Typography>
                  {/* will need to use api to pull in open/closed/returned requests count </CardContent>{count}</Typography> */}
                </CardContent>
              </CardActionArea>
            </Card>
          </Box>
          <Box px={1}>
            <Card
              id="R2"
              sx={{
                border: "3px solid #666886",
                borderRadius: 4,
                maxHeight: "200px",
                minWidth: "160px",
              }}
            >
              <CardActionArea
                onClick={() => {
                  setReturnedOpen(true);
                  // dispatch(updateSelectedRequest(request));
                }}
              >
                <CardMedia align="center">
                  <Box
                    component="img"
                    src={returnedrequestsmini}
                    sx={{ height: "140px" }}
                  />
                </CardMedia>
                <CardContent
                  align="middle"
                  sx={{ backgroundColor: "#342570", p: 1 }}
                >
                  <Typography> RETURNED REQUESTS 3 </Typography>
                  {/* will need to use api to pull in open/closed/returned requests count </CardContent>{count}</Typography> */}
                </CardContent>
              </CardActionArea>
            </Card>
          </Box>
          <Box px={1}>
            <Card
              id="R3"
              sx={{
                border: "2px solid #666886",
                borderRadius: 4,
                maxHeight: "200px",
                minWidth: "160px",
              }}
            >
              <CardActionArea
                onClick={() => {
                  setClosedOpen(true);
                  // dispatch(updateSelectedRequest(request));
                }}
              >
                <CardMedia align="center">
                  <Box
                    component="img"
                    src={closedrequestsmini}
                    sx={{ height: "140px" }}
                  />
                </CardMedia>
                <CardContent
                  align="middle"
                  sx={{ backgroundColor: "#342570", p: 1 }}
                >
                  <Typography> CLOSED REQUESTS 3 </Typography>
                  {/* will need to use api to pull in open/closed/returned requests count </CardContent>{count}</Typography> */}
                </CardContent>
              </CardActionArea>
            </Card>
          </Box>
        </Stack>
      </Stack>
    </>
  );
};

export default RequestsMiniCards;
