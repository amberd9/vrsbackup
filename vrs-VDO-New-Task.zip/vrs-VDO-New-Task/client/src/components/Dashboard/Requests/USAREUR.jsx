import CheckBoxTemplate from "../../NewRequests/CheckBoxTemplate";
import { USAREURImage } from "../../../imgs/RequestPageImages";

const USAREUR = () => {
  return (
    <CheckBoxTemplate
      header1="You will need the following documents to help us"
      header2="service you for this request."
      image={USAREURImage}
      cardHeader="I verify I have and will present a valid USAREUR-AF License."
      cardFooter="Resources"
      backLink="/DoDID"
      continueLink="/USAREURUpload"
      footerLink=""
    />
  );
};

export default USAREUR;
