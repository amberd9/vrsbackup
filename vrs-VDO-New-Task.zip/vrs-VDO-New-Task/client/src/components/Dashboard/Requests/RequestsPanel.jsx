import { useNavigate } from "react-router-dom";
import { Stack, Button, Box } from "@mui/material";
import { UserDashboardThemeProvider } from "../../../Themes";
import RequestsMiniCards from "./RequestsMiniCards";
import VRSRequestsSplash from "../../../views/VRSRequestsSplash";
import OpenedRequestCard from "./OpenedRequestCard";
import { useState } from "react";

const RequestsPanel = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  return (
    <>
      <Stack display="flex" direction="row" pt="1%" justifyContent="center">
        <Box alignItems="flex-start">
          <Stack gap={3} justifyContent="space-evenly" align-self="flex-start">
            <VRSRequestsSplash />
            <Button
              size="small"
              sx={{ mx: 2, maxWidth: "170px" }}
              onClick={() => navigate("/NewRequests")}
            >
              NEW REQUEST
            </Button>
          </Stack>
        </Box>{" "}
        <UserDashboardThemeProvider>
          <RequestsMiniCards onClick={() => setOpen(true)} color="secondary" />
        </UserDashboardThemeProvider>
      </Stack>
      <Stack direction="row" justifyContent="space-around">
        <UserDashboardThemeProvider>
          <OpenedRequestCard />
        </UserDashboardThemeProvider>
      </Stack>
    </>
  );
};

export default RequestsPanel;
