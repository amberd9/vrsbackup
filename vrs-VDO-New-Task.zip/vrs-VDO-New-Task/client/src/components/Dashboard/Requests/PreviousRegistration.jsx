import CheckBoxTemplate from "../../NewRequests/CheckBoxTemplate";
import { PreviousRegistrationImage } from "../../../imgs/RequestPageImages";

const PreviousRegistration = () => {
  return (
    <CheckBoxTemplate
      header1="I verify I have and will present my"
      header2="current/previous registration OR my previous ORGINAL Title."
      cardFooter="Resources"
      cardFooterNote="Please Note: It is okay if your registration is expired from your previous location."
      link="/UserDashboard"
      image={PreviousRegistrationImage}
      footerLink=""
   
    />
  );
};

export default PreviousRegistration;
