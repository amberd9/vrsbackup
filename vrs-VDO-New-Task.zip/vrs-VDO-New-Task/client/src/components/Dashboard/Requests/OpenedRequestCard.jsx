import { useState } from "react";
import {
  Box,
  Card,
  Stack,
  CardMedia,
  Typography,
  CardActionArea,
  CardContent,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { openrequestslarge } from "../../../imgs";
import EditRequest from "./EditRequestModal";
import { updateSelectedRequest } from "../../../utils/usersSlice";

const OpenedRequestCard = () => {
  // const dispatch = useDispatch();
  // const { selectedRequest } = useSelector((state) => state.user);
  const [editOpen, setEditOpen] = useState(false);

  const cardData = [
    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Toyota Truck 1999 <br /> Service: NonOp Registration
          Renewal <br /> Outcome: Approved. Please make appointment.
        </Typography>
      ),
      image: openrequestslarge,
      id: 1,
    },

    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Red Porsche
          <br />
          Service: Agent Owner <br /> Outcome: In review.
        </Typography>
      ),
      image: openrequestslarge,
      id: 2,
    },
    {
      content: (
        <Typography>
          Date Opened: 04/04/24 <br />
          Summary: Vehicle: Mercedes Benz CLS-550
          <br />
          Service: Shipping <br /> Outcome: In review.
        </Typography>
      ),

      image: openrequestslarge,
      id: 3,
    },
  ];
  return (
    <>
      <EditRequest
        open={editOpen}
        handleClose={() => setEditOpen(false)}
        handleOpen={() => setEditOpen(true)}
        showFab={true}
        // selectedRequest={selectedRequest}
      />
      <Stack
        direction="row"
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          overflowY: "auto",
          maxHeight: "80svh",
        }}
        spacing={1}
      >
        {cardData.map((request, index) => {
          const { image, content, id } = request;
          return (
            <Box px={1} key={index}>
              <Card sx={{ border: "2px solid #666886", borderRadius: 4 }}>
                <CardActionArea
                  onClick={() => {
                    setEditOpen(true);
                    // dispatch(updateSelectedRequest(request));
                  }}
                >
                  <CardMedia align="center">
                    <Box
                      component="img"
                      src={image}
                      alt="open request"
                      height={250}
                      minWidth={350}
                    />
                  </CardMedia>
                  <CardContent
                    align="center"
                    sx={{ backgroundColor: "#1D0061" }}
                  >
                    <Typography variant="h5">Request #{id}</Typography>
                    {content}
                  </CardContent>
                </CardActionArea>
              </Card>
            </Box>
          );
        })}
      </Stack>
    </>
  );
};

export default OpenedRequestCard;
