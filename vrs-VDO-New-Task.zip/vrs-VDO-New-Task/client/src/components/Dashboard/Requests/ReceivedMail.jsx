import { Stack, Box, Typography, Card, Button } from "@mui/material";
import { ReceivedMailAstronaut } from "../../../imgs/RequestPageImages";
import { Navigate } from "react-router-dom";

export default function ReceivedMail() {
  return (
    <Stack alignItems="center" padding={2} spacing={3}>
      <Typography variant="h4" padding={2} color="#F3DDF1">
        Great! Let’s make sure that all of your documents are ready for the day
        of your appointment.
      </Typography>
      <Card
        sx={{
          borderRadius: 4,
          width: "80%",
          border: "4px solid #904082",
          backgroundColor: "rgba(38, 20, 41, 0.0)",
        }}
        align="center"
      >
        <Stack alignItems="center" justifyContent="center">
          <Box
            padding={2}
            component="img"
            src={ReceivedMailAstronaut}
            alt="Astronaut Cargo"
            minHeight={120}
            sx={{ display: { xs: "none", sm: "none", md: "flex" } }}
          />
        </Stack>
        <Stack alignItems="center" padding={2}>
          <Box>
            <Button
              color="error"
              onClick={() => navigate("/Service/Arrival/HHG")}
            >
              CONTINUE
            </Button>
          </Box>
        </Stack>
      </Card>
      {/* TODO Link needs to be implemented where "(Click Here)" is */}
      <Typography variant="h6" color="#D5F632">
        Resources (Click Here)
      </Typography>
    </Stack>
  );
}
