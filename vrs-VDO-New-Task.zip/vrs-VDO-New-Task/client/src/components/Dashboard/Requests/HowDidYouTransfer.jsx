import {
  Box,
  Card,
  CardActionArea,
  CardMedia,
  Modal,
  Stack,
  Typography,
} from "@mui/material";
import {
  BothMethodsCar,
  DroveCar,
  ShippedCar,
} from "../../../imgs/RequestPageImages";
import { Outlet, useNavigate } from "react-router-dom";
import MainHeaderServices from "../../MainHeaderServices";
import ServicesNav from "../ServicesNav";
import {
  typ_fira_title,
  typ_fira_xLarge_thin,
  typ_roboto_regular,
} from "../../Services/WalkthruCSS";
import RequestNav from "../../RequestPage/RequestNav";
import { useState } from "react";
import { Outbound } from "@mui/icons-material";

const HowDidYouTransfer = () => {
  const navigate = useNavigate();
  // const [arrival, setArrival] = useState(true);
  // const handleClose = () => navigate(setArrival(false));
  // TODO The cards need to navigate to their respective sections

  return (
    <>
      <Box className="services_bg services_bgtransp">
        <MainHeaderServices />
        <ServicesNav className="services_bg services_bgtransp" />{" "}
        <Box height="2%" />
        <Stack direction="row">
          <RequestNav /> <Box width="5%" />
          <Outlet />
        </Stack>
      </Box>
    </>
  );
};
export default HowDidYouTransfer;
