import CheckBoxTemplate from "../../NewRequests/CheckBoxTemplate";
import { DoDIDImage } from "../../../imgs/RequestPageImages";

const DoDID = () => {
  return (
    <CheckBoxTemplate
      header1="You will need the following documents to help us"
      header2="service you for this request."
      cardHeader="I verify I have and will present a valid DoD ID Card at my appointment."
      cardFooter="Resources"
      footerLink=""
      backLink="/UserDashboard"
      continueLink="/USAREUR"
      image={DoDIDImage}
    />
  );
};

export default DoDID;
