import UploadRequestTemplate from "../../NewRequests/UploadRequestTemplate";

const USAREURUpload = () => {
  return (
    <UploadRequestTemplate
      header1="Please upload your valid USAREUR-AF License here."
      footer1="Please Note: You are REQUIRED to bring ALL required documents to your appointment or services will not be rendered! Uploading documents"
      footer2="on this website does not substitute your physical presentation of any required document at your appointment time. "
      backLink="/USAREUR"
      // TODO Link not available due to missing page
      continueLink=""
    />
  );
};

export default USAREURUpload;
