import { Box, Button, Card, CardMedia, Stack, Typography } from "@mui/material";
import { SeeYouSoon } from "../../../imgs/RequestPageImages";
import { useNavigate } from "react-router-dom";

export default function NoReceivedMail() {
  const navagate = useNavigate();
  return (
    <Stack alignItems="center" padding={2}>
      <Typography variant="h4" padding={2} color="#E1E6FA">
        You CANNOT register your POV until you've been notified it is ready
      </Typography>
      <Card
        sx={{
          borderRadius: 4,
          width: "80%",
          border: "2px solid #513E4F",
          backgroundColor: "rgba(53, 35, 56, 0.5)",
        }}
        align="center"
      >
        <CardMedia>
          <Box
            component="img"
            src={SeeYouSoon}
            alt="See You Soon"
            minHeight={120}
            sx={{ display: { xs: "none", sm: "none", md: "flex" } }}
          />
        </CardMedia>
        <Typography variant="h5" color="#E7DEFF">
          *Please Note: Sponsor MUST be present for ALL initial registrations OR
          spouse MUST have a POA.
        </Typography>
        <Typography variant="h6" color="#E7DEFF">
          *You will first need to register your POV BEFORE you try to pick up!
        </Typography>
        {/* TODO The Click Here needs a link */}
        <Typography padding={2} color="#FDBFCD">
          Need an Agent Owner or POA? (Click Here)
        </Typography>
        {/* TODO The Click Here needs a link */}
        <Typography color="#FDBFCD">
          Resources for POV shipment and notifications. (Click Here)
        </Typography>
        <Stack alignItems="end">
          <Box padding={2}>
            <Button
              color="error"
              sx={{ border: "2px solid #E7DEFF" }}
              onClick={() => navagate("/UserDashboard/requests")}
            >
              Return
            </Button>
          </Box>
        </Stack>
      </Card>
      {/* TODO The Click Here needs a link */}
      <Typography padding={2} color="#D5F632">
        Resources (Click Here)
      </Typography>
    </Stack>
  );
}
