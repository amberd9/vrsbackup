import UploadRequestTemplate from "../../NewRequests/UploadRequestTemplate";

const PCSOrdersUpload = () => {
  return (
    <UploadRequestTemplate
      header1="Please upload your PCS orders or Proof of Logistical Support here."
      footer1="Please Note: You are REQUIRED to bring ALL required documents to your appointment or services will not be rendered! Uploading documents on"
      footer2="this website does not substitute your physical presentation of any required document at your appointment time."
      backLink="/PCSOrders"
      // TODO Page has not been made yet for the shipping documents
      continueLink=""
    />
  );
};

export default PCSOrdersUpload;
