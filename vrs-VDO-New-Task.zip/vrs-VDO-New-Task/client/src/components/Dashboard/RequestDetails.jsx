import Card from "@mui/material/Card";
import Stack from "@mui/material/Stack";
import Fab from "@mui/material/Fab";
import AutoFixNormalTwoToneIcon from "@mui/icons-material/AutoFixNormalTwoTone";
import Typography from "@mui/material/Typography";
import { Navigate } from "react-router-dom";
import EditRequestModal from "./Requests/EditRequestModal";
import { useState } from "react";

const RequestDetails = () => {
  const [editOpen, setEditOpen] = useState(false);
  return (
    <>
      <EditRequestModal
        open={editOpen}
        handleClose={() => setEditOpen(false)}
        handleOpen={() => setEditOpen(true)}
        showFab={true}
        // selectedRequest={selectedRequest}
      />
      <Card sx={styles.requestDetailsCard}>
        <Typography color="#fff" p=".5rem" variant="h5">
          Request Details
        </Typography>
        <Stack p="1rem">
          <Typography sx={styles.requestDetailsText}>Request ID</Typography>
          <Typography variant="h5" mb={1}>
            POV Year/Make/Model/VIN
          </Typography>
          <Typography variant="h5" mb={1}>
            Service Type/Info
          </Typography>
          <Typography variant="h5" mb={1}>
            Considerations [i.e. Buyer Name]
          </Typography>
          <Fab
            color="secondary"
            variant="extended"
            sx={styles.requestDetailsCorrectionsButton}
            size="medium"
            onClick={() => setEditOpen(true)}
          >
            <AutoFixNormalTwoToneIcon size="small" /> Make Corrections
          </Fab>
        </Stack>
      </Card>
    </>
  );
};

const styles = {
  requestDetailsCard: {
    border: "2px solid #666886",
    borderRadius: 4,
    minWidth: "500px",
    m: ".5rem",
    textAlign: "center",
  },
  requestDetailsText: {
    border: "1px solid #666886",
    borderRadius: 4,
    width: "fit-content",
    padding: ".5rem",
  },
  requestDetailsCorrectionsButton: {
    width: "fit-content",
    justifyContent: "left",
    fontSize: ".5rem",
    p: ".5rem",
    m: ".5rem",
  },
};

export default RequestDetails;
