import { useEffect } from "react";
import FixedList from "../FixedList";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";

const ScheduleAppointmentLocation = ({ checkedIndex, setCheckedIndex }) => {
  const bases = [
    "Fort Hood",
    "Fort Bragg",
    "Fort Benning",
    "Fort Bliss",
    "Fort Campbell",
    "Fort Carson",
    "Fort Drum",
    "Fort Hood",
    "Fort Irwin",
    "Fort Jackson",
  ];

  const addresses = [
    "123 Main St",
    "456 Elm St",
    "789 Oak St",
    "1011 Pine St",
    "1213 Maple St",
    "1415 Cedar St",
    "1617 Birch St",
    "1819 Walnut St",
    "2021 Chestnut St",
    "2223 Spruce St",
  ];

  useEffect(() => {
    setCheckedIndex(null);
  }, []);

  return (
    <>
      <FixedList
        HeaderText={"Select Location"}
        FirstLineData={bases}
        SecondLineData={addresses}
        checkedIndex={checkedIndex}
        setCheckedIndex={setCheckedIndex}
      />
      <Stack
        sx={{
          border: "2px solid #666886",
          borderRadius: 4,
          minHeight: 150,
          justifyContent: "center",
          textAlign: "center",
        }}
      >
        <Typography variant="h6">Services Information</Typography>
        <Stack direction="row" justifyContent="space-evenly" p="1rem">
          <Button size="small" sx={{ mx: 1 }}>
            MAPS
          </Button>
          <Button size="small" sx={{ mx: 1 }}>
            HOURS
          </Button>
        </Stack>
      </Stack>
    </>
  );
};

export default ScheduleAppointmentLocation;
