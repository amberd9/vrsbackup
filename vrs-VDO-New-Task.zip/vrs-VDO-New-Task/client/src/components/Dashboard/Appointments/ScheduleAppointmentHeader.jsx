import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";

const ScheduleAppointmentHeader = ({ step, setStep }) => {
  const steps = ["Confirm Details", "Select Location", "Select Date & Time"];

  return (
    <>
      <Stack sx={{ m: "1rem" }}>
        <Stepper activeStep={step} alternativeLabel>
          {steps.map((label) => {
            return (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            );
          })}
        </Stepper>
      </Stack>
      <Stack textAlign="center">
        <Typography variant="h5">
          {step === 0 &&
            "Select an approved Request ID from the provided list below or start a new request."}
          {step === 1 &&
            "Select the location where you’d like your appointment to be."}
          {step === 2 && "Select the date and time for your appointment."}
        </Typography>
        <Typography
          color="#d3d3d350"
          variant="body1"
          sx={{ fontStyle: "italic" }}
        >
          {step === 0 &&
            "Verify that the associated request details still look correct before continuing."}
          {step === 1 &&
            "Use VRS maps & hours to help you decide. Only locations that manage your selected service can be chosen.."}
          {step === 2 &&
            "VRS reserves the right to make changes to scheduled appointments as staffing and service hours allow. Please be mindful of any notifications."}
        </Typography>
      </Stack>
    </>
  );
};

export default ScheduleAppointmentHeader;
