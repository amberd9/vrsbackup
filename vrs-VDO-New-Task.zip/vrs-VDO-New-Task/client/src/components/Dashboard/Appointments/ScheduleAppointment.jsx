import Card from "@mui/material/Card";
import Divider from "@mui/material/Divider";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import RequestDetails from "../RequestDetails";
import ScheduleAppointmentHeader from "./ScheduleAppointmentHeader";
import ScheduleAppointmentRequestID from "./ScheduleAppointmentRequestID";
import ScheduleAppointmentLocation from "./ScheduleAppointmentLocation";
import ScheduleAppointmentDate from "./ScheduleAppointmentDate";
import { useNavigate } from "react-router";
import { useState, useEffect } from "react";

const ScheduleAppointment = () => {
  const navigate = useNavigate();
  const [checkedIndex, setCheckedIndex] = useState(null);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (step === 4) {
      setStep(0);
      setCheckedIndex(null);
      navigate("userdashboard");
    }
  }, [step]);

  return (
    <Card direction="column" justifyContent="space-around" sx={styles.card}>
      <ScheduleAppointmentHeader step={step} setStep={setStep} />
      <Stack direction="row" justifyContent="space-around" flexWrap="wrap">
        <Stack>
          <RequestDetails />
        </Stack>
        <Divider orientation="vertical" flexItem sx={styles.divider} />
        <Stack sx={styles.rightPane}>
          {step === 0 && (
            <ScheduleAppointmentRequestID
              checkedIndex={checkedIndex}
              setCheckedIndex={setCheckedIndex}
              styles={styles}
            />
          )}
          {step === 1 && (
            <ScheduleAppointmentLocation
              checkedIndex={checkedIndex}
              setCheckedIndex={setCheckedIndex}
            />
          )}
          {step === 2 && (
            <ScheduleAppointmentDate
              checkedIndex={checkedIndex}
              setCheckedIndex={setCheckedIndex}
            />
          )}
        </Stack>
      </Stack>
      <Stack
        direction="row"
        m="1rem"
        width="98%"
        alignSelf="center"
        justifyContent="space-between"
      >
        <Button
          disabled={step === 0}
          type="submit"
          onClick={() => setStep(step - 1)}
          sx={{
            border: "none",
          }}
        >
          BACK
        </Button>
        <Button
          type="submit"
          onClick={() =>
            step === 2 ? navigate("/UserDashboard/vehicles") : setStep(step + 1)
          }
          disabled={checkedIndex === null}
          sx={{
            border: "none",
          }}
        >
          NEXT
        </Button>
      </Stack>
    </Card>
  );
};

const styles = {
  card: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-around",
    border: "2px solid #666886",
    borderRadius: 4,
    height: "100%",
    maxWidth: "1800px",
    position: "relative",
    alignSelf: "center",
    m: ".5rem",
  },
  divider: {
    m: "1rem 4rem",
    display: {
      xs: "none",
      sm: "none",
      md: "none",
      lg: "none",
      xl: "flex",
    },
  },
  rightPane: {
    alignItems: "center",
    justifyContent: "center",
    width: "45%",
    maxWidth: "650px",
    minWidth: "650px",
    minHeight: 420,
  },
  nextButton: {
    border: "none",
    mr: "1rem",
  },
};

export default ScheduleAppointment;
