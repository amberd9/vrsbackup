import Stack from "@mui/material/Stack";
import Fab from "@mui/material/Fab";
import Typography from "@mui/material/Typography";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import FixedList from "../FixedList";
import { useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";

const ScheduleAppointmentRequestID = ({ checkedIndex, setCheckedIndex }) => {
  const navigate = useNavigate();
  const requestTypes = [
    "Arrival Private Shipment",
    "Arrival IAL Shipment",
    "Arrival HHG Shipment",
    "Arrival Driving EU",
    "Arrival Driving NON-EU",
    "Gained/Retained Logistical Support", // #Career Change
    "Separating/Retiring: Staying in DEU with Logistical Support",
    "Separating/Retiring: Staying in DEU without Logistical Support",
    "Separating/Retiring: Leaving DEU",
    "Separating/Retiring: Terminal Leave",
    "Bought NEW EU SPEC Vehicle from Local National/Dealership",
    "Bought OLD EU SPEC Vehicle from Local National/Dealership",
    "Bought NEW US SPEC Vehicle from Local National/Dealership",
    "Bought OLD US SPEC Vehicle from Local National/Dealership",
    "Sold EU SPEC Vehicle to Local National/Dealership",
    "Sold US SPEC Vehicle to Local National/Dealership",
    "Selling Vehicle to DOD ID Holder",
    "Buying Vehicle from DOD ID Holder",
    "Disposing Vehicle with MWR",
    "Disposing Vehicle NOT with MWR",
    "Need to Ship Vehicle, but has Temp Plates",
    "Need to Sell Vehicle, but Registration is Expired",
    "Need to Sell Vehicle, but has Temp Plates",
    "Departure IAL Shipment",
    "Departure Private Shipment",
    "Departure HHG Shipment",
    "Departure Driving",
    "Departure Shipment Request for QQ Shipping Plates",
    "Disability Placard",
    "Fuel Ration Request",
    "Suspense Clearance",
    "License Suspended/Revoked",
    "Insurance Suspended",
    "Insurance Cancelled",
    "Deployment Services",
    "Need Power of Attorney",
    "Need an Agent Owner",
    "Renew Registration: Permanent Plates",
    "Renew Registration: Non-Operational",
    "Initial Registration: Non-Operational",
    "Expired Registration: Permanent Plates",
    "Expired Registration: Non-Operational", //Becomes nonop renewal
    "Expired Registration: Temp Plates",
    "Expired Registration: 2nd Temp Plates",
    "Request for Initial Temp Plates",
    "Request for Second Set Temp Plates",
    "Request for Third Set Temp Plates",
    "Request for Permanent Plates",
    "Cannot Pass Inspection (has Permanent Plates)",
    "Update or Change Registration Information",
    "Add a Joint Owner or Additional Driver",
    "Update Personal Information (Rank, Name, Unit..)",
    "Update Address",
    "Update Insurance",
    "Remove Lien Holder",
    "Lost or Stolen Registration",
    "Replace Inspection Sticker",
    "Replace Environmental Sticker",
    "Lost or Stolen Plates",
    "Seized Plates",
  ];

  const carModels = [
    "2019 Toyota Camry",
    "2005 Jeep Wrangler",
    "2003 Ford F150",
    "2024 Chevy Silverado",
    "2016 Honda Civic",
    "2001 Nissan Altima",
    "2014 Dodge Ram",
    "2022 GMC Sierra",
    "2024 Subaru Outback",
    "2021 Hyundai Elantra",
    "2008 Kia Soul",
    "2015 Mazda 3",
    "2014 Volkswagen Jetta",
    "2021 BMW 3 Series",
  ];

  useEffect(() => {
    setCheckedIndex(null);
  }, []);

  return (
    <>
      <FixedList
        HeaderText={"Select Request ID #"}
        FirstLineData={requestTypes}
        SecondLineData={carModels}
        checkedIndex={checkedIndex}
        setCheckedIndex={setCheckedIndex}
      />
      <Stack
        sx={{
          textAlign: "center",
          alignItems: "center",
          p: 2,
          minHeight: 150,
        }}
      >
        <Typography
          variant="caption"
          width="fit-content"
          sx={{ fontStyle: "italic" }}
          maxWidth="25rem"
        >
          {
            "Don’t see your request? Use your tabs above to see your requests or contact us. You can also start a new request here."
          }
        </Typography>

        <Fab
          color="secondary"
          variant="extended"
          size="large"
          sx={styles.selectRequestButton}
          onClick={() => navigate("/UserDashboard/requests")}
        >
          <AddCircleOutlineIcon size="small" /> New Request
        </Fab>
      </Stack>
    </>
  );
};

const styles = {
  selectRequestButton: {
    width: "fit-content",
    justifyContent: "left",
    fontSize: "1rem",
  },
};

export default ScheduleAppointmentRequestID;
