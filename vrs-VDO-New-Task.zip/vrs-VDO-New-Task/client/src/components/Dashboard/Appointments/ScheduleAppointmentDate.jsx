import FixedList from "../FixedList";
import { Stack, Typography } from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers";
import { useEffect } from "react";

const ScheduleAppointmentDate = ({ checkedIndex, setCheckedIndex }) => {
  const times = [
    "8:00 AM",
    "8:30 AM",
    "9:00 AM",
    "9:30 AM",
    "10:00 AM",
    "10:30 AM",
    "11:00 AM",
    "11:30 AM",
    "12:00 PM",
    "12:30 PM",
    "1:00 PM",
    "1:30 PM",
    "2:00 PM",
    "2:30 PM",
    "3:00 PM",
    "3:30 PM",
    "4:00 PM",
    "4:30 PM",
  ];

  const openings = [
    "2 openings",
    "1 opening",
    "3 openings",
    "4 openings",
    "1 openings",
    "2 openings",
    "1 opening",
    "3 openings",
    "4 openings",
    "1 openings",
    "2 openings",
    "1 opening",
    "3 openings",
    "4 openings",
    "1 openings",
    "2 openings",
    "1 opening",
    "3 openings",
    "4 openings",
  ];

  useEffect(() => {
    setCheckedIndex(null);
  }, []);

  return (
    <Stack alignItems="center">
      <Stack sx={{ width: "50%", justifySelf: "center" }}>
        <Typography variant="h6">Select Appt. Date</Typography>
        <DatePicker
          slotProps={{
            textField: {
              size: "small",
            },
          }}
        />
      </Stack>
      <FixedList
        HeaderText={"Select Location"}
        FirstLineData={times}
        SecondLineData={openings}
        checkedIndex={checkedIndex}
        setCheckedIndex={setCheckedIndex}
      />
    </Stack>
  );
};

export default ScheduleAppointmentDate;
