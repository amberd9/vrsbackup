import {
  Stack,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import { ArrowDownwardRounded } from "@mui/icons-material";
import { ArrowDropDownIcon } from "@mui/x-date-pickers";
import { astroTV, astromoneyman } from "../../imgs";
const Partners = () => {
  return (
    <>
      <Stack
        direction="row-reverse"
        justifyContent="space-evenly"
        pt="1%"
        display="flex"
        sx={{
          "::-webkit-scrollbar-thumb": {
            background: "#ffb74d",
          },
          "::-webkit-scrollbar-thumb:hover": {
            background: "#00e5ff",
          },
          overflowY: "auto",
          borderRadius: 4,
          backgroundColor: "tertiary",
        }}
      >
        <img src={astromoneyman} alt="astroreader" height={400} />
        <Stack width="40%">
          <Stack justifyContent="space-evenly">
            <Typography
              fontSize="28px"
              fontFamily="Fira Sans Extra Condensed"
              color="#d35d9c"
              align="center"
            >
              <br /> BROWSE PARTNERS BY SERVICE <br />
            </Typography>
            <Typography
              fontSize="22px"
              fontFamily="Fira Sans Extra Condensed"
              color="#e9ead3"
              align="center"
              px={5}
            >
              <br /> TODO: BROWSE BY LOCATION?
              <br /> <br />
            </Typography>
          </Stack>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="Roboto Extra Condensed"
              id="newreg-header"
            >
              <Typography>IAL</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>DOCUMENT: AEF-910</Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDropDownIcon />}
              id="regrenew-header"
            >
              <Typography>KAPUN</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                NON-OP WAIVER TEMPLATE: ARMY <br /> NON-OP WAIVER TEMPLATE: AIR
                FORCE
              </Typography>
            </AccordionDetails>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="Roboto Extra Condensed"
              id="newreg-header"
            >
              <Typography>FMS</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>DOCUMENT: AEF-910</Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDropDownIcon />}
              id="regrenew-header"
            >
              <Typography>CUSTOMS OFFICE</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                NON-OP WAIVER TEMPLATE: ARMY <br /> NON-OP WAIVER TEMPLATE: AIR
                FORCE
              </Typography>
            </AccordionDetails>
            <AccordionSummary
              expandIcon={<ArrowDownwardRounded />}
              fontFamily="Roboto Extra Condensed"
              id="newreg-header"
            >
              <Typography>POAs - BASE LEGAL</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>SHIPPING</Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              expandIcon={<ArrowDropDownIcon />}
              id="regrenew-header"
            >
              <Typography>POAs - BASE LEGAL</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                NAME CHANGE <br /> SEPARATION/RETIREMENT
              </Typography>
            </AccordionDetails>
          </Accordion>
        </Stack>
      </Stack>
    </>
  );
};
export default Partners;
