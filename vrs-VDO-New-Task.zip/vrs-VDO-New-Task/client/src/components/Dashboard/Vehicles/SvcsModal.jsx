import { useState } from "react";
import {
  Dialog,
  Fab,
  DialogContent,
  Box,
  Divider,
  Paper,
  Stack,
  TextField,
  ToggleButtonGroup,
  ToggleButton,
  AppBar,
  Toolbar,
  Typography,
  Button,
  Modal,
  Tooltip,
} from "@mui/material";
import {
  AddCircleRounded,
  TwoWheelerRounded,
  DirectionsCarRounded,
  ConstructionRounded,
  ElectricCarRounded,
  BikeScooterRounded,
} from "@mui/icons-material";
import { userAstronautSedan } from "../../../imgs";
import RequestsMiniCards from "./RequestsMiniCards";
import { ThemeProvider } from "@mui/material";
import { QueueThemeProvider, ServicePathThemeProvider } from "../../../Themes";
import { serviceTheme } from "../../../Themes";

const OpenRequestsModal = () => {
  const [open, setOpen] = useState(false);
  const [currentKey, setKey] = useState("open");
  const handleChange = (event, newValue) => {
    set(newChoice);
  };

  return (
    <>
      <Stack direction="row" columnGap={2} justifyContent="space-around">
        <RequestsMiniCards
          value={currentKey}
          onChange={(event, newValue) => {
            setCurrentTab(newValue);
          }}
          textColor="primary"
          component={Paper}
          centered
        />
        <Card key="R1" label="Open Requests" />
        <RequestsMiniCards onClick={() => setOpen(true)} color="secondary" />
        <AddCircleRounded />
        <Modal open={open} onClose={() => setOpen(false)}>
          <Box
            sx={{
              width: 1000,
              maxWidth: "90vw",
              mx: "auto",
              mt: 4,
              backgroundColor: "#1A1429",
              // opacity: 0.9,
              borderRadius: "12px 12px 0px 0px",
            }}
          >
            <AppBar
              position="sticky"
              sx={{
                // border: "2px solid #9078d5",
                borderRadius: "12px 12px 0px 0px",
              }}
            >
              {" "}
              <Toolbar className="mainHeaderBar" sx={{ flexGrow: 1 }}>
                <Typography
                  variant="h4"
                  color="text.tertiary"
                  fontFamily="Fira Sans Extra Condensed"
                >
                  ADD VEHICLE
                </Typography>
              </Toolbar>
            </AppBar>
            <Divider sx={{ border: "2px solid #9078d5" }} />
            <Stack
              sx={{
                p: 2,
                border: "3px solid #9078D5",
                borderTopWidth: 0,
                borderRadius: "0px 0px 12px 12px",
              }}
            >
              <Stack rowGap={2.5}>
                <Stack
                  component={Paper}
                  direction="row"
                  justifyContent="space-between"
                  alignItems="center"
                  sx={{
                    backgroundColor: "#31225B",

                    fontFamily: "Fira Sans Extra Condensed",
                    border: "3px #CBBEFF solid",
                    borderRadius: 4,
                    px: 2,
                  }}
                >
                  <Typography
                    variant="h4"
                    fontFamily="Fira Sans Extra Condensed"
                  >
                    REQUESTS INFORMATION
                  </Typography>
                  <img
                    src={userAstronautSedan}
                    alt="Car Astronaut"
                    height={110}
                  />
                </Stack>
                <Stack direction="row" gap={3}>
                  <TextField size="small" variant="outlined" label="Make" />
                  <TextField size="small" variant="outlined" label="Model" />
                  <TextField size="small" variant="outlined" label="VIN" />
                </Stack>
                <Stack direction="row" spacing={2}>
                  <Typography
                    variant="h5"
                    sx={{
                      fontFamily: "Fira Sans Extra Condensed",
                      fontWeight: "light",
                    }}
                  >
                    Type:{" "}
                  </Typography>
                  <ToggleButtonGroup size="small" variant="filled" value={pov}>
                    <ToggleButton
                      value="car"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <DirectionsCarRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Vehicle
                    </ToggleButton>
                    <ToggleButton
                      value="moto"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <TwoWheelerRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Motorcycle
                    </ToggleButton>

                    <ToggleButton
                      value="rec"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <BikeScooterRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />{" "}
                      Recreational
                    </ToggleButton>
                  </ToggleButtonGroup>
                </Stack>

                <Stack direction="row" gap={5} justifyContent="right">
                  <Button size="small" color="tertiary">
                    SAVE
                  </Button>
                  <Button size="small">CANCEL</Button>
                </Stack>
              </Stack>
            </Stack>
          </Box>
        </Modal>
      </Stack>
    </>
  );
};

export default OpenRequestsModal;
