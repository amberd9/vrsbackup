import { useState } from "react";
import {
  Fab,
  Box,
  Divider,
  Paper,
  Stack,
  TextField,
  ToggleButtonGroup,
  ToggleButton,
  AppBar,
  Toolbar,
  Typography,
  Button,
  Modal,
  Tooltip,
  Chip,
  IconButton,
} from "@mui/material";
import {
  TwoWheelerRounded,
  DirectionsCarRounded,
  ConstructionRounded,
  ElectricCarRounded,
  BikeScooterRounded,
  InfoOutlined,
  ModeEditRounded,
  GavelRounded,
} from "@mui/icons-material";
import { DatePicker } from "@mui/x-date-pickers";
import { cancel, userAstronautSedan } from "../../../imgs";
import CurrentVehiclesMiniCards from "./CurrentVehiclesMiniCards";
import dayjs from "dayjs";
import isSameOrAfter from "dayjs/plugin/isSameOrAfter";
import relativeTime from "dayjs/plugin/relativeTime";
import VehiclesCards4PanelRow from "./VehiclesCards4PanelRow";

const EditVehicleModal = ({
  open,
  handleClose,
  handleOpen = false,
  showFab = false,
}) => {
  const [pov, setPov] = useState("car");
  const [regType, setRegType] = useState("reg");
  const [iDate, setiDate] = useState(dayjs().add(1, "year"));
  const [regValid, setRegValid] = useState(true);
  const [regExpOpen, setRegExpOpen] = useState(false);

  const [regExp, setRegExp] = useState(true);
  dayjs.extend(isSameOrAfter);
  dayjs.extend(relativeTime);

  return (
    <>
      {showFab && Boolean(handleOpen) && (
        <Fab onClick={handleOpen} color="secondary" size="small">
          <ModeEditRounded />
        </Fab>
      )}

      <Modal open={open} onClose={handleClose}>
        <Box
          sx={{
            width: 1000,
            maxWidth: "90vw",
            mx: "auto",
            mt: 4,
            backgroundColor: "#1A1429",
            borderRadius: "12px 12px 0px 0px",
          }}
        >
          <AppBar position="sticky">
            <Toolbar className="mainHeaderBar" sx={{ flexGrow: 1 }}>
              <Typography
                variant="h4"
                color="##B0F2B4"
                fontFamily="Fira Sans Extra Condensed"
              >
                EDIT VEHICLE
              </Typography>
              <IconButton
                sx={{ position: "absolute", top: 5, right: 5 }}
                size="small"
                onClick={handleClose}
              >
                <img src={cancel} alt="cancel" height="30px" />
              </IconButton>
            </Toolbar>
          </AppBar>
          <Divider sx={{ border: "2px solid #9078d5" }} />
          <Stack
            sx={{
              p: 2,
              border: "3px solid #6e628e",
              borderTopWidth: 0,
              borderRadius: "0px 0px 8px 8px",
              "::-webkit-scrollbar": {
                width: 0,
                height: 0,
              },
              overflowY: "auto",
              overflowX: "auto",
              maxHeight: "80svh",
            }}
            spacing={1}
          >
            <Stack
              component={Paper}
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              sx={{
                backgroundColor: "#31225B",

                fontFamily: "Fira Sans Extra Condensed",
                border: "3px #CBBEFF solid",
                borderRadius: 4,
                px: 2,
              }}
            >
              <Typography variant="h4" fontFamily="Fira Sans Extra Condensed">
                YOUR VEHICLE INFORMATION
              </Typography>
              <img src={userAstronautSedan} alt="Car Astronaut" height={110} />
            </Stack>
            {/* <VehiclesCards4PanelRow /> */}
            <Stack justifyContent="space-between" spacing={1.5}>
              <Typography
                variant="h5"
                sx={{
                  fontFamily: "Fira Sans Extra Condensed",
                  fontWeight: "light",
                  color: "secondary",
                }}
              >
                Vehicle Details:
              </Typography>
              <Stack direction="row" gap={3}>
                <TextField
                  size="small"
                  variant="outlined"
                  label="Make"
                  color="secondary"
                />
                <TextField
                  size="small"
                  variant="outlined"
                  label="Model"
                  color="secondary"
                />
                <TextField
                  size="small"
                  variant="outlined"
                  label="VIN"
                  color="secondary"
                />
              </Stack>
              <Stack gap={1}>
                <Typography
                  variant="h5"
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "light",
                    color: "secondary",
                  }}
                >
                  Type:
                </Typography>
                <Stack direction="row" spacing={4}>
                  <ToggleButtonGroup size="small" variant="filled" value={pov}>
                    <ToggleButton
                      value="car"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <DirectionsCarRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Vehicle
                    </ToggleButton>
                    <ToggleButton
                      value="moto"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <TwoWheelerRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Motorcycle
                    </ToggleButton>
                    <ToggleButton
                      value="rec"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <BikeScooterRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Recreational
                    </ToggleButton>
                    <ToggleButton
                      value="rec"
                      onClick={(event, newValue) => {
                        setPov(newValue);
                      }}
                    >
                      <GavelRounded
                        sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                      />
                      Agent Owner
                    </ToggleButton>
                  </ToggleButtonGroup>
                  <Tooltip
                    title={
                      <>
                        <Typography>
                          Recreational includes RV, Camper, Quad, etc.
                        </Typography>
                        <Typography>
                          Agent Owner: If you are acting as an Agent Owner for
                          someone elses' vehicle.
                        </Typography>
                      </>
                    }
                  >
                    <IconButton>
                      <InfoOutlined />
                    </IconButton>
                  </Tooltip>
                </Stack>
              </Stack>
              <Stack gap={1}>
                <Typography
                  variant="h5"
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "light",
                    color: "secondary",
                  }}
                >
                  Registration Expiration:
                </Typography>

                <DatePicker
                  open={regExpOpen}
                  slotProps={{
                    textField: {
                      onClick: () => setRegExpOpen(!regExpOpen),
                      size: "small",
                      helperText:
                        regValid && !regExp
                          ? "You can renew your registration! Start a new request in your dashboard."
                          : regExp && !regValid
                          ? "Your registration is expired - start a new request!"
                          : "You must wait until 75 days before expiration.",
                    },
                  }}
                  value={iDate}
                  onChange={(val) => {
                    setiDate(val);
                    if (dayjs(val).subtract(75, "day") > dayjs()) {
                      setRegValid(false);
                      setRegExp(false);
                      //set regexp(false) to highlight text and field in RED because it is expired!
                    } else if (dayjs(val) < dayjs()) {
                      setRegValid(false);
                      setRegExp(true);
                    } else {
                      setRegValid(true);
                      setRegExp(false);
                    }
                    setRegExpOpen(false);
                  }}
                />
              </Stack>
              <Stack gap={1}>
                <Typography
                  variant="h5"
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "light",
                    color: "secondary",
                  }}
                >
                  Date Eligible to Renew:
                </Typography>
                <TextField
                  inputProps={{ readOnly: true }}
                  size="small"
                  value={dayjs(iDate).subtract(75, "days").format("MM/DD/YYYY")}
                />
              </Stack>
              <Stack gap={1}>
                <Typography
                  variant="h5"
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "light",
                    color: "secondary",
                  }}
                >
                  Days until Registration Expires:
                </Typography>

                <Chip
                  variant="outlined"
                  color="secondary"
                  sx={{ fontSize: 20 }}
                  label={dayjs(iDate).toNow(true)}
                />
              </Stack>
              <Stack gap={1}>
                <Typography
                  variant="h5"
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "light",
                    color: "secondary",
                  }}
                >
                  Registration Type:
                </Typography>

                <ToggleButtonGroup
                  size="small"
                  variant="filled-nodal"
                  value={regType}
                >
                  <ToggleButton
                    value="reg"
                    onClick={(event, newValue) => {
                      setRegType(newValue);
                    }}
                  >
                    <DirectionsCarRounded
                      sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                    />
                    Permanent Plates
                  </ToggleButton>
                  <ToggleButton
                    value="nonOp"
                    onClick={(event, newValue) => {
                      setRegType(newValue);
                    }}
                  >
                    <ConstructionRounded
                      sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                    />
                    NonOperational
                  </ToggleButton>
                  <ToggleButton
                    value="Temp Plates"
                    onClick={(event, newValue) => {
                      setRegType(newValue);
                    }}
                  >
                    <ElectricCarRounded
                      sx={{ mr: 1, mt: -0.5, color: "#2BDEC8" }}
                    />
                    Temp Plates
                  </ToggleButton>
                </ToggleButtonGroup>
              </Stack>
              <Stack direction="row" gap={5} justifyContent="right">
                <Button size="small">SAVE</Button>
                <Button size="small" onClick={handleClose}>
                  CANCEL
                </Button>
              </Stack>
            </Stack>
          </Stack>
        </Box>
      </Modal>
    </>
  );
};

export default EditVehicleModal;
