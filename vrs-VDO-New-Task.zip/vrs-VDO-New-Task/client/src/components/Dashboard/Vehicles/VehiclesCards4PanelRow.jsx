import { useState } from "react";
import {
  Box,
  Card,
  Stack,
  CardMedia,
  Typography,
  CardActionArea,
} from "@mui/material";

import {
  astrodrivinginredtruck,
  userAstroAgent,
  userAstroPurpleMotor,
  userAstroShoppingCart,
  userAstroYellowSports,
} from "../../../imgs";

const VehiclesCards4PanelRow = () => {
  const [pov, setPov] = useState("car1");

  const cardData = [
    {
      key: "V1",
      title: "Vehicle 1",
      content: "Car",
      image: userAstroYellowSports,
    },
    {
      key: "V2",
      title: "Vehicle 2",
      content: "My Red Truck",
      image: astrodrivinginredtruck,
      imageSize: "50%",
    },
    {
      key: "V3",
      title: "Vehicle 3",
      content: "Motorcycle",
      image: userAstroPurpleMotor,
    },
    {
      key: "V4",
      title: "Vehicle 4",
      content: "Recreational Vehicle",
      image: userAstroShoppingCart,
    },
    {
      key: "V5",
      title: "Vehicle 5",
      content: "Agent Owner",
      image: userAstroAgent,
    },
  ];

  return (
    <>
      <Stack
        maxHeight="60svh"
        sx={{ border: "2px solid #660886", borderRadius: 4, p: 0.5 }}
      >
        <Stack
          sx={{
            "::-webkit-scrollbar": {
              width: 3,
              height: 0.2,
              color: "tertiary",
            },
            "::-webkit-scrollbar-thumb": {
              background: "#ffb74d",
            },
            "::-webkit-scrollbar-thumb:hover": {
              background: "#00e5ff",
            },
            overflowY: "auto",
            maxWidth: "70svh",
            borderRadius: 4,
            p: 0.5,
            backgroundColor: "tertiary",
          }}
          spacing={1.5}
        >
          {cardData.map((item, index) => (
            <Box key={index}>
              <Card
                sx={{
                  border: "2px solid #666886",
                  borderRadius: 4,
                  minWidth: 200,
                }}
              >
                <CardActionArea sx={{ height: "100%" }}>
                  <CardMedia
                    align="center"
                    onClick={() => setPov(item)}
                    sx={{ maxHeight: 100, position: "top center", mb: 5 }}
                  >
                    <Box
                      component="img"
                      src={item.image}
                      sx={{ maxHeight: "150px" }}
                    />
                  </CardMedia>
                  <Typography
                    align="center"
                    sx={{ backgroundColor: "#1D0061" }}
                  >
                    {item.title}
                  </Typography>
                  <Typography
                    align="center"
                    sx={{ backgroundColor: "#1D0061" }}
                  >
                    {item.content}
                  </Typography>
                </CardActionArea>
              </Card>
            </Box>
          ))}
        </Stack>
      </Stack>
    </>
  );
};

export default VehiclesCards4PanelRow;
