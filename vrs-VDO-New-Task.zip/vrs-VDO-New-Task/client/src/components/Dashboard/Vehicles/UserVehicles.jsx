import { useState } from "react";
import { Stack, Button, Typography, Paper, Box, Divider } from "@mui/material";
import VehicleInfoCards from "./VehicleInfoCards";
import VehiclesCards4PanelRow from "./VehiclesCards4PanelRow";
import AddVehicleModal from "./AddVehicleModal";
import UserDashboardSplash from "../../../views/UserDashboardSplash";

const UserVehicles = () => {
  const [addOpen, setAddOpen] = useState(false);
  const [dbSplashOpen, setDBSplashOpen] = useState(false);
  return (
    <>
      <AddVehicleModal
        modalName="AddVehicleModal"
        open={addOpen}
        handleClose={() => setAddOpen(false)}
      />
      <UserDashboardSplash
        iopen={dbSplashOpen}
        handleCancel={() => setDBSplashOpen(false)}
      />
      <Stack
        position="relative"
        direction="row"
        spacing={1}
        justifyContent="space-evenly"
        pt="1%"
      >
        <Stack justifyContent="bottom" alignSelf="center">
          <Stack maxWidth="200px" gap={1} ml={3}>
            <Button
              size="small"
              color="secondary"
              onClick={() => setDBSplashOpen(true)}
            >
              Instructions
            </Button>
            <Button
              size="small"
              color="secondary"
              onClick={() => setAddOpen(true)}
            >
              Add Vehicle
            </Button>
          </Stack>
          <Stack spacing={1} mt={2.0} justifyContent="center" ml={2}>
            <Typography
              align="center"
              component={Paper}
              sx={{
                backgroundColor: "#31225B",
                py: 0.5,
                mb: 0.5,
                borderRadius: 25,
              }}
              variant="h6"
              fontWeight="light"
              fontFamily="Fira Sans Extra Condensed"
              color="text.tertiary"
            >
              MY VEHICLES
            </Typography>

            <Box
              sx={{
                "::-webkit-scrollbar-thumb": {
                  background: "#ffb74d",
                },
                "::-webkit-scrollbar-thumb:hover": {
                  background: "#00e5ff",
                },
                overflowY: "auto",
                maxWidth: "70svh",
                borderRadius: 4,
                backgroundColor: "tertiary",
              }}
              spacing={1.5}
            >
              <VehiclesCards4PanelRow />
            </Box>
          </Stack>
        </Stack>
        <Box py={10}>
          <VehicleInfoCards />
        </Box>
      </Stack>
    </>
  );
};
export default UserVehicles;
