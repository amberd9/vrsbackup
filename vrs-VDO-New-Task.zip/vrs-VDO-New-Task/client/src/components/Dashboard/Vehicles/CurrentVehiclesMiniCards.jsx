import { useState } from "react";
import {
  Box,
  Card,
  Stack,
  CardMedia,
  Typography,
  CardActionArea,
} from "@mui/material";
import {
  userAstroAgent,
  userAstroPurpleMotor,
  userAstroShoppingCart,
  userAstroYellowSports,
  astrodrivinginredtruck,
} from "../../../imgs";
import EditVehicleModal from "./EditVehicleModal";

const CurrentVehiclesMiniCards = () => {
  const [showEdit, setShowEdit] = useState(false);
  const cardData = [
    {
      title: "Vehicle 1",
      content: "Car",
      image: userAstroYellowSports,
    },
    {
      title: "Vehicle 2",
      content: "My Red Truck",
      image: astrodrivinginredtruck,
    },
    {
      title: "Vehicle 3",
      content: "Motorcycle",
      image: userAstroPurpleMotor,
    },
    {
      title: "Vehicle 4",
      content: "Recreational Vehicle",
      image: userAstroShoppingCart,
    },
    {
      title: "Vehicle 5",
      content: "Agent Owner",
      image: userAstroAgent,
    },
  ];

  return (
    <>
      <EditVehicleModal
        open={showEdit}
        handleClose={() => {
          setShowEdit(false);
        }}
        showFab={false}
      />
      <Stack
        sx={{
          "::-webkit-scrollbar": {
            width: 0,
            height: 0,
          },
          overflowY: "auto",
          overflowX: "auto",
          maxHeight: "80svh",
          border: "2px solid #666886",
          borderRadius: 4,
        }}
        spacing={1}
      >
        {cardData.map((item, i) => (
          <Box key={i} px={1}>
            <Card sx={{ border: "2px solid #666886", borderRadius: 4 }}>
              <CardActionArea onClick={() => setShowEdit(true)}>
                <CardMedia align="center">
                  <Box component="img" src={item.image} />
                </CardMedia>
                <Typography align="center" sx={{ backgroundColor: "#1D0061" }}>
                  {item.title}
                </Typography>
                <Typography align="center" sx={{ backgroundColor: "#1D0061" }}>
                  {item.content}
                </Typography>
              </CardActionArea>
            </Card>
          </Box>
        ))}
      </Stack>
    </>
  );
};

export default CurrentVehiclesMiniCards;
