import { useState } from "react";
import {
  Box,
  Card,
  Stack,
  CardMedia,
  Typography,
  CardActionArea,
  CardContent,
} from "@mui/material";
import {
  userAstronautSedan,
  userRoboServices,
  userAstroServices,
} from "../../../imgs";
import EditVehicleModal from "./EditVehicleModal";

const VehicleInfoCards = () => {
  const [editOpen, setEditOpen] = useState(false);

  return (
    <>
      <Stack
        direction="row"
        sx={{
          "::-webkit-scrollbar": { width: 0, height: 0 },
          overflowY: "auto",
          borderRadius: 4,
        }}
        mr={10}
      >
        <Box px={4}>
          <Card sx={{ border: "2px solid #666886", borderRadius: 4 }}>
            {/* for future api connection - loading card information based on user profile content // dispatch(updateSelectedRequest(request)); */}
            <CardMedia>
              <Box
                align="center"
                component="img"
                src={userAstronautSedan}
                alt="Astro Car"
                height={200}
                p={1}
              />{" "}
            </CardMedia>
            <CardContent
              align="center"
              sx={{
                backgroundColor: "#342570",
                p: 3,
                pt: 2,
                mt: 5,
                height: 300,
                width: 515,
              }}
            >
              <Box
                sx={{
                  border: "3px solid #7c79ad",
                  borderRadius: 4,
                  backgroundColor: "rgb(25, 23, 49, 70%)",
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "regular",
                    fontSize: 24,
                    p: 2,
                  }}
                >
                  VEHICLE INFO
                </Typography>
                <Typography>
                  Type <br /> Registration Expiration
                  <br /> Days Left to Renewal
                  <br />
                </Typography>
                <Box p={3.5}>
                  <EditVehicleModal
                    sx={{ position: "absolute", right: "top" }}
                    open={editOpen}
                    handleClose={() => setEditOpen(false)}
                    handleOpen={() => setEditOpen(true)}
                    showFab={true}
                  />
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Box>
        <Box px={1}>
          <Card sx={{ border: "2px solid #666886", borderRadius: 4 }}>
            {/* // // dispatch(updateSelectedRequest(request)); */}
            <CardMedia align="center">
              <Box
                component="img"
                src={userRoboServices}
                alt="Robot Roomba"
                height={100}
              />
              <Box
                component="img"
                src={userAstroServices}
                alt="Astro Mechanic"
                height={200}
              />
            </CardMedia>
            <CardContent
              align="center"
              sx={{
                backgroundColor: "#342570",
                p: 3,
                pt: 2,
                mt: 5,
                height: 300,
                width: 500,
              }}
            >
              <Box
                sx={{
                  border: "3px solid #7c79ad",
                  borderRadius: 4,
                  backgroundColor: "rgb(25, 23, 49, 70%)",
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Fira Sans Extra Condensed",
                    fontWeight: "regular",
                    fontSize: 24,
                    p: 2,
                  }}
                >
                  SERVICES RENDERED
                </Typography>
                <Typography>
                  {" "}
                  Request #124 <br />
                  Agent Owner for Vehicle #2 <br /> <br /> Request #432 <br />{" "}
                  Added joint spouse and plates seized.
                  <br /> <br />
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Stack>
    </>
  );
};

export default VehicleInfoCards;
