import { Stack, Typography, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";
import * as React from "react";
import { typ_servnav } from "../Services/WalkthruCSS";

const ServicesNav = () => {
  const navigate = useNavigate();
  return (
    <Box className="sticky2" background="#581b3596">
      <Stack
        direction="row"
        justifyContent="space-around"
        px={50}
        flex={1}
        background="#"
      >
        <Typography sx={typ_servnav}>
          Contact Us <a href="/UserDashboard/Contact" />
        </Typography>

        <Typography sx={typ_servnav}>
          Documents and Forms <a href="/UserDashboard/Documents" />
        </Typography>

        <Typography sx={typ_servnav}>
          <a href="/UserDashboard/Resources" />
          Tools and Resources
        </Typography>
      </Stack>
    </Box>
  );
};

export default ServicesNav;
