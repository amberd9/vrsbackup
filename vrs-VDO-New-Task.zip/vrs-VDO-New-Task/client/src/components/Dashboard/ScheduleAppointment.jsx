import Card from "@mui/material/Card";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import CardHeader from "@mui/material/CardHeader";
import Stack from "@mui/material/Stack";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import ListItemButton from "@mui/material/ListItemButton";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControl from "@mui/material/FormControl";
import FormControlLabel from "@mui/material/FormControlLabel";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { FixedSizeList } from "react-window";

const ScheduleAppointment = () => {
  return (
    <Card
      direction="column"
      justifyContent="space-around"
      sx={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-around",
        border: "2px solid #666886",
        borderRadius: 4,
        height: "100%",
        m: ".5rem",
      }}
    >
      <Stack textAlign="center">
        <Typography variant="h4">
          Select an approved Request ID # from the provided list below or start
          a new request
        </Typography>
        <Typography color="#d3d3d350" sx={{ fontStyle: "italic" }} variant="h5">
          Verify that the associated request details still look correct before
          continuing.
        </Typography>
      </Stack>
      <Stack direction="row" justifyContent="space-around" flexWrap="wrap">
        <Card
          sx={{
            border: "2px solid #666886",
            borderRadius: 4,
            minWidth: "500px",
            maxHeight: "250px",
            m: ".5rem",
            textAlign: "center",
            alignSelf: "center",
          }}
        >
          <Typography color="#fff" variant="h5" p=".5rem">
            Select Request ID
          </Typography>

          <Divider flexItem />
          {/* <FormControl sx={{ width: "100%" }}> */}
          <Box>
            <FixedSizeList
              height={200}
              width="100%"
              itemSize={46}
              itemCount={10}
            >
              {({ index, style }) => (
                <ListItemButton
                  divider={true}
                  radioGroup="r"
                  style={style}
                  key={index}
                >
                  <ListItemText primary={`Request ID #${index + 1}`} />
                </ListItemButton>
              )}
            </FixedSizeList>
          </Box>
          {/* TODO: add state and event handler for radio group */}
          {/* <RadioGroup value={"lorem"}>
              {["lorem", "ipsum", "dolor", "sit", "amet"].map((item, index) => {
                return (
                  <Stack
                    p={1}
                    sx={{
                      border: "1px solid #666886",
                      borderRadius: 4,
                    }}
                  >
                    <FormControlLabel control={<Radio />} label={item} />
                  </Stack>
                );
              })}
            </RadioGroup>
          </FormControl> */}
        </Card>
        <Divider
          orientation="vertical"
          flexItem
          sx={{ mt: "1rem", mb: "1rem" }}
        />
        <Card
          sx={{
            border: "2px solid #666886",
            borderRadius: 4,
            minWidth: "500px",
            m: ".5rem",
            textAlign: "center",
          }}
        >
          <Typography color="#fff" p=".5rem" variant="h5">
            Request Details
          </Typography>
          <Stack p="1rem">
            <Typography
              sx={{
                border: "1px solid #666886",
                borderRadius: 4,
                width: "fit-content",
                padding: ".5rem",
              }}
            >
              Request ID
            </Typography>
            <TextField
              defaultValue="POV Year/Make/Model/VIN"
              sx={{ margin: ".5rem" }}
              multiline={true}
            ></TextField>
            <TextField
              dafualtValue="Service Type/Info"
              sx={{ margin: ".5rem" }}
              multiline={true}
            ></TextField>
            <TextField
              defaultValue="Considerations [i.e. Buyer Name]"
              sx={{ margin: ".5rem" }}
              multiline={true}
            ></TextField>
          </Stack>
          <Button variant="contained">Make Corrections</Button>
          <Divider flexItem />
        </Card>
      </Stack>
    </Card>
  );
};

export default ScheduleAppointment;
