import { Box, Container, Typography } from "@mui/material";
import HomeNav from "../components/Buttons/HomeNav";

export default function UnderConstruction() {
  return (
    <Box>
      <Box component="img" src="./UnderConstruction.svg" />
      <Typography variant="h1" fontFamily="Fira Sans Extra Condensed">
        WE'RE UNDER CONSTRUCTION!
      </Typography>
      <HomeNav />
    </Box>
  );
}
