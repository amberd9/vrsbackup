import { useState } from "react";
import {
  Box,
  Button,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemButton,
  Avatar,
  ListItemAvatar,
  Typography,
  Stack,
  Breadcrumbs,
} from "@mui/material";
import { germanleaving } from "../../imgs";
import { Outlet, useNavigate } from "react-router-dom";
import {
  btn_restart,
  svc_btn_green,
  svc_btn_pink_light,
  svc_btn_purple,
  typ_roboto_lightsmall,
} from "../Services/WalkthruCSS";
const RequestNav = () => {
  const [checked, setChecked] = useState(0);
  const navigate = useNavigate();

  return (
    <Box alignItems="center" justifyContent="center" sx={{ width: "flex 5%" }}>
      <List>
        <ListItem>
          <ListItemButton onClick={() => navigate("/UserDashboard/Vehicles")}>
            <ListItemAvatar>
              <Avatar src={germanleaving} />
            </ListItemAvatar>
            <ListItemText primary="Username" />
          </ListItemButton>
        </ListItem>
      </List>
      <Stack alignItems="center" justifyContent="center" flex={1} padding={1}>
        <Button
          sx={{ ...btn_restart, background: "none", maxHeight: 30 }}
          onClick={() => navigate("/NewRequests")}
        >
          <Typography sx={{ maxHeight: 30 }}>Start Over</Typography>
        </Button>
      </Stack>
      <Divider sx={{ p: 1, color: "ActiveBorder" }} />
      {/* TODO This is where the history should be */}
      <Typography align="center" sx={typ_roboto_lightsmall}>
        HISTORY
        <Breadcrumbs></Breadcrumbs>
      </Typography>
      <List>
        <ListItem></ListItem>
      </List>
      <Divider sx={{ p: 1, color: "ActiveBorder" }} />
      <Stack
        direction="column"
        justifyContent="center"
        alignItems="center"
        padding={3}
        spacing={2}
      >
        <Box>
          <Button
            sx={{ ...svc_btn_purple, borderWidth: 1, maxHeight: 30 }}
            onClick={() => navigate("/UserDashboard/Documents")}
          >
            PDF Guide
          </Button>
        </Box>

        <Box>
          <Button
            sx={{ ...svc_btn_green, borderWidth: 1, maxHeight: 30 }}
            onClick={() => navigate("/QueueIn")}
          >
            Queue-In
          </Button>
        </Box>
        <Box>
          <Button
            sx={{ ...svc_btn_pink_light, borderWidth: 1, maxHeight: 30 }}
            onClick={() => navigate("/UserDashboard/Resources")}
          >
            FAQs
          </Button>
        </Box>
      </Stack>
      <Stack padding={3} spacing={2}>
        <Box>
          <Button
            variant="outlined"
            sx={{
              ...svc_btn_purple,
              background: "none",
              borderColor: "ButtonText",
              maxHeight: 35,
            }}
            onClick={() => navigate("/UserDashboard/Partners")}
          >
            External Partners
          </Button>
        </Box>
      </Stack>
    </Box>
  );
};

export default RequestNav;
