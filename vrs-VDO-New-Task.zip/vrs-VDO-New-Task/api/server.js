import express from "express";
import cors from "cors";
// import { v4 } from "uuid";
import cookieParser from "cookie-parser";
// import retrieveSecrets from "./utils/retrieve-secrets";
const app = express();
app.use(cookieParser());
app.use(
  cors({
    origin: process.env.NODE_ENV === "development" ? "*" : process.env.ENDPOINT,
  })
);

app.use(express.json());
if (process.env.NODE_ENV === "development") {
  // Logging responses to console
  app.use((req, res, next) => {
    let send = res.send;
    res.send = (c) => {
      console.log("Body: ", req.body);
      console.log("Code:", res.statusCode);
      res.send = send;
      return res.send(c);
    };
    next();
  });
  console.log("MODE:", process.env.NODE_ENV);
}
// Setup Routes
app.use("/api", (req, res, next) => {
  res.send("Hello World");
});

// Set up port to listen
const PORT = process.env.PORT || 4000;

app.listen(PORT, async () => {
  try {
    // Setup Secrets from Secrets Manager
    // const secrets = await retrieveSecrets("losthorizon");
    // Object.keys(secrets).forEach((key) => {
    //   if (!(key in process.env)) process.env[key] = secrets[key];
    // });
    // if (process.env.NODE_ENV === "development") console.log(secrets);
    // setup();
    console.log(`API server listening on port ${PORT}`);
  } catch (error) {
    console.log("Error in setting environment variables", error);
    process.exit(-1);
  }
});
