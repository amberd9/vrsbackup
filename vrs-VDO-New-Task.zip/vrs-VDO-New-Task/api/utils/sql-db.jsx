import { Sequelize } from "sequelize";

const sequelize =
  process.env.NODE_ENV === "production"
    ? new Sequelize(process.env.DATABASE_URL, {
        schema: "private",
        dialect: "postgres",
        protocol: "postgres",
        logging: false,
      })
    : new Sequelize({
        schema: "private",
        database: "VrsDB",
        username: "postgres",
        password: "admin",
        host: "localhost",
        port: 5432,
        dialect: "postgres",
        // logging: console.log,
        logging: false,
      });

await sequelize
  .authenticate()
  .then(() => {
    console.log("Connection to database has been established successfully.");
  })
  .catch((err) => {
    console.error("Unable to connect to the database:", err);
    process.exit(-1);
  });

export default sequelize;
