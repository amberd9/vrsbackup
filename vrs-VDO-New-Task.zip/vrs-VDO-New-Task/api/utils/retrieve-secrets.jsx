import { SecretsManager } from "@aws-sdk/client-secrets-manager";

export const retrieveSecrets = async (key) => {
  // Configure AWS SDK
  const region = "us-gov-west-1";
  const client = new SecretsManager({ region });

  // Retrieving secrets from secrets manager
  const data = await client.getSecretValue({ SecretId: key });

  // Parsing the fetched data into JSON
  return JSON.parse(data.SecretString);
};
