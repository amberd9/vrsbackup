import { retrieveSecrets } from "./retrieve-secrets.js";
// import { populateConfig } from "../keycloak/kc_model.js";

export const setupEnvironment = async () => {
  try {
    // Setup Secrets from Secrets Manager
    const secrets = await retrieveSecrets("Vrs");

    // Load the secrets into the environment
    Object.entries(secrets).forEach(
      ([key, value]) => (process.env[key] = value)
    );

    // Log the secrets if in dev mode
    if (process.env.NODE_ENV === "development") console.debug(secrets);

    console.log("Environment setup completed");
  } catch (error) {
    throw new Error("Error setting up environment: " + error.message);
  }
};
