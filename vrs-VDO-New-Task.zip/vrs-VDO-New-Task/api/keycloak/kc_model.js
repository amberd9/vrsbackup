import KeycloakClient from "./admin_client";
import KeycloakAdminClient from "@keycloak/keycloak-admin-client";

const config = {
  serverUrl: process.env.KC_SERVER || "https://auth.devilops.us",
  masterRealm: "master",
  requestRealm:
    process.env.NODE_ENV === "development" ? "dev" : process.env.KC_REALM,
  resource: process.env.KC_CLIENT || "vrs",
  adminLogin: process.env.KC_USER || "admin",
  adminPassword: process.env.KC_PASS || "pass",
  adminClientId:
    process.env.NODE_ENV === "development"
      ? "admin-cli"
      : process.env.KC_ADMIN_CLI,
  clientSecret:
    process.env.NODE_ENV === "development"
      ? process.env.KC_DEV_CLIENT_SECRET || ""
      : process.env.KC_CLIENT_SECRET || "",
};

const createAdminClient = async () => {
  try {
    const client = new KeycloakAdminClient({
      baseUrl: `${config.serverUrl}/auth`,
      realmName: config.requestRealm,
    });

    await client.auth({
      clientSecret: config.clientSecret,
      grantType: "client_credentials",
      clientId: config.adminClientId,
    });

    client.setConfig({ realmName: config.requestRealm });
    let newClient = new KeycloakClient(client, config);

    return newClient.AdminClient;
  } catch (e) {
    console.error("********* This is the problem *********");
    console.error(e);
  }
};

module.exports = createAdminClient;
