const { config, createAdminClient } = require("./kc_model"); // Update the path accordingly
const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");
const util = require("util");

// Helper to log objects with sub-objects
const logJSON = (out) => {
  console.log(
    util.inspect(out, { showHidden: false, depth: null, colors: true })
  );
};

// Middleware to authenticate Keycloak admin client
const authenticateAdmin = async (req, res, next) => {
  try {
    req.adminClient = await createAdminClient();
    next();
  } catch (error) {
    console.error("Failed to authenticate admin client:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const verifyGroup = (group, token) => {
  // Perform a regex match
  const escapedPattern = group.replace(/\*/g, ".*");
  const groupPattern = new RegExp(`^${escapedPattern}$`);
  for (const group of token.groups) {
    if (groupPattern.test(group)) {
      return true;
    }
  }
  return false;
};

// Middleware to verify JWT token using Keycloak Admin API
const verifyTokenAndGroup = (allowedGroups) => async (req, res, next) => {
  try {
    const authorizationHeader = req.headers.authorization;

    if (!authorizationHeader || !authorizationHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const token = authorizationHeader.split(" ")[1]; // Extract the token part

    const client = jwksClient({
      jwksUri: `${config.serverUrl}/auth/realms/${config.requestRealm}/protocol/openid-connect/certs`,
    });

    function jwtVerify(token, secretOrPublicKey) {
      return new Promise((resolve, reject) => {
        jwt.verify(token, secretOrPublicKey, (err, decoded) => {
          if (err) {
            reject(err);
          } else {
            resolve(decoded);
          }
        });
      });
    }

    function getKey(header, callback) {
      client.getSigningKey(header.kid, (err, key) => {
        if (err) {
          console.log(`Error signing key ${err}`);
          res.status(401).json({ error: "Unauthorized" });
          callback(null, null);
        } else {
          const signingKey = key.publicKey || key.rsaPublicKey;
          callback(null, signingKey);
        }
      });
    }

    // Verify the JWT has not expired
    const decodedToken = await jwtVerify(token, getKey);

    // Check if the token represents an active Keycloak session
    if (!decodedToken.session_state) {
      return res.status(403).json({ error: "Forbidden" });
    }

    // Append the Decoded Token
    req.decodedToken = decodedToken;

    // Append the email to the req
    req.email = decodedToken.preferred_username;

    // Append the KC username to sub
    req.username = decodedToken.sub;

    // Token is valid and represents an active Keycloak session
    // Check if user is part of any allowed group (with wildcard support)
    if (allowedGroups) {
      let isAllowed = false;
      const realm = req.adminClient.realms.agent.client;
      for (const allowedGroup of allowedGroups) {
        isAllowed = verifyGroup(allowedGroup, decodedToken); //TODO - verify the org id
        if (isAllowed) {
          break;
        }
        // if (decodedToken.groups.includes(allowedGroup)) {
        // }
      }

      if (!isAllowed) {
        return res.status(403).json({ error: "Forbidden" });
      }
    }
    next();
  } catch (error) {
    if (error.message === "invalid token" || error.message === "jwt expired") {
      res.status(401).json({ error: error.message });
    } else {
      console.error("Failed to introspect token:", error);
      res.status(500).json({ error: error.message });
    }
  }
};

// Helper function to create child groups
const createChildGroups = async (realm, parentId, groups) => {
  let childrenIds = {};
  //Iterate through and create all of the groups
  for (g of groups) {
    const newOrgSubgroup = await realm.groups.setOrCreateChild(
      { id: parentId },
      { name: g }
    );
    childrenIds[g] = newOrgSubgroup.id;
  }
  return childrenIds;
};

const verifyOrganizationExists = async (realm, oid) => {
  const groups = await realm.groups.find({ search: "organizations" });
  const orgGroups = findObjectByPropertyName(groups, "name", oid);
  return orgGroups.length > 0;
};

const verifyApplicationSpaceExists = async (realm, oid, aid) => {
  const groups = await realm.groups.find({ search: "applications" });
  const appGroups = findObjectByPropertyName(
    groups,
    "path",
    `/applications/${aid}/${oid}`
  );
  return appGroups.length > 0;
};

// Helper function to get user by username
const getUserByEmail = async (realm, username) =>
  await realm.users.findOne({ username, exact: true });

// Helper function to get group by name
const getGroupByName = async (realm, groupName) => {
  return await realm.groups.find({ name: groupName });
};

const getGroupMembersById = async (realm, id) => {
  let GROUPS = {};
  // Get the keycloak group and deconstruct to get the sub-groups
  const { subGroups } = await realm.groups.findOne({ id });
  // Loop over the sub-groups
  for (subGrp of subGroups) {
    // Assign sub-groups members to the object key labeled the sub-group's name
    GROUPS[subGrp.name] = await realm.groups.listMembers({
      id: subGrp.id,
    });
  }
  return GROUPS;
};

const getGroupMembers = async (realm, selectedOrgs) => {
  let GROUPS = {};
  const idList = selectedOrgs.map(({ id, name }) => {
    GROUPS[name] = {};
    return { id, name };
  });
  for (mainGrp of idList) {
    const { subGroups } = await realm.groups.findOne({ id: mainGrp.id });
    for (grp of subGroups) {
      GROUPS[mainGrp.name][grp.name] = await realm.groups.listMembers({
        id: grp.id,
      });
    }
  }
  return GROUPS;
};

const getAppAdminMembers = async (realm, selectedApps) => {
  let GROUPS = {};
  const idList = selectedApps.map(({ id, path }) => {
    const appName = path.split("/")[2];
    GROUPS[appName] = {};
    return { id, appName };
  });
  for (grp of idList) {
    GROUPS[grp.appName] = await realm.groups.listMembers({
      id: grp.id,
    });
  }
  return GROUPS;
};

const createNewOrganization = async ({
  realm,
  uid,
  name,
  requestor,
  justification,
}) => {
  try {
    // Get the "organizations" group ID
    const organizationsGroup = await getGroupByName(realm, "organizations");
    const organizationsGroupId = organizationsGroup.id;

    // Create the new organization subgroup with justification as an attribute
    const newOrgSubgroup = await realm.groups.setOrCreateChild(
      { id: organizationsGroupId },
      {
        name: uid,
        attributes: {
          name: [name],
          justification: [justification],
          requestor: [requestor],
          createdAt: [new Date().toISOString()],
        },
      }
    );
    return { id: newOrgSubgroup.id };
  } catch (error) {
    return { error };
  }
};

// Helper function to validate params
const validateUpdateParams = (body, schema) => {
  let updateValues = {};
  Object.keys(body).forEach((element) => {
    if (Object.keys(schema).includes(element)) {
      if (
        schema[element].hasOwnProperty("canUpdate") &&
        schema[element].canUpdate
      ) {
        updateValues[element] = body[element];
      }
    }
  });
  return updateValues;
};

// Helper function to add user to a org group (add or delete)
const modifyUserOrgGroupAccess = async (realm, uid, oid, group, action) => {
  const groups = await realm.groups.find();
  const orgGroups = findObjectByPropertyName(
    groups,
    "path",
    `/organizations/${oid}/${group}`
  );
  if (orgGroups.length === 1) {
    if (action === "add") {
      return await realm.users.addToGroup({
        id: uid,
        groupId: orgGroups[0].id,
      });
    } else if (action === "delete") {
      return await realm.users.delFromGroup({
        id: uid,
        groupId: orgGroups[0].id,
      });
    } else {
      throw new Error("Incorrect keycloak org group modification action");
    }
  } else {
    throw new Error(
      `Failed to add ${uid} to group ${group} for org ${oid}. No valid group was found`
    );
  }
};

// Helper function to add user to a application group
const modifyUserAppAccess = async (realm, uid, aid, oid, group, action) => {
  const groups = await realm.groups.find();
  const appGroups = findObjectByPropertyName(
    groups,
    "path",
    `/applications/${aid}/${oid}/${group}`
  );
  if (appGroups.length === 1) {
    if (action === "add") {
      return await realm.users.addToGroup({
        id: uid,
        groupId: appGroups[0].id,
      });
    } else if (action === "delete") {
      return await realm.users.delFromGroup({
        id: uid,
        groupId: appGroups[0].id,
      });
    } else {
      throw new Error("Incorrect keycloak org group modification action");
    }
  } else {
    throw new Error(
      `Failed to add ${uid} to group ${group} for application ${aid} for unit ${oid}. No valid group was found`
    );
  }
};

// Helper function to create an application space by copying the keycloak
// base group for an application (applications/<aid>/base/<groups>) and creating
// sub groups under the newly created group
const createAppSpace = async (realm, aid, oid, requestor, justification) => {
  const groups = await realm.groups.find();
  const appGroups = findObjectByPropertyName(
    groups,
    "path",
    `/applications/${aid}`
  );

  if (appGroups.length !== 1) {
    throw new Error(`Failed to find application group for ${aid}`);
  }

  // Create the new organization subgroup with applications/aid
  const newAppSubgroup = await realm.groups.setOrCreateChild(
    { id: appGroups[0].id },
    {
      name: oid,
      attributes: {
        justification: [justification],
        requestor: [requestor],
        createdAt: [new Date().toISOString()],
      },
    }
  );

  // Now lets grab the base groups for the application
  const appBaseGroups = findObjectByPropertyName(
    groups,
    "path",
    `/applications/${aid}/base`
  );

  if (appBaseGroups.length !== 1) {
    throw new Error(`Failed to find application base group for ${aid}`);
  }

  // Grab the base groups
  let baseGroupRoles = appBaseGroups[0].subGroups.map(({ name }) => name);

  let baseGroups = [];

  // For each base group, create a child group
  for (bg of baseGroupRoles) {
    const newGroup = await realm.groups.setOrCreateChild(
      { id: bg },
      {
        name: bg,
        attributes: {
          createdAt: [new Date().toISOString()],
        },
      }
    );
    baseGroups.append(newGroup);
  }

  // return the newly created base groups
  return baseGroups;
};

// Recursive helper function to traverse the tree to identify property names by a matching case with myVariable
const findObjectByPropertyName = (input, propertyName, myVariable) => {
  const results = [];

  function search(input) {
    if (Array.isArray(input)) {
      for (let i = 0; i < input.length; i++) {
        search(input[i]);
      }
    } else if (typeof input === "object") {
      if (
        input.hasOwnProperty(propertyName) &&
        input[propertyName] === myVariable
      ) {
        results.push(input);
      }
      for (const key in input) {
        search(input[key]);
      }
    }
  }

  search(input);
  return results;
};

module.exports = {
  getGroupByName,
  getUserByEmail,
  getGroupMembers,
  getGroupMembersById,
  getAppAdminMembers,
  verifyOrganizationExists,
  verifyApplicationSpaceExists,
  verifyTokenAndGroup,
  authenticateAdmin,
  validateUpdateParams,
  verifyGroup,
  createNewOrganization,
  createChildGroups,
  modifyUserOrgGroupAccess,
  modifyUserAppAccess,
  createAppSpace,
  findObjectByPropertyName,
};
