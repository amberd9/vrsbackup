import request from "axios";
import getToken from "keycloak-request-token";

class KeycloakClient {
  constructor(adminClient, config) {
    this.adminClient = adminClient;
    this.config = KeycloakClient.createAdminClientConfig(config);
    this.request = new KeyCloakAdminRequest(this.config);
  }

  static createAdminClientConfig(config) {
    const authServerUrl = `${config.serverUrl}/auth`;
    return {
      realm: config.realm,
      baseUrl: authServerUrl,
      clientSecret: config.clientSecret,
      grantType: "client_credentials",
      client_id: config.adminClientId || "admin-cli",
    };
  }

  authenticate() {
    return getToken(this.config.baseUrl, this.config);
  }

  findUser(email) {
    try {
      return this.adminClient.users.find(this.config.realm, {
        username: email,
      });
    } catch (error) {
      console.error("Error finding user...", email.toString());
      return error;
    }
  }

  addUserToGroup(id, futureGroup) {
    return this.authenticate()
      .then((token) => this.request.addUserToGroup(id, futureGroup, token))
      .then(() => `User '${id}' added to group ${futureGroup}`)
      .catch(function (error) {
        console.error("Failed to add user to group: ", error.toString());
        return error;
      });
  }

  removeUserFromGroup(id, currentGroup) {
    return this.authenticate()
      .then((token) =>
        this.request.removeUserFromGroup(id, currentGroup, token)
      )
      .then(() => `User '${id}' removed from group ${currentGroup}`)
      .catch(function (error) {
        console.error("Failed to remove user from group: ", error.toString());
        return error;
      });
  }

  getGroups(resolve, reject, groupId) {
    return this.authenticate()
      .then(async (token) => {
        let groups = [];
        if (Array.isArray(groupId)) {
          groups = await Promise.all(
            groupId.map(async (id) => await this.request.getGroups(id, token))
          );
        } else {
          groups.push(await this.request.getGroups(groupId, token));
        }
        return groups;
      })
      .then((groups) => {
        groups ? resolve(groups) : reject("Group(s) not found - 1");
      })
      .catch(function (error) {
        Promise.reject("Group(s) not found - 2");
        console.error(error);
        return error;
      });
  }

  getGroupByName(GroupName) {
    return this.authenticate()
      .then((token) => this.request.getGroupByName(GroupName, token))
      .then((groups) =>
        groups ? Promise.resolve(groups) : Promise.reject("Group not found")
      )
      .catch(function (error) {
        console.error(error);
        return error;
      });
  }
}
// ---------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------
class KeyCloakAdminRequest {
  constructor(config) {
    this.config = config;
  }

  logout(token) {
    return this.doRequest(
      "POST",
      `/${this.config.realm}/users/openid-cuserinfo`,
      token,
      null
    );
  }

  getRole(roleName, token) {
    return this.doRequest(
      "GET",
      `/admin/realms/${this.config.realm}/roles/${roleName}`,
      token,
      null
    );
  }

  addRoleToUser(userId, role, token) {
    return this.doRequest(
      "POST",
      `/admin/realms/${this.config.realm}/users/${userId}/role-mappings/realm`,
      token,
      [role]
    );
  }

  removeRoleFromUser(userId, role, token) {
    return this.doRequest(
      "DELETE",
      `/admin/realms/${this.config.realm}/users/${userId}/role-mappings/realm`,
      token,
      [role]
    );
  }
  // --------------------------------------------------------
  // --------------------------------------------------------
  // --------------------------------------------------------
  addUserToGroup(id, futureGroup, token) {
    return this.doRequest(
      "PUT",
      `/admin/realms/${this.config.realm}/users/${id}/groups/${futureGroup}`,
      token,
      null
    );
  }

  removeUserFromGroup(id, currentGroup, token) {
    return this.doRequest(
      "DELETE",
      `/admin/realms/${this.config.realm}/users/${id}/groups/${currentGroup}`,
      token,
      null
    );
  }

  getGroups(groupId, token) {
    return this.doRequest(
      "GET",
      `/admin/realms/${this.config.realm}/groups/${groupId}/members`,
      token,
      null
    );
  }

  getGroupByName(GroupName, token) {
    return this.doRequest(
      "GET",
      `/admin/realms/${this.config.realm}/groups?search=${GroupName}`,
      token,
      null
    );
  }
  // --------------------------------------------------------
  // --------------------------------------------------------
  // --------------------------------------------------------
  doRequest(method, url, accessToken, jsonBody) {
    let options = {
      url: this.config.baseUrl + url,
      auth: { bearer: accessToken },
      method,
      responseType: "json",
    };

    if (jsonBody !== null) {
      options.body = jsonBody;
    }

    return request(options).catch((error) =>
      Promise.reject(error.message ? error.message : error)
    );
  }
}

module.exports = KeycloakClient;
